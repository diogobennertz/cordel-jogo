// Aura de CHEFE no chão: estrela de pontas gravada (preto com ponta vermelha) girando devagar, um filete de papel
// e um anel interno. Enfurecido: pulsa e as pontas ficam mais longas. Marca de longe quem é o chefe.
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, shadows_disabled, fog_disabled;
uniform float furia = 0.0;
uniform int pontas = 12;
const vec3 TINTA = vec3(0.0144, 0.0103, 0.0086);
const vec3 VERM = vec3(0.39, 0.03, 0.02);
const vec3 PAPEL = vec3(0.80, 0.66, 0.42);
void fragment() {
	vec2 p = (UV - 0.5) * 2.0;
	float r = length(p);
	float a = atan(p.y, p.x) + TIME * (0.25 + furia * 0.6);
	float n = float(pontas);
	float pico = abs(fract(a * n / 6.2831853) - 0.5) * 2.0;      // 0 na ponta, 1 no vale
	float alcance = mix(0.95, 0.55 - furia * 0.1, pico) * (1.0 + 0.06 * furia * sin(TIME * 7.0));
	if (r > alcance) discard;
	vec3 c = TINTA;
	if (r > alcance - 0.14 * (1.0 - pico) - 0.05) c = mix(VERM, VERM * 1.4, furia);        // ponta vermelha
	if (r < 0.62 && r > 0.56) c = PAPEL;                                                    // filete de papel
	if (r < 0.50) discard;                                                                  // o miolo fica livre pro chefe
	ALBEDO = c;
	ALPHA = 0.95;
}
