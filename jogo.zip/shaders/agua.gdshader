// Água gravada: azul chapado com linhas de onda cavadas (como o rio de uma xilogravura), sem brilho nem reflexo.
shader_type spatial;
render_mode unshaded, cull_disabled, shadows_disabled;

varying vec3 pw;
void vertex() { pw = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }

void fragment() {
	vec3 azul = vec3(0.113, 0.235, 0.31);          // azul profundo, em linear
	vec3 tinta = vec3(0.0144, 0.0103, 0.0086);
	vec3 papel = vec3(0.80, 0.72, 0.52);
	float w = pw.z * 1.3 + sin(pw.x * 0.55) * 0.45 + sin(pw.x * 1.9 + pw.z * 0.7) * 0.14;
	float f = abs(fract(w) - 0.5) * 2.0;
	float linha_tinta = 1.0 - smoothstep(0.10, 0.22, f);
	float f2 = abs(fract(w * 0.5 + 0.25) - 0.5) * 2.0;
	float linha_papel = (1.0 - smoothstep(0.03, 0.10, f2)) * step(0.3, fract(pw.x * 0.13 + w * 0.37));
	vec3 c = azul;
	c = mix(c, papel, linha_papel * 0.8);
	c = mix(c, tinta, linha_tinta * 0.75);
	ALBEDO = c;
}
