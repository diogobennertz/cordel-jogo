// Xilogravura: cor chapada, sombra em 3 degraus e hachura (riscos de goiva) no lado que não pega sol,
// com granulado de papel. Serve para bonecos, árvores, pedras e o chão (cor por vértice).
shader_type spatial;
render_mode cull_back, specular_disabled;

uniform vec4 cor : source_color = vec4(1.0);
// tinta em espaço linear (= #201A17 em sRGB); por isso é constante e não uniform
const vec3 TINTA = vec3(0.0144, 0.0103, 0.0086);
uniform vec3 sol_dir = vec3(0.45, 0.75, 0.48);   // direção PARA o sol (o World atualiza)
uniform float emissao = 0.0;                      // fogo e brilhos: sem sombra nem hachura
uniform float hachura = 1.0;
uniform float preenchimento = 0.2;               // luz de enchimento: o lado sem sol nunca vira breu (legibilidade)
uniform float escala_hachura = 7.0;
uniform bool cor_vertice = false;
uniform vec3 verde_para = vec3(0.0);            // tema da fase: o que era verde vira esta cor (espaço linear)
uniform float verde_mix = 0.0;
uniform float relevo = 0.0;                      // chão: riscos de goiva sempre presentes

varying vec3 pw;
varying vec3 nw;

float hash(vec3 p) {
	p = fract(p * 0.3183099 + vec3(0.1));
	p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float ruido(vec3 x) {
	vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(mix(hash(i), hash(i + vec3(1, 0, 0)), f.x), mix(hash(i + vec3(0, 1, 0)), hash(i + vec3(1, 1, 0)), f.x), f.y),
	           mix(mix(hash(i + vec3(0, 0, 1)), hash(i + vec3(1, 0, 1)), f.x), mix(hash(i + vec3(0, 1, 1)), hash(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}

void vertex() {
	pw = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	nw = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
	vec3 c = cor_vertice ? pow(COLOR.rgb, vec3(2.2)) : cor.rgb;   // cor de vértice vem em sRGB
	// tema da fase: a mata verde vira terra queimada, noite azulada etc., mantendo o valor (claro/escuro)
	if (verde_mix > 0.001) {
		float verdice = smoothstep(0.0, 0.06, c.g - max(c.r, c.b)) * verde_mix;
		float v = dot(c, vec3(0.299, 0.587, 0.114));
		vec3 alvo = verde_para * (v / max(dot(verde_para, vec3(0.299, 0.587, 0.114)), 0.02));
		c = mix(c, alvo, verdice);
	}
	// granulado de papel / veio da madeira
	float g = ruido(pw * 26.0) * 0.6 + ruido(pw * 7.0) * 0.4;
	c *= 0.9 + 0.2 * g;
	// hachura estilo goiva: riscos em todo meio-tom, mais grossos e cruzados conforme escurece (calculada com a direção do sol)
	float nl = dot(normalize(nw), normalize(sol_dir));
	float dist = -(VIEW_MATRIX * vec4(pw, 1.0)).z;
	float fade = 1.0 - smoothstep(18.0, 40.0, dist);
	float traco = 0.0;
	if (hachura > 0.5 && emissao < 0.01) {
		float escuro = smoothstep(0.65, -0.2, nl);          // 0 = iluminado, 1 = bem escuro
		float d1 = (pw.x * 0.8 + pw.z * 0.6 + pw.y * 1.1) * escala_hachura;
		float d2 = (pw.x * 0.7 - pw.z * 0.7 + pw.y * 0.9) * escala_hachura;
		float l1 = 1.0 - smoothstep(escuro * 0.5, escuro * 0.5 + 0.14, abs(fract(d1) - 0.5) * 2.0);
		float l2 = (1.0 - smoothstep(0.1, 0.24, abs(fract(d2) - 0.5) * 2.0)) * smoothstep(0.55, 0.9, escuro);   // cruzado no escuro
		traco = max(l1 * step(0.08, escuro), l2) * fade;
		c = mix(c, TINTA, smoothstep(0.1, -0.25, nl) * 0.3 * fade);      // sombra puxa pra tinta
	}
	if (relevo > 0.5) {
		// chão gravado: tracinhos horizontais irregulares, como terra riscada na madeira
		float t1 = step(0.80, ruido(vec3(pw.x * 2.2, 0.0, pw.z * 8.0)));
		float t2 = step(0.86, ruido(vec3(pw.x * 6.0 + 9.0, 0.0, pw.z * 3.0)));
		traco = max(traco, max(t1, t2) * 0.55 * (1.0 - smoothstep(30.0, 70.0, dist)));
	}
	c = mix(c, TINTA, traco * 0.92);
	ALBEDO = c;
	EMISSION = c * (emissao + (emissao < 0.01 ? preenchimento : 0.0));
	ROUGHNESS = 1.0;
}

void light() {
	if (emissao <= 0.01) {
		float nl = dot(NORMAL, LIGHT) * ATTENUATION;
		// 3 degraus: sombra, meio-tom, claro
		float s = smoothstep(0.02, 0.06, nl) * 0.42 + smoothstep(0.30, 0.34, nl) * 0.58;
		DIFFUSE_LIGHT += LIGHT_COLOR * s / PI;
	}
}
