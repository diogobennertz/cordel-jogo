// Transição de PÁGINA: uma folha de folheto cobre a tela e é puxada pra cima com a borda rasgada e irregular,
// revelando o jogo — a ilustração ganhando vida.
shader_type canvas_item;
uniform float progresso = 0.0;      // 0 = folha cobrindo tudo, 1 = tela livre
const vec3 TINTA = vec3(0.125, 0.102, 0.09);
const vec3 PAPEL = vec3(0.91, 0.84, 0.68);
float h21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y);
}
void fragment() {
	float rasgo = (vn(vec2(UV.x * 22.0, 3.0)) - 0.5) * 0.10 + (vn(vec2(UV.x * 90.0, 7.0)) - 0.5) * 0.02;
	float frente = progresso * 1.2 - 0.1 + rasgo;                 // a borda da folha desce... e some por baixo
	float coberto = step(frente, 1.0 - UV.y);                     // 1 = ainda tem papel aqui (o papel sobe: sai por cima)
	float perto = abs((1.0 - UV.y) - frente);
	vec3 c = PAPEL * (1.0 + (h21(floor(FRAGCOORD.xy / 2.0)) - 0.5) * 0.06);
	// moldura de folheto na própria folha
	vec2 q = UV; float d = min(min(q.x, 1.0 - q.x) * 1280.0, min(q.y, 1.0 - q.y) * 720.0);
	c = mix(c, TINTA, step(14.0, d) * step(d, 20.0));
	c = mix(c, TINTA, step(30.0, d) * step(d, 32.0));
	c = mix(c, TINTA, (1.0 - smoothstep(0.0, 0.012, perto)) * 0.95);   // filete de tinta na borda rasgada
	COLOR = vec4(c, coberto);
}
