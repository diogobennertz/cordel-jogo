// Escurecimento de fundo atrás de menus dentro do jogo: tinta cavada em hachura (linhas diagonais), não véu translúcido.
shader_type canvas_item;
uniform float forca = 0.72;
const vec3 TINTA = vec3(0.125, 0.102, 0.09);
void fragment() {
	float d = abs(fract((FRAGCOORD.x + FRAGCOORD.y) / 5.0) - 0.5) * 2.0;
	float linha = 1.0 - smoothstep(0.55, 0.75, d);
	COLOR = vec4(TINTA, clamp(forca * 0.62 + linha * (0.38 + forca * 0.2), 0.0, 1.0));
}
