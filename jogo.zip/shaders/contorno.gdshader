// Contorno de tinta: casca invertida, mais grossa de longe (pra não sumir) e com espessura irregular
// (traço de goiva, não de régua).
shader_type spatial;
render_mode cull_front, unshaded, shadows_disabled, fog_disabled;

// tinta em espaço linear (= #201A17 em sRGB); por isso é constante e não uniform
const vec3 TINTA = vec3(0.0144, 0.0103, 0.0086);
uniform float espessura = 0.032;

float hash3(vec3 p) {
	p = fract(p * 0.3183099 + vec3(0.1)); p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

void vertex() {
	vec3 dir = normalize(mix(NORMAL, normalize(VERTEX + vec3(0.0001)), 0.5));
	float d = length((MODELVIEW_MATRIX * vec4(VERTEX, 1.0)).xyz);
	if (PROJECTION_MATRIX[3][3] == 1.0) d = 12.0;      // câmera ortográfica (molde da gravura): traço como se visto de 12 m
	float irregular = 0.7 + 0.6 * hash3(floor(VERTEX * 5.0));
	VERTEX += dir * espessura * irregular * (1.0 + d * 0.05);
	// empurra o contorno pra trás (longe da câmera): ele só aparece na silhueta e nunca fura as superfícies da frente
	vec4 vp = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	vp.z -= 0.2;
	POSITION = PROJECTION_MATRIX * vp;
}

void fragment() {
	ALBEDO = TINTA;
}
