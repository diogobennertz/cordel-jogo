// Etapa 2 da impressão de uma figura: pega a renderização da figura (RGBA) e faz o RECORTE DE PAPEL:
// faixa branca de papel ao redor da silhueta + filete de tinta por fora (como figura recortada e colada),
// e falhas de tinta (pontinhos de papel) nas áreas pretas, como numa gravura mal entintada.
shader_type canvas_item;

uniform vec2 tam_total = vec2(768.0, 288.0);
uniform float escala = 1.0;                   // moldes maiores (árvores) engrossam recorte e hachura na mesma proporção

const vec3 TINTA = vec3(0.125, 0.102, 0.09);   // sRGB (canvas_item não converte)
const vec3 PAPEL = vec3(0.95, 0.91, 0.80);

float h21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }

float vn(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y);
}

void fragment() {
	vec2 px = 1.0 / tam_total * escala;
	vec4 c = texture(TEXTURE, UV);
	float m_papel = 0.0;
	float m_tinta = 0.0;
	// a faixa de papel e o filete de tinta variam de espessura ao longo da silhueta (corte feito a mão, não régua)
	vec2 pp = FRAGCOORD.xy / escala;
	float kp = 0.8 + 0.4 * vn(pp * 0.06);
	float kt = 0.55 + 0.9 * vn(pp * 0.045 + 31.0);
	for (int i = 0; i < 16; i++) {
		float ang = float(i) * 0.3926991;   // 2*PI/16
		vec2 d = vec2(cos(ang), sin(ang));
		m_papel = max(m_papel, texture(TEXTURE, UV + d * 3.0 * kp * px).a);
		m_papel = max(m_papel, texture(TEXTURE, UV + d * 6.0 * kp * px).a);
		m_tinta = max(m_tinta, texture(TEXTURE, UV + d * 8.0 * kp * kt * px).a);
		m_tinta = max(m_tinta, texture(TEXTURE, UV + d * 10.0 * kp * kt * px).a);
	}
	vec2 p = FRAGCOORD.xy;
	if (c.a > 0.5) {
		vec3 rgb = c.rgb;
		float L = dot(rgb, vec3(0.299, 0.587, 0.114));
		// hachura de goiva nas sombras da figura: linhas diagonais que engrossam com o escuro
		float esc = smoothstep(0.50, 0.14, L);
		float diag = abs(fract((p.x + p.y) / (6.0 * escala)) - 0.5) * 2.0;
		float linha = 1.0 - smoothstep(esc * 0.75, esc * 0.75 + 0.2, diag);
		rgb = mix(rgb, TINTA, linha * step(0.12, esc) * 0.9);
		float falha = step(0.965, h21(floor(p))) * smoothstep(0.25, 0.1, L);   // pontinho de papel na tinta
		COLOR = vec4(mix(rgb, PAPEL, falha * 0.9), 1.0);
	} else if (m_papel > 0.5) {
		float g = h21(floor(p)) - 0.5;
		COLOR = vec4(PAPEL * (1.0 + g * 0.06), 1.0);
	} else if (m_tinta > 0.5) {
		COLOR = vec4(TINTA, 1.0);
	} else {
		COLOR = vec4(TINTA, 0.0);   // fora da figura: transparente, mas com a cor da tinta (evita halo escuro nos mipmaps)
	}
}
