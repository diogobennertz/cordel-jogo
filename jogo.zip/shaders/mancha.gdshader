// Mancha de tinta no chão, sob a figura: no lugar da sombra suave, uma poça preta de borda irregular.
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_opaque, shadows_disabled;
const vec3 TINTA = vec3(0.0144, 0.0103, 0.0086);
void fragment() {
	vec2 p = (UV - 0.5) * 2.0;
	float r = length(p);
	float a = atan(p.y, p.x);
	float borda = 0.86 + 0.09 * sin(a * 5.0 + 1.0) + 0.05 * sin(a * 11.0);
	if (r > borda) discard;
	ALBEDO = TINTA;
}
