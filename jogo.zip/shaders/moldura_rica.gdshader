// Página de capa de folheto: papel manchado, raios de sol gravados ao fundo e moldura rica:
// filete grosso, filete fino, FAIXA DE LOSANGOS entalhados (cada um com um miolo de papel), filete interno
// e estrela de losango nos quatro cantos. Medida como se a tela tivesse 720 de altura.
shader_type canvas_item;
const vec3 TINTA = vec3(0.125, 0.102, 0.09);
const vec3 TERRA = vec3(0.53, 0.30, 0.21);
float h21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y);
}
void fragment() {
	vec2 sz = 1.0 / SCREEN_PIXEL_SIZE;
	float k = max(sz.y / 720.0, 0.5);
	vec2 p = UV * sz / k; vec2 dim = sz / k;
	vec2 q = vec2(min(p.x, dim.x - p.x), min(p.y, dim.y - p.y));
	float d = min(q.x, q.y);
	float ao = (q.x < q.y) ? p.y : p.x;
	// raios de sol gravados atrás da página + manchas de papel velho
	vec2 r = p - vec2(dim.x * 0.30, dim.y * 0.54);
	float fr = fract(atan(r.y, r.x) * 28.0 / 6.2831853);
	float raios = step(fr, 0.07) * smoothstep(120.0, 300.0, length(r));
	float tom = raios * 0.20 + step(0.985, h21(floor(p * 0.8))) * 0.10;
	float ink = 0.0;
	ink += step(6.0, d) * step(d, 12.0);
	ink += step(16.0, d) * step(d, 17.5);
	float b = d - 21.0;
	if (b > 0.0 && b < 20.0) {
		float a = fract(ao / 22.0) - 0.5;
		float bb = (b - 10.0) / 10.0;
		float dm = abs(a) * 2.0 + abs(bb);
		ink += step(dm, 0.94) * (1.0 - step(dm, 0.34));
	}
	ink += step(44.0, d) * step(d, 45.6);
	if (q.x < 52.0 && q.y < 52.0) {                              // canto: estrela de losango
		ink = step(6.0, d) * step(d, 12.0);
		float diam = abs(26.0 - q.x) + abs(26.0 - q.y);
		ink += step(diam, 21.0) * (1.0 - step(diam, 14.0));
		ink += step(diam, 6.5);
	}
	ink = clamp(ink, 0.0, 1.0);
	COLOR = vec4(TINTA, max(tom, ink));
}
