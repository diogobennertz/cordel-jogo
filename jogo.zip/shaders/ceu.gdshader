// Céu de papel: gradiente chapado em faixas (como tinta em camadas) com um sol grande de raios gravados.
shader_type sky;

uniform vec4 topo : source_color = vec4(0.19, 0.34, 0.42, 1.0);
uniform vec4 horizonte : source_color = vec4(0.91, 0.84, 0.68, 1.0);
uniform vec4 chao : source_color = vec4(0.53, 0.30, 0.21, 1.0);
uniform vec4 cor_sol : source_color = vec4(0.84, 0.60, 0.20, 1.0);
// tinta em espaço linear (= #201A17 em sRGB); por isso é constante e não uniform
const vec3 TINTA = vec3(0.0144, 0.0103, 0.0086);
uniform vec3 dir_sol = vec3(0.4, 0.5, 0.6);
uniform float sol_visivel = 1.0;

void sky() {
	vec3 d = normalize(EYEDIR);
	float h = d.y;
	vec3 c;
	if (h >= 0.0) {
		float t = floor(pow(clamp(h * 1.6, 0.0, 1.0), 0.8) * 5.0) / 5.0;   // faixas
		c = mix(horizonte.rgb, topo.rgb, t);
	} else {
		c = mix(horizonte.rgb, chao.rgb, clamp(-h * 4.0, 0.0, 1.0));
	}
	// sol gravado: disco + raios
	vec3 s = normalize(dir_sol);
	float cs = dot(d, s);
	if (cs > 0.0 && sol_visivel > 0.5) {
		vec3 up = abs(s.y) < 0.95 ? vec3(0, 1, 0) : vec3(1, 0, 0);
		vec3 r = normalize(cross(up, s)); vec3 u = cross(s, r);
		vec2 p = vec2(dot(d, r), dot(d, u)) / max(cs, 0.001);
		float rad = length(p);
		float ang = atan(p.y, p.x);
		float disco = smoothstep(0.115, 0.105, rad);
		float aro = smoothstep(0.125, 0.12, rad) - smoothstep(0.135, 0.13, rad);
		float raios = step(0.5, fract(ang * 18.0 / TAU * 1.0 + 0.0)) * smoothstep(0.30, 0.18, rad) * step(0.145, rad);
		c = mix(c, cor_sol.rgb, max(disco, raios * 0.85));
		c = mix(c, TINTA, aro);
	}
	COLOR = c;
}
