// Barras do HUD (vida, XP, chefe): a cor chapada ganha hachura de goiva na diagonal, como uma barra entalhada.
shader_type canvas_item;
uniform float forca = 0.32;
const vec3 TINTA = vec3(0.125, 0.102, 0.09);
void fragment() {
	float d = abs(fract((FRAGCOORD.x + FRAGCOORD.y) / 6.0) - 0.5) * 2.0;
	float linha = 1.0 - smoothstep(0.3, 0.46, d);
	COLOR = vec4(mix(COLOR.rgb, TINTA, linha * forca), COLOR.a);
}
