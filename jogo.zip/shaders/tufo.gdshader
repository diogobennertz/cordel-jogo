// Capim e flores como RISCOS DE TINTA: cada tufo é um cartãozinho em pé com 3 lâminas gravadas;
// cada flor, um ponto de pigmento com filete preto. Cor vem da instância (paleta).
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_opaque, shadows_disabled;

uniform int forma = 0;      // 0 = capim, 1 = flor
varying vec4 cor_i;

void vertex() {
	cor_i = COLOR;
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(
		vec4(normalize(cross(vec3(0.0, 1.0, 0.0), INV_VIEW_MATRIX[2].xyz)), 0.0),
		vec4(0.0, 1.0, 0.0, 0.0),
		vec4(normalize(cross(INV_VIEW_MATRIX[0].xyz, vec3(0.0, 1.0, 0.0))), 0.0),
		MODEL_MATRIX[3]);
	MODELVIEW_MATRIX = MODELVIEW_MATRIX * mat4(
		vec4(length(MODEL_MATRIX[0].xyz), 0.0, 0.0, 0.0),
		vec4(0.0, length(MODEL_MATRIX[1].xyz), 0.0, 0.0),
		vec4(0.0, 0.0, length(MODEL_MATRIX[2].xyz), 0.0),
		vec4(0.0, 0.0, 0.0, 1.0));
}

void fragment() {
	vec2 p = vec2(UV.x, 1.0 - UV.y);      // y = 0 no chão, 1 no topo
	vec3 col = pow(cor_i.rgb, vec3(2.2));
	if (forma == 0) {
		bool dentro = false;
		float xs[3] = float[3](0.28, 0.5, 0.72);
		float ls[3] = float[3](-0.22, 0.04, 0.24);
		float hs[3] = float[3](0.62, 1.0, 0.74);
		for (int i = 0; i < 3; i++) {
			float cx = xs[i] + ls[i] * p.y;
			float hw = 0.075 * (1.0 - p.y / hs[i]);
			if (p.y < hs[i] && abs(p.x - cx) < hw) dentro = true;
		}
		if (!dentro) discard;
		ALBEDO = col;
	} else {
		vec2 q = p - vec2(0.5, 0.5);
		float r = length(q);
		if (r > 0.46) discard;
		ALBEDO = r > 0.34 ? vec3(0.0144, 0.0103, 0.0086) : col;
	}
}
