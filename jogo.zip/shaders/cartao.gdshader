// Figura de papel em pé: um quadro de uma folha de gravuras (vários quadros lado a lado), sempre virado pra câmera
// só em Y (fica de pé como recorte de livro pop-up), com balanço de boneco de mamulengo.
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_opaque, fog_disabled;      // a neblina é feita aqui, mais suave

uniform sampler2D folha : source_color, filter_linear_mipmap, repeat_disable;
uniform vec2 tam = vec2(1.7, 2.6);          // tamanho da figura no mundo (m)
uniform float quadros = 4.0;
uniform float desloca = 0.0;                  // o centro da figura em relação à origem do modelo (objetos com peças de um lado só)
uniform float vento = 0.0;                    // plantas balançam
uniform float nevoa = 0.4;                    // quanto a figura esmaece pro papel lá longe (0 = nada)
uniform vec3 cor_nevoa = vec3(0.81, 0.68, 0.43);
// tema da fase: o verde vira outra cor (mesma ideia do shader de xilogravura)
uniform vec3 verde_para = vec3(0.0);
uniform float verde_mix = 0.0;

instance uniform float quadro = 0.0;
instance uniform float lado = 1.0;            // 1 / -1 espelha; valores entre dão o giro (figura de lado)
instance uniform float inclina = 0.0;         // balanço
instance uniform float flash = 0.0;           // acerto: pisca em branco
// contorno colorido em volta da figura (o herói), em px de tela; alfa 0 = sem contorno
instance uniform vec4 contorno_cor : source_color = vec4(0.0);
uniform float contorno_px = 7.0;

varying vec2 uv_q;

void vertex() {
	vec3 v = VERTEX;
	v.x = v.x * tam.x * lado + desloca;
	v.y = v.y * tam.y;
	float balanco = inclina + vento * sin(TIME * 1.3 + MODEL_MATRIX[3].x * 0.7 + MODEL_MATRIX[3].z * 0.5) * 0.05;
	v.x += v.y * balanco;
	VERTEX = v;
	// de pé, virado pra câmera, mas inclinando um pouco pra trás junto com o ângulo da câmera (não só em Y
	// puro): um recorte 100% vertical parece papel colado quando a câmera olha de cima; um pouco de
	// inclinação junto com o "up" da câmera dá a sensação de volume/profundidade de pé no chão.
	vec3 up_mundo = vec3(0.0, 1.0, 0.0);
	vec3 up_tela = normalize(mix(up_mundo, INV_VIEW_MATRIX[1].xyz, 0.42));
	vec3 eixo_x = normalize(cross(up_tela, INV_VIEW_MATRIX[2].xyz));
	vec3 eixo_z = normalize(cross(eixo_x, up_tela));
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(
		vec4(eixo_x, 0.0),
		vec4(up_tela, 0.0),
		vec4(eixo_z, 0.0),
		MODEL_MATRIX[3]);
	MODELVIEW_MATRIX = MODELVIEW_MATRIX * mat4(
		vec4(length(MODEL_MATRIX[0].xyz), 0.0, 0.0, 0.0),
		vec4(0.0, length(MODEL_MATRIX[1].xyz), 0.0, 0.0),
		vec4(0.0, 0.0, length(MODEL_MATRIX[2].xyz), 0.0),
		vec4(0.0, 0.0, 0.0, 1.0));
	uv_q = vec2((UV.x + quadro) / quadros, UV.y);
}

void fragment() {
	vec2 gx = dFdx(uv_q); vec2 gy = dFdy(uv_q);
	vec2 fw = abs(gx) + abs(gy);
	vec4 t = texture(folha, uv_q);
	vec3 c = t.rgb;
	if (t.a < 0.4) {
		float m = 0.0;
		if (contorno_cor.a > 0.01) {
			float x0 = quadro / quadros; float x1 = (quadro + 1.0) / quadros;
			for (int i = 0; i < 12; i++) {
				float a = float(i) * 0.5235988;
				vec2 u = uv_q + vec2(cos(a), sin(a)) * fw * contorno_px;
				u.x = clamp(u.x, x0, x1);
				m = max(m, textureGrad(folha, u, gx, gy).a);
			}
		}
		if (m < 0.4) discard;
		c = contorno_cor.rgb;
	} else if (verde_mix > 0.001) {
		float verdice = smoothstep(0.0, 0.06, c.g - max(c.r, c.b)) * verde_mix;
		float v = dot(c, vec3(0.299, 0.587, 0.114));
		vec3 alvo = verde_para * (v / max(dot(verde_para, vec3(0.299, 0.587, 0.114)), 0.02));
		c = mix(c, alvo, verdice);
	}
	float dist = length(VERTEX);
	c = mix(c, cor_nevoa, smoothstep(30.0, 120.0, dist) * nevoa);
	// escurece as bordas (esquerda/direita do quadro) como se o corpo fizesse curva pra trás ali — a
	// gravura não muda de sombra girando a câmera (foi impressa uma vez só de frente), então sem isso
	// a figura lê como papel colado por inteiro, sem volume nenhum.
	float curva = pow(abs(UV.x - 0.5) * 2.0, 1.7) * 0.4;
	c = mix(c, c * 0.55, curva);
	c = mix(c, vec3(1.0), flash * 0.75);
	ALBEDO = c;
}
