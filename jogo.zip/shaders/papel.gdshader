// IMPRESSÃO DE XILOGRAVURA sobre o jogo inteiro (pós-processamento, entre o 3D e a interface).
// Imita como uma gravura de cordel é feita de verdade:
//  - matriz entalhada a mão: bordas levemente trêmulas;
//  - a tinta só pega no relevo: o preto é preto chapado, a sombra vira LINHAS cavadas (hachura), nunca degradê;
//  - tinta irregular: pontinhos onde o papel aparece e veio de madeira nas áreas pretas;
//  - cor impressa em outra chapa, chapada e levemente DESALINHADA do preto (erro de registro);
//  - papel poroso, com grão, na cor do papel da fase (cordel é impresso em papel colorido).
shader_type canvas_item;

uniform sampler2D tela : hint_screen_texture, filter_linear;
uniform vec3 cor_papel = vec3(0.91, 0.84, 0.68);   // sRGB direto (canvas_item não converte)
uniform float levanta = 0.35;                      // quanto clarear a chapa de cor nas sombras (a tinta é quem escurece)
uniform float rigor = 1.0;                         // quanto da imagem vira linha cavada (fases escuras pedem menos)
uniform float forca = 1.0;

const vec3 TINTA = vec3(0.125, 0.102, 0.09);

float h21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y);
}
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void fragment() {
	vec2 sz = 1.0 / SCREEN_PIXEL_SIZE;
	float k = max(sz.y / 720.0, 0.5);                 // tudo medido como se a tela tivesse 720 de altura
	vec2 p = FRAGCOORD.xy / k;
	vec2 px = SCREEN_PIXEL_SIZE * k;

	// entalhe feito a mão: ondulação lenta nas bordas
	vec2 wob = vec2(vn(p * 0.055), vn(p * 0.055 + 17.3)) - 0.5;
	vec2 uv = SCREEN_UV + wob * 2.4 * px;
	vec3 c = texture(tela, uv).rgb;
	float L = lum(c);

	// chapa de cor: chapada, desalinhada do preto, mais clara e misturada ao papel
	vec3 cc = texture(tela, uv + vec2(3.0, -2.0) * px).rgb;
	float lc = lum(cc);
	cc = mix(vec3(lc), cc, 0.92);
	cc += (vec3(1.0) - cc) * smoothstep(0.55, 0.08, lc) * levanta;     // sombra não escurece a cor: a tinta é que faz
	cc = mix(cor_papel, cc, 0.9);

	// chapa de tinta
	float tinta = smoothstep(0.21, 0.10, L);                            // preto que o 3D já trouxe (contorno, hachura)
	float esc = smoothstep(0.36, 0.09, L) * rigor;                              // 0 claro .. 1 escuro
	float diag = abs(fract((p.x + p.y) / 5.5) - 0.5) * 2.0;             // linhas cavadas na diagonal
	float linha = 1.0 - smoothstep(esc * 0.7, esc * 0.7 + 0.16, diag);
	tinta = max(tinta, linha * step(0.16, esc));

	// tinta irregular: falha em pontos e tem veio de madeira
	float ponto = step(0.955, h21(floor(p * 1.1)));
	float veio = vn(vec2(p.x * 0.035, p.y * 0.8));
	float falha = max(ponto * 0.95, smoothstep(0.80, 0.92, veio) * 0.55);
	tinta *= 1.0 - falha * smoothstep(0.1, 0.9, tinta);

	vec3 o = mix(cc, TINTA, tinta);

	// papel poroso
	float g = h21(floor(p)) - 0.5;
	float fibra = h21(floor(p * vec2(0.5, 0.07))) - 0.5;
	o *= 1.0 + g * 0.05 + fibra * 0.03;

	// moldura de folheto: filete grosso + filete fino, cantos reforçados; vinheta de tinta nas bordas
	float d = min(min(p.x, 720.0 * sz.x / sz.y - p.x), min(p.y, 720.0 - p.y));
	float moldura = step(4.0, d) * step(d, 8.0) + step(12.0, d) * step(d, 13.5);
	vec2 q = vec2(min(p.x, 720.0 * sz.x / sz.y - p.x), min(p.y, 720.0 - p.y));
	moldura += step(max(q.x, q.y), 28.0) * step(min(q.x, q.y), 8.0) * step(4.0, min(q.x, q.y));
	o = mix(o, TINTA, clamp(moldura, 0.0, 1.0));
	float vinheta = smoothstep(0.62, 1.05, distance(SCREEN_UV, vec2(0.5)));
	o = mix(o, TINTA, vinheta * 0.22);

	COLOR = vec4(mix(c, o, forca), 1.0);
}
