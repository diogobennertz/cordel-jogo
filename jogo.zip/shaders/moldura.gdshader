// Moldura de página de folheto (fundo dos menus): filete grosso por fora, faixa de DENTES entalhados no meio e filete fino
// por dentro, com quadrados de reforço nos cantos. Medida como se a tela tivesse 720 de altura.
shader_type canvas_item;
const vec3 TINTA = vec3(0.125, 0.102, 0.09);
void fragment() {
	vec2 sz = 1.0 / SCREEN_PIXEL_SIZE;
	float k = max(sz.y / 720.0, 0.5);
	vec2 p = UV * sz / k;
	vec2 dim = sz / k;
	float d = min(min(p.x, dim.x - p.x), min(p.y, dim.y - p.y));
	float m = step(8.0, d) * step(d, 13.0);                              // filete grosso
	m += step(17.0, d) * step(d, 18.6);                                  // filete fino
	// faixa de dentes (triângulos) entre os dois filetes: serrilha ao longo da borda
	float ao_longo = (min(p.x, dim.x - p.x) < min(p.y, dim.y - p.y)) ? p.y : p.x;
	float serra = abs(fract(ao_longo / 14.0) - 0.5) * 2.0;               // 0..1
	float altura = 5.0 * (1.0 - serra);
	m += step(18.6, d) * step(d, 18.6 + altura) * 0.0;                   // (reservado)
	float dentro = step(13.0, d) * step(d, 13.0 + altura * 0.9 + 0.5);
	m += dentro;
	// quadrados de canto
	vec2 q = vec2(min(p.x, dim.x - p.x), min(p.y, dim.y - p.y));
	m += step(max(q.x, q.y), 34.0) * step(min(q.x, q.y), 8.0 + 26.0) * step(8.0, min(q.x, q.y)) * step(min(q.x, q.y), 13.0) * 1.0;
	COLOR = vec4(TINTA, clamp(m, 0.0, 1.0));
}
