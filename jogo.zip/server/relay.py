#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Relay de pacotes do Cordel (multijogador) — roda na sua casa, numa porta so.

O QUE FAZ
Nao entende nada do jogo: so repassa bytes crus entre o anfitriao e os convidados
de uma mesma SALA (codigo), igual um "correio". Ninguem mais precisa abrir porta
no proprio roteador — so quem roda este relay (uma vez so, aqui em casa).

PROTOCOLO (so entre o relay e o tunel.py — o jogo em si nao sabe que isso existe)
Cada pacote UDP que chega aqui comeca com um cabecalho de 10 bytes:
  b'R'            1 byte  (marca d'agua, so pra nao confundir com lixo de rede)
  sala            8 bytes (codigo da sala, texto, preenchido com espacos)
  papel           1 byte  (b'H' = anfitriao, b'C' = convidado)
seguido do resto (o payload de verdade, pode vir vazio so pra "avisar que cheguei").

Ao receber um pacote, o relay:
  1) anota (sala, papel, endereco de quem mandou) — assim sempre sabe pra onde
     devolver resposta, mesmo que a porta de origem mude (NAT reconectando).
  2) se o payload nao estiver vazio, repassa ele CRU (sem cabecalho) para:
     - papel H (anfitriao mandou): para TODOS os convidados daquela sala.
     - papel C (convidado mandou): so para o anfitriao daquela sala.
Uma sala sem anfitriao registrado ainda guarda os convidados em espera; quando o
anfitriao aparecer, os pacotes dele comecam a fluir normalmente.

Salas paradas (sem nenhum pacote) por mais de LIMPEZA_S somem sozinhas.

USO
    python relay.py [porta]            # porta padrao 40000
"""
import socket
import sys
import time

PORTA_PADRAO = 40000
LIMPEZA_S = 120.0          # sala sem trafego nenhum por 2 min: esquece ela
MARCA = b"R"
TAM_SALA = 8
TAM_CABECALHO = len(MARCA) + TAM_SALA + 1


def pacote(sala: bytes, papel: bytes, payload: bytes) -> bytes:
    return MARCA + sala.ljust(TAM_SALA)[:TAM_SALA] + papel + payload


def partir(dados: bytes):
    if len(dados) < TAM_CABECALHO or dados[0:1] != MARCA:
        return None
    sala = dados[1:1 + TAM_SALA].rstrip()
    papel = dados[1 + TAM_SALA:TAM_CABECALHO]
    payload = dados[TAM_CABECALHO:]
    return sala, papel, payload


def principal(porta: int) -> None:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("0.0.0.0", porta))
    print(f"relay do Cordel ouvindo na porta UDP {porta} — Ctrl+C pra parar")

    # salas[codigo] = {"anfitriao": (ip,porta)|None, "convidados": {(ip,porta): ultimo_visto}, "visto": tempo}
    salas: dict[bytes, dict] = {}

    while True:
        try:
            dados, origem = s.recvfrom(4096)
        except (ConnectionResetError, OSError):
            # no Windows, um ICMP "porta fechada" do outro lado pode chegar como erro aqui — ignora e segue
            continue

        lido = partir(dados)
        if lido is None:
            continue
        sala, papel, payload = lido
        agora = time.monotonic()

        s_estado = salas.setdefault(sala, {"anfitriao": None, "convidados": {}, "visto": agora})
        s_estado["visto"] = agora

        if papel == b"H":
            if s_estado["anfitriao"] != origem:
                print(f"sala {sala.decode(errors='replace')!r}: anfitriao em {origem}")
            s_estado["anfitriao"] = origem
            if payload:
                for conv in list(s_estado["convidados"].keys()):
                    s.sendto(payload, conv)
        elif papel == b"C":
            if origem not in s_estado["convidados"]:
                print(f"sala {sala.decode(errors='replace')!r}: convidado em {origem}")
            s_estado["convidados"][origem] = agora
            if payload and s_estado["anfitriao"] is not None:
                s.sendto(payload, s_estado["anfitriao"])

        # limpeza preguicosa: a cada pacote, aproveita pra descartar salas mortas
        mortas = [k for k, v in salas.items() if agora - v["visto"] > LIMPEZA_S]
        for k in mortas:
            print(f"sala {k.decode(errors='replace')!r}: esqueci (sem trafego ha {LIMPEZA_S:.0f}s)")
            del salas[k]


if __name__ == "__main__":
    porta_cli = int(sys.argv[1]) if len(sys.argv) > 1 else PORTA_PADRAO
    try:
        principal(porta_cli)
    except KeyboardInterrupt:
        print("\nrelay encerrado.")
