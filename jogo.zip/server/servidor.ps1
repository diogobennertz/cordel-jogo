# Supervisor do SERVIDOR DEDICADO do Cordel (roda neste PC, sem janela).
# Mantém o jogo rodando em modo --servidor, atualiza pro último release do GitHub quando não tem ninguém jogando,
# e sobe de novo se o servidor cair. Fica em C:\Users\diogo\Cordel-Servidor\servidor.ps1 (cópia deste arquivo).
#
# Usa o Cordel.exe JÁ INSTALADO (o firewall do Windows já libera ele), com o projeto numa pasta própria (jogo\)
# pra não brigar com o Jogar.ps1 do jogo normal. Porta UDP 40000 (a que o roteador já encaminha pra este PC).
$ErrorActionPreference = 'Continue'
$base   = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe    = Join-Path $env:LOCALAPPDATA 'Programs\Cordel\motor\Cordel.exe'
$url    = 'https://raw.githubusercontent.com/diogobennertz/cordel-jogo/main'
$porta  = 40000
$status = Join-Path $base 'status.txt'
$log    = Join-Path $base 'servidor.log'
$script:proc = $null
$script:iniciou = Get-Date

function Log($m) {
  ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) | Add-Content -Path $log -Encoding UTF8
  if ((Get-Item $log -ErrorAction SilentlyContinue).Length -gt 500KB) { Move-Item $log "$log.antigo" -Force }
}

# só uma cópia deste supervisor por vez
$mutex = New-Object System.Threading.Mutex($false, 'CordelServidorSupervisor')
if (-not $mutex.WaitOne(0)) { exit 0 }

# "estado jogadores unix" escrito pelo próprio servidor a cada 5 s
function Ler-Status {
  if (-not (Test-Path $status)) { return $null }
  $p = ("" + (Get-Content $status -TotalCount 1)).Split(' ')
  if ($p.Count -lt 3) { return $null }
  return @{ estado = $p[0]; jogadores = [int]$p[1]; idade = ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - [int64]$p[2]) }
}

function Parar-Servidor {
  if ($script:proc -and -not $script:proc.HasExited) {
    Log "parando o servidor (pid $($script:proc.Id))"
    $script:proc.Kill(); $script:proc.WaitForExit(5000) | Out-Null
  }
  $script:proc = $null
}

function Subir-Servidor {
  if (-not (Test-Path (Join-Path $base 'jogo\project.godot'))) { Log 'sem jogo\ ainda: nada pra subir'; return }
  if (-not (Test-Path $exe)) { Log "Cordel.exe não achado em $exe"; return }
  Remove-Item $status -ErrorAction SilentlyContinue
  $a = @('--headless', '--audio-driver', 'Dummy', '--path', ('"' + (Join-Path $base 'jogo') + '"'), '--', '--servidor', '--porta', "$porta", '--status', ('"' + $status + '"'))
  $script:proc = Start-Process -FilePath $exe -ArgumentList $a -PassThru -WindowStyle Hidden
  $script:iniciou = Get-Date
  Log "servidor no ar (pid $($script:proc.Id), porta UDP $porta, versão $(Get-Content (Join-Path $base 'versao.txt') -TotalCount 1))"
}

# baixa o release novo; só troca de verdade quando não tem ninguém jogando
function Atualizar {
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $wc = New-Object Net.WebClient
    $rem = $wc.DownloadString("$url/versao.txt").Trim()
    $arq = Join-Path $base 'versao.txt'
    $loc = if (Test-Path $arq) { ("" + (Get-Content $arq -TotalCount 1)).Trim() } else { '' }
    if (-not $rem -or $rem -eq $loc -or $rem.Length -ge 40) { return }
    $s = Ler-Status
    if ($script:proc -and -not $script:proc.HasExited -and $s -and $s.idade -lt 60 -and $s.jogadores -gt 0) {
      Log "versão nova ($rem) esperando: tem $($s.jogadores) jogando"; return
    }
    Log "atualizando $loc -> $rem"
    $zip = Join-Path $env:TEMP 'cordel-servidor.zip'
    $wc.DownloadFile("$url/jogo.zip", $zip)
    $novo = Join-Path $base 'jogo_novo'
    if (Test-Path $novo) { Remove-Item -Recurse -Force $novo }
    Expand-Archive -Path $zip -DestinationPath $novo -Force
    Remove-Item -Force $zip
    if (Test-Path (Join-Path $novo 'project.godot')) {
      Parar-Servidor
      $velho = Join-Path $base 'jogo'
      if (Test-Path $velho) { Remove-Item -Recurse -Force $velho }
      Rename-Item $novo 'jogo'
      Set-Content -Path $arq -Value $rem
      Log "atualizado pra $rem"
    } else { Log 'zip sem project.godot: ignorei' }
  } catch { Log "erro ao atualizar: $_" }
}

Log '--- supervisor iniciado'
Atualizar
$ultima = Get-Date
while ($true) {
  if ($script:proc -and $script:proc.HasExited) {
    Log "servidor caiu (código $($script:proc.ExitCode)); subindo de novo em 10 s"
    $script:proc = $null; Start-Sleep 10
  }
  # travado: está vivo mas parou de escrever o status (esperando 90 s depois de subir)
  if ($script:proc -and ((Get-Date) - $script:iniciou).TotalSeconds -gt 90) {
    $s = Ler-Status
    if (-not $s -or $s.idade -gt 90) { Log 'servidor parou de responder: reiniciando'; Parar-Servidor }
  }
  if (-not $script:proc) { Subir-Servidor }
  if (((Get-Date) - $ultima).TotalMinutes -ge 10) { Atualizar; $ultima = Get-Date }
  Start-Sleep 5
}
