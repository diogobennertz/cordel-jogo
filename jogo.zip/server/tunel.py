#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tunel local do Cordel: faz o jogo (ENet) conversar com o relay sem precisar abrir
porta nenhuma no proprio roteador. Roda uma copia disso no PC do anfitriao e outra
no PC de cada convidado — cada um com --papel diferente.

Anfitriao (quem abriu a sala no jogo, que ja esta ouvindo em 127.0.0.1:<porta_jogo>):
    python tunel.py --papel anfitriao --sala ABCD1234 --relay relay.example.com:40000 --porta-jogo 7777

Convidado (o jogo, em vez de conectar no IP de internet do anfitriao, conecta em
"127.0.0.1:<porta_local>" — essa porta e a que este tunel abre e finge ser o anfitriao):
    python tunel.py --papel convidado --sala ABCD1234 --relay relay.example.com:40000 --porta-local 17777

Nao entende nada do jogo: so repassa bytes crus pra la e pra ca. A reconexao/latencia
de internet fica por conta do ENet (que ja tem isso embutido); aqui so existe mais um
salto no meio do caminho.
"""
import argparse
import select
import socket
import sys
import time

MARCA = b"R"
TAM_SALA = 8
REGISTRO_S = 3.0   # reenvia "eu existo" pro relay nesse intervalo, mesmo sem trafego


def cabecalho(sala: str, papel: bytes) -> bytes:
    return MARCA + sala.encode()[:TAM_SALA].ljust(TAM_SALA) + papel


def resolver(endereco: str) -> tuple[str, int]:
    host, _, porta = endereco.rpartition(":")
    if not host:
        raise ValueError(f"endereco invalido (use host:porta): {endereco!r}")
    return host, int(porta)


def rodar_anfitriao(sala: str, relay_addr: tuple[str, int], porta_jogo: int) -> None:
    cab = cabecalho(sala, b"H")
    s_relay = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s_jogo = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s_jogo.connect(("127.0.0.1", porta_jogo))   # so fixa o destino; nao impede receber resposta
    print(f"tunel ANFITRIAO: sala={sala!r} relay={relay_addr} jogo local na porta {porta_jogo}")
    _laco(s_relay, relay_addr, s_jogo, None, cab)


def rodar_convidado(sala: str, relay_addr: tuple[str, int], porta_local: int) -> None:
    cab = cabecalho(sala, b"C")
    s_relay = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s_jogo = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s_jogo.bind(("127.0.0.1", porta_local))     # o jogo (ENet cliente) conecta AQUI, pensando ser o anfitriao
    print(f"tunel CONVIDADO: sala={sala!r} relay={relay_addr} esperando o jogo em 127.0.0.1:{porta_local}")
    _laco(s_relay, relay_addr, s_jogo, "aguardando", cab)


def _laco(s_relay: socket.socket, relay_addr, s_jogo: socket.socket, endereco_jogo, cab: bytes) -> None:
    # endereco_jogo: None quando s_jogo.connect() ja fixou o destino (anfitriao);
    # uma string/None-ainda-descoberto quando e preciso aprender quem conectou (convidado, via recvfrom).
    ultimo_registro = 0.0
    while True:
        agora = time.monotonic()
        if agora - ultimo_registro > REGISTRO_S:
            s_relay.sendto(cab, relay_addr)   # payload vazio = so "continuo vivo"
            ultimo_registro = agora

        try:
            prontos, _, _ = select.select([s_relay, s_jogo], [], [], REGISTRO_S)
        except OSError:
            continue   # pode acontecer junto de um ICMP "porta fechada" de um pacote anterior
        for pronto in prontos:
            try:
                if pronto is s_relay:
                    dados, origem = s_relay.recvfrom(4096)
                    if origem != relay_addr:
                        continue   # pacote de endereco estranho: ignora (nao e o relay combinado)
                    if not dados:
                        continue
                    if endereco_jogo is None:
                        s_jogo.send(dados)
                    elif endereco_jogo == "aguardando":
                        pass   # ainda nao sabe pra onde mandar (jogo local nao conectou ainda)
                    else:
                        s_jogo.sendto(dados, endereco_jogo)
                else:
                    if endereco_jogo is None:
                        dados = pronto.recv(4096)
                    else:
                        dados, remetente = pronto.recvfrom(4096)
                        if remetente != endereco_jogo:
                            # jogo local (re)conectou — reconhece o endereco novo (porta pode mudar entre partidas)
                            endereco_jogo = remetente
                            print(f"  jogo local conectou de {remetente}")
                    if dados:
                        s_relay.sendto(cab + dados, relay_addr)
            except (ConnectionResetError, OSError) as e:
                # no Windows, um ICMP "porta fechada" do outro lado pode chegar como erro aqui — so ignora
                print(f"  (aviso: {e})")
                continue


def principal() -> None:
    ap = argparse.ArgumentParser(description="Tunel local do Cordel (fala com o relay em vez de abrir porta)")
    ap.add_argument("--papel", choices=["anfitriao", "convidado"], required=True)
    ap.add_argument("--sala", required=True, help="codigo da sala (ate 8 caracteres)")
    ap.add_argument("--relay", required=True, help="endereco do relay, host:porta")
    ap.add_argument("--porta-jogo", type=int, default=7777, help="(anfitriao) porta local onde o Cordel ja esta ouvindo")
    ap.add_argument("--porta-local", type=int, default=17777, help="(convidado) porta que este tunel abre pro Cordel conectar")
    args = ap.parse_args()

    relay_addr = resolver(args.relay)
    if args.papel == "anfitriao":
        rodar_anfitriao(args.sala, relay_addr, args.porta_jogo)
    else:
        rodar_convidado(args.sala, relay_addr, args.porta_local)


if __name__ == "__main__":
    try:
        principal()
    except KeyboardInterrupt:
        print("\ntunel encerrado.")
    except ValueError as e:
        print(f"erro: {e}", file=sys.stderr)
        sys.exit(1)
