# Direção de arte — Cordel como xilogravura em 3D

## Arquitetura atual: TEATRO DE PAPEL GRAVADO
O mundo é um livro pop-up de cordel: personagens, bichos, chefes, árvores e mata são **figuras de papel recortado**
(uma xilogravura cada, com faixa branca de recorte e filete de tinta), em pé, viradas pra câmera, sobre um chão de
papel entalhado. O 3D continua existindo (câmera, profundidade, colisão, jogabilidade), mas a figura em si é um cartão.

| Peça | Arquivo | O que faz |
|---|---|---|
| Matriz 3D dos personagens | `scripts/visual/Modelo.gd` | o modelo montado por código (antigo `Boneco`); só serve pra tirar a gravura e de reserva |
| Boneco (interface do jogo) | `scripts/Boneco.gd` | mesma interface de sempre (criar/animar/atacar/girar/bater/tonto); por dentro usa um Cartao |
| Ateliê de gravura | `scripts/visual/Gravador.gd` | monta a matriz com luz de frente, imprime 4 quadros (parado, 2 passos, ataque), faz o recorte de papel e guarda em cache |
| Figura em pé | `scripts/visual/Cartao.gd` + `shaders/cartao.gdshader` | só gira em Y pra câmera, balança/quica como mamulengo, espelha, pisca ao apanhar |
| Recorte de papel | `shaders/recorte.gdshader` | faixa branca + filete preto + hachura + falhas de tinta |
| Mancha no chão | `shaders/mancha.gdshader` | poça de tinta no lugar da sombra suave |

- Fallback: sem tela (testes automáticos) ou com a opção "Figuras de papel recortado" desligada, o `Boneco` usa o modelo 3D antigo.
- Árvores e mata: `Gravador.construtores` ("planta", "muralha"); a colisão e a oclusão continuam em `World._planta` (`PLANTA_COL`).
- Medido na mesma cena de combate: 11.859 → 1.601 chamadas de desenho e 4.774 → 1.136 nós.
- Depuração: `--folha` (imprime todas as folhas em `godot/folha_N.png`; `--folha poucos` só os chefes), `--sem-papel` (modo 3D antigo).
- Pra criar um personagem novo: monte-o em `Modelo.gd` (mesmo jeito de antes); o Gravador imprime sozinho.


Ideia: o mundo é feito de recortes de papel impressos com tinta de gráfica de cordel.
Cor chapada, contorno preto irregular, sombra em degraus, hachura no lado sem sol, grão de papel.

## Proposta visual (paleta definitiva e diretrizes)
**Paleta definitiva** (pigmentos impressos; `scripts/visual/Paleta.gd`; qualquer cor pedida pelo código é puxada pra cá):

| Papel na gravura | Cor | Hex |
|---|---|---|
| Preto carvão (entalhes, contornos, massas) | TINTA | `#201A17` |
| Branco envelhecido (papel, recorte) | PAPEL / CREME | `#E8D7AE` / `#F0E9D7` |
| Bege e amarelado (terra seca, palha) | PALHA | `#B8A47A` |
| Vermelho queimado | VERMELHO | `#A83226` |
| Terracota | TERRA / TERRA_CL | `#874C35` / `#B26C47` |
| Amarelo ocre | AMARELO | `#D69A32` |
| Azul profundo (só pontual: janela, água, noite) | AZUL | `#31566B` |
| Apoio: verde seco, vinho, pele (3 tons) | VERDE, VINHO, PELE_* | ver `Paleta.gd` |

**Iluminação:** sem gradiente. A luz vira degraus (claro / meio-tom / sombra) e a sombra vira **hachura** (linhas cavadas
na diagonal que engrossam e se cruzam no escuro) e massa preta. A figura recortada leva faixa de papel branco + filete preto
de espessura **variável** (corte à mão), e áreas de preto têm falhas de tinta e veio de madeira.
**Texturas:** granulado de papel poroso, chão riscado (traços de terra), sem textura de madeira "colada" nos objetos.
**Ambiente = teatro de papel:** TUDO é recorte em pé sobre o chão de papel: personagens, bichos, chefes, árvores, mata de fundo,
serras (bastidores), nuvens, casas de taipa, cruzeiro, crânios de boi, cercas, bandeirinhas, potes, baús, oratório, bodega.
Capim = riscos de tinta; flor = ponto de pigmento; água = ondas cavadas. Luz/céu/papel mudam por fase
(dia creme, noite azulada, queimada cinza e terra, Corcovado dourado).
**Animação:** em etapas (o tempo anda em degraus; cada passo tem pequena variação própria), balanço de mamulengo,
estrela gravada de impacto, **transição de página** (folha do folheto que sobe com a borda rasgada).
**Interface:** papel, tinta, slab pesada (Alfa Slab One/Arvo, OFL), molduras de filete grosso+fino, cantos de gravura.

## Interface (refeita do zero)
Toda a interface usa o kit `Tela.gd` + peças em `scripts/visual/`; as telas continuam com a mesma lógica.
| Peça | Arquivo | O que é |
|---|---|---|
| Moldura de papel recortado | `visual/StyleEntalhe.gd` | borda irregular de cantos chanfrados, sombra de tinta chapada, contorno de 2 passadas, filete interno, ornamento de canto |
| Título de folheto | `visual/TituloGravado.gd` | letras de slab com esteira de relevo vermelho e losangos (texto de verdade: traduz) |
| Capa viva | `visual/VinhetaCapa.gd` | teatro de papel animado com as figuras do jogo (no lugar do logo de IA) |
| Fundo de página (simples) | `shaders/moldura.gdshader` | dois filetes e faixa de dentes entalhados + cantos reforçados (telas altas) |
| Fundo de página (capa de folheto) | `shaders/moldura_rica.gdshader` | filete grosso e fino, FAIXA DE LOSANGOS entalhados, estrela de losango nos cantos, raios de sol e manchas de papel velho |
| Escurecer atrás do menu | `shaders/escuro.gdshader` | hachura diagonal de tinta, não véu translúcido |
| Barras do HUD | `shaders/barra.gdshader` | cor chapada com hachura; marcas de entalhe a cada quarto de vida |
| Retratos | `Gravador.retrato()` | o quadro "parado" da própria figura de papel (mesma de campo) |
A capa é uma página de folheto de duas colunas: à esquerda a gravura de abertura em moldura dupla (bandeirolas, pássaros, serras, cactos e o elenco); à direita o cabeçalho "Literatura de Cordel", o título em relevo, uma sextilha e os botões como etiquetas com losangos nas pontas; o "preço" é o saldo de moedas.
Ícones de carta, golpe e melhoria: `visual/IconeGravura.gd` (vetorial: placa recortada, raios de sol, disco de pigmento, pictograma de tinta
e chão hachurado; ~25 pictogramas). Os ícones Q/R de cada herói usam a figura de papel do próprio herói (R com coroa de pontas).
Sliders (marcador em losango entalhado, trilho de papel), caixas de seleção (X de goiva), chaves e barras de rolagem estão no tema (`Tela.tema()`).
Botões = etiquetas recortadas (apertado afunda), campos de texto = papel com filete, raridades das cartas na paleta
(`Tela.COR_RARIDADE`), minimapa = placa de tinta com anel duplo e pontos cardeais, tempo da partida em placa de tinta.

## Telas refeitas (escolha de herói, melhorias, multijogador, configurações)
- Escolha de herói: elenco em grade de retratos, **palco vivo** (`visual/PalcoGravura.gd`: o herói de verdade, animado, com golpes de vez em quando),
  ficha com **medidores entalhados** (`visual/Medidor.gd`) e a fileira de GOLPES com o ícone próprio de cada um.
- Melhorias: troca de herói por setas, palco vivo, recibos em duas colunas com fileira de níveis.
- Ícones de golpe: um objeto próprio por golpe (`visual/ObjetosGravura.gd`, 97 golpes, par objeto+tipo único) + efeito do tipo de ataque.
- Multijogador: ABRIR SALA (1 clique, abre a porta por UPnP) mostra um código curto (`Rede.codigo_de_ip`); quem entra digita o código.
- Configurações: abas laterais + página; **não existe mais opção de voltar ao visual antigo** (nem pixelado, nem 3D, nem sem-gravura).

## Regra de ouro da interface e do jogo: POUCAS TINTAS
Uma xilogravura é massa de tinta preta + linhas brancas entalhadas + papel + UMA cor de destaque. Por isso:
- **Interface:** blocos de tinta preta com filete branco entalhado (`StyleEntalhe.modo = 1`), papel com veio de madeira, e vermelho queimado como a
  cor de destaque. Azul e verde viram tinta preta; ocre só em detalhes. Pictogramas são **papel entalhado sobre disco preto**; títulos são bloco preto com letra de papel.
- **Jogo:** o pós-processamento (`shaders/papel.gdshader`) reduz TODA a imagem a 6 tintas (papel da fase, ocre, terracota, vermelho, azul, preto)
  — `chapa()` escolhe a mais próxima, pesando o brilho. O chão é papel claro com manchas; sombra vira hachura e massa preta.

## Acabamento: silhuetas, chefes, efeitos e transições
- **Silhueta própria** de cada personagem (`Modelo.FORMA`: largura × altura): o magro e alto (escritor, maestro, aviador), o parrudo (escultor, jiu-jitsu),
  o de saia rodada (maracatu, jongueira, benzedeira), o baixinho do mato (saci, curupira, caipora) e o gigante (lobisomem, mapinguari). A figura é impressa já com isso.
- **Chefe:** estrela de tinta no chão (`shaders/aura.gdshader`) com pontas vermelhas girando; enfurecido ela pulsa e as pontas crescem.
- **Impacto:** estrela gravada a cada golpe (vermelha e maior no crítico) e **riscos de movimento** (traços de tinta e papel) na arrancada. Morte: estrela maior.
- **Transição de página:** a folha do folheto vira ao iniciar a fase e entre as telas do menu.
- Teste visual: `godot --path godot -- --aura 1..4` (chefe da fase com aura, impactos e riscos), `--galeria`, `--chefe`.

## Base: como a xilogravura de cordel é feita (e como o jogo imita)
Fontes consultadas: descrições do processo em [Casa do Cordel](https://casadocordel.blogspot.com/2009/06/como-se-faz-uma-xilogravura.html),
[Enciclopédia Nordeste](https://enciclopedianordeste.com.br/xilogravura-de-cordel-a-arte-de-entalhar-historias-no-sertao/),
[Matéria Educativa](https://materiaeducativa.com.br/artes-e-cultura/cordel-xilogravura/) e o catálogo do IPHAN
([Mulheres na xilogravura](https://www.gov.br/iphan/pt-br/unidades-especiais/centro-nacional-de-folclore-e-cultura-popular/CatlogoOnlineMulheresnaxilogravuraSAP209.pdf)).
Não consegui ler textos acadêmicos sobre a linguagem visual; o que vai além do processo (hachura cavada, massas pretas,
chapa de cor desalinhada) vem do conhecimento geral da tradição, não de citação direta.

| Na gravura de verdade | No jogo (`shaders/papel.gdshader`, pós-processamento) |
|---|---|
| A matriz de madeira é entalhada com goiva/buril; só o relevo pega tinta, o cavado vira papel | A sombra vira **linhas cavadas** (hachura diagonal que engrossa com o escuro), nunca degradê |
| Entalhe feito a mão | Bordas levemente **trêmulas** (ondulação lenta) |
| A tinta não cobre por igual; a madeira tem veio | Pontinhos onde o papel aparece e **veio de madeira** nas áreas pretas |
| Papel poroso, grosso | Grão e fibras de papel por cima de tudo |
| Cordel é impresso em papel colorido; cor vem de outra chapa | **Papel colorido por fase** e chapa de cor **fora de registro** (3 px) em relação ao preto |
| Capa de folheto com filetes | Moldura de filete grosso + fino com cantos reforçados |

O jogador pode desligar em Opções → "Gravura de cordel" se quiser ver o mundo 3D sem a impressão.

## Onde mora cada coisa
| O quê | Arquivo |
|---|---|
| Paleta (e `Paleta.snap()`, que puxa qualquer cor pra paleta) | `scripts/visual/Paleta.gd` |
| Biblioteca de materiais (único lugar que cria material 3D) | `scripts/visual/Materiais.gd` |
| Cel shading + hachura + grão de papel | `shaders/xilogravura.gdshader` |
| Contorno de tinta (casca invertida, espessura irregular) | `shaders/contorno.gdshader` |
| Céu de papel com sol gravado | `shaders/ceu.gdshader` |
| Impressão de gravura sobre o jogo todo (por cima do 3D, abaixo da UI) | `shaders/papel.gdshader` |
| Peças primitivas (`Lib.cx/esf/caps/cil`) → entregam material de tinta | `scripts/Lib.gd` |

## Como criar coisa nova
- **Cor**: use `Paleta.X`. Se usar uma cor qualquer, `Lib.mat()` a puxa pra paleta sozinho.
- **Elemento de cenário** (árvore, casa, cerca): envolva a montagem em `Lib.contorno_mundo = 0.05` ... `= 0.0`
  e use `Lib.cx/esf/cil`. Veja `World._planta_obj` (mandacaru, xique-xique, juazeiro) e `World._montar_vilarejo`.
- **Boneco**: continua em `Boneco.gd` (o visual é independente da lógica; o resto do jogo só usa
  `animar/atacar/girar/bater`, `cor_base`, `tonto`). O contorno entra sozinho (`Lib.toon`).
- **Fogo/brilho**: passe `brilho > 0` em `Lib.*` — vira emissivo, sem sombra, sem hachura.
- **Luz**: `World._aplicar_luz()`. O sol do shader acompanha a luz direcional (`_atualizar_sol`).
- **Efeito de golpe**: `World._efeito_setor` (faixas tinta / cor / papel, borda serrilhada).

## Regras
- Poucas cores por elemento (2–3 + tinta). Cor demais vira ruído em combate.
- Silhueta primeiro: se não se reconhece em preto, o design não está pronto.
- Nada de gradiente suave no mundo 3D. Degrau, hachura e grão.

## Teste visual (sem abrir o jogo inteiro)
```
godot --path godot -- --shot cangaceiro   # cena de combate real, salva godot/shot_cangaceiro.png
godot --path godot -- --galeria           # fila de heróis
godot --path godot -- --tela coop         # qualquer tela de menu
```

## Fontes
Arvo Bold (texto) e Alfa Slab One (títulos), ambas licença OFL — arquivos e licenças em `art/fontes/`.

## Cuidado: cores nos shaders
O preto da tinta é constante linear (`TINTA`) dentro dos shaders. Não use `uniform ... : source_color` com valor padrão para a tinta: o padrão não é convertido e a tinta sai cinza.
