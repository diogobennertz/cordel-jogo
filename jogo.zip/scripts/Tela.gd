extends Node
class_name Tela
# Estilo de folheto de cordel para todas as telas: papel, tinta preta grossa, cores chapadas.
# A arte (logo, gravuras das cartas, bonecos, títulos entalhados) veio da versão 2D e fica em art/cordel.

# Paleta da interface = a paleta definitiva do jogo (ver visual/Paleta.gd)
const TINTA := Color("201A17")        # preto carvão
const PAPEL := Color("E8D7AE")        # branco envelhecido
const PAPEL2 := Color("D4C092")       # papel mais escuro (fundo de seleção)
const PARDO := Color("B8A47A")        # palha
const URUCUM := Color("A83226")       # vermelho queimado
const IPE := Color("D69A32")          # amarelo ocre
const ANIL := Color("201A17")         # (era azul) numa gravura as "cores frias" são a própria tinta preta
const MATA := Color("5C3526")         # terra escura (no lugar do verde)
const BARRO := Color("B26C47")        # terracota

static var _tex := {}
static var _tema: Theme
static var _f_txt: Font
static var _f_tit: Font

static func tex(nome: String) -> Texture2D:
	if _tex.has(nome): return _tex[nome]
	var cam := "res://art/cordel/%s.png" % nome
	var t: Texture2D = load(cam) if ResourceLoader.exists(cam) else null
	_tex[nome] = t
	return t

# Fontes embarcadas (licença OFL, ver art/fontes): Arvo Bold no texto e Alfa Slab One nos títulos — slab pesada de
# cartaz de cordel. Se algum símbolo faltar nelas, cai pra fonte do sistema.
static func fonte(titulo: bool = false) -> Font:
	if _f_txt == null:
		var sis := SystemFont.new(); sis.font_names = PackedStringArray(["Segoe UI Symbol", "Noto Sans Symbols2", "Arial", "Georgia"])
		var a: Font = load("res://art/fontes/Arvo-Bold.ttf")
		var b: Font = load("res://art/fontes/AlfaSlabOne-Regular.ttf")
		if a == null or b == null:     # segurança: se a fonte não carregar, volta ao jeito antigo
			a = SystemFont.new(); a.font_names = PackedStringArray(["Rockwell", "Georgia", "Times New Roman"]); a.font_weight = 700
			b = a
		else:
			a.fallbacks = [sis]; b.fallbacks = [sis]
		_f_txt = a; _f_tit = b
	return _f_tit if titulo else _f_txt

# --- peças de controle desenhadas à mão (marcador do slider, caixa de seleção, chave) ---
static func _textura_losango(fundo: Color, tam: int = 26) -> ImageTexture:
	var img := Image.create(tam, tam, false, Image.FORMAT_RGBA8)
	var c := (tam - 1) / 2.0
	for y in range(tam):
		for x in range(tam):
			var d := absf(x - c) + absf(y - c)
			if d <= c: img.set_pixel(x, y, TINTA if d > c - 3.6 else fundo)
	return ImageTexture.create_from_image(img)

static func _textura_caixa(marcada: bool, tam: int = 30) -> ImageTexture:
	var img := Image.create(tam, tam, false, Image.FORMAT_RGBA8)
	for y in range(tam):
		for x in range(tam):
			var borda := x < 3 or y < 3 or x >= tam - 3 or y >= tam - 3
			var sombra := (x >= tam - 1 or y >= tam - 1) and not borda
			img.set_pixel(x, y, TINTA if (borda or sombra) else Color("F6EBCB"))
	if marcada:                                       # X de goiva, dois riscos grossos e levemente tortos
		for i in range(5, tam - 5):
			for w in range(-2, 3):
				var a := Vector2i(i, clampi(i + w + (1 if i % 7 == 0 else 0), 4, tam - 5)); var b := Vector2i(i, clampi(tam - 1 - i + w - (1 if i % 5 == 0 else 0), 4, tam - 5))
				img.set_pixelv(a, URUCUM); img.set_pixelv(b, URUCUM)
	return ImageTexture.create_from_image(img)

static func _textura_chave(ligada: bool, larg: int = 56, alt: int = 28) -> ImageTexture:
	var img := Image.create(larg, alt, false, Image.FORMAT_RGBA8)
	for y in range(alt):
		for x in range(larg):
			var borda := x < 3 or y < 3 or x >= larg - 3 or y >= alt - 3
			img.set_pixel(x, y, TINTA if borda else (IPE if ligada else PARDO))
	var kx := larg - 3 - 20 if ligada else 5
	for y in range(5, alt - 5):
		for x in range(kx, kx + 20):
			var d := absf(x - (kx + 9.5)) * 1.0 + absf(y - (alt - 1) / 2.0) * 1.35
			if d < 11.0: img.set_pixel(x, y, TINTA if d > 8.2 else (URUCUM if ligada else PAPEL))
	return ImageTexture.create_from_image(img)

static func tema() -> Theme:
	if _tema == null:
		_tema = Theme.new(); _tema.default_font = fonte(); _tema.default_font_size = 16
		# campos de texto: papel claro com contorno de tinta (foco = vermelho queimado), nada do cinza padrão
		var le := caixa(Color("F6EBCB"), 3, TINTA, 0); le.filete = false; le.set_content_margin_all(8)
		var lef := caixa(Color("FBF3DA"), 4, URUCUM, 0); lef.filete = false; lef.set_content_margin_all(8)
		_tema.set_stylebox("normal", "LineEdit", le); _tema.set_stylebox("focus", "LineEdit", lef); _tema.set_stylebox("read_only", "LineEdit", le)
		_tema.set_color("font_color", "LineEdit", TINTA); _tema.set_color("font_placeholder_color", "LineEdit", Color(TINTA.r, TINTA.g, TINTA.b, 0.5))
		_tema.set_color("caret_color", "LineEdit", URUCUM); _tema.set_color("selection_color", "LineEdit", Color(IPE.r, IPE.g, IPE.b, 0.6))
		# slider: trilho de papel com filete, parte cheia em vermelho queimado e marcador em losango entalhado
		var tr_ := caixa(PAPEL2, 3, TINTA, 0); tr_.filete = false; tr_.content_margin_top = 6; tr_.content_margin_bottom = 6
		var ch_ := caixa(URUCUM, 3, TINTA, 0); ch_.filete = false; ch_.content_margin_top = 6; ch_.content_margin_bottom = 6
		for cls: String in ["HSlider", "VSlider"]:
			_tema.set_stylebox("slider", cls, tr_); _tema.set_stylebox("grabber_area", cls, ch_); _tema.set_stylebox("grabber_area_highlight", cls, ch_)
			_tema.set_icon("grabber", cls, _textura_losango(IPE)); _tema.set_icon("grabber_highlight", cls, _textura_losango(URUCUM)); _tema.set_icon("grabber_disabled", cls, _textura_losango(PARDO))
		# caixa de seleção (X de goiva) e chave (tábua com bloco)
		for cls: String in ["CheckBox", "CheckButton"]:
			_tema.set_color("font_color", cls, TINTA); _tema.set_color("font_hover_color", cls, URUCUM); _tema.set_color("font_pressed_color", cls, TINTA)
			_tema.set_color("font_hover_pressed_color", cls, URUCUM); _tema.set_color("font_focus_color", cls, TINTA)
			_tema.set_stylebox("normal", cls, StyleBoxEmpty.new()); _tema.set_stylebox("hover", cls, StyleBoxEmpty.new()); _tema.set_stylebox("pressed", cls, StyleBoxEmpty.new()); _tema.set_stylebox("focus", cls, StyleBoxEmpty.new())
			_tema.set_constant("h_separation", cls, 12)
		_tema.set_icon("checked", "CheckBox", _textura_caixa(true)); _tema.set_icon("unchecked", "CheckBox", _textura_caixa(false))
		_tema.set_icon("checked_disabled", "CheckBox", _textura_caixa(true)); _tema.set_icon("unchecked_disabled", "CheckBox", _textura_caixa(false))
		_tema.set_icon("checked", "CheckButton", _textura_chave(true)); _tema.set_icon("unchecked", "CheckButton", _textura_chave(false))
		_tema.set_icon("checked_disabled", "CheckButton", _textura_chave(true)); _tema.set_icon("unchecked_disabled", "CheckButton", _textura_chave(false))
		# barras de rolagem: trilho de papel e pegador de tinta
		for cls: String in ["VScrollBar", "HScrollBar"]:
			var vertical: bool = (cls == "VScrollBar")
			var tr2 := caixa(PAPEL2, 2, TINTA, 0); tr2.filete = false
			var g1 := caixa(TINTA, 2, TINTA, 0); g1.filete = false
			var g2 := caixa(URUCUM, 2, TINTA, 0); g2.filete = false
			var g3 := caixa(IPE, 2, TINTA, 0); g3.filete = false
			for st in [tr2, g1, g2, g3]:
				st.content_margin_left = 6 if vertical else 2; st.content_margin_right = 6 if vertical else 2
				st.content_margin_top = 2 if vertical else 6; st.content_margin_bottom = 2 if vertical else 6
			_tema.set_stylebox("scroll", cls, tr2); _tema.set_stylebox("scroll_focus", cls, tr2)
			_tema.set_stylebox("grabber", cls, g1); _tema.set_stylebox("grabber_highlight", cls, g2); _tema.set_stylebox("grabber_pressed", cls, g3)
	return _tema

# caixa de papel recortado com borda de tinta e sombra chapada (StyleEntalhe). `raio` não existe mais (cantos chanfrados).
static var _semente := 1
static func caixa(fundo: Color, borda: int = 4, cor_borda: Color = TINTA, sombra: int = 5, raio: int = 5) -> StyleEntalhe:
	var e := StyleEntalhe.new()
	_semente += 1
	e.semente = _semente % 9 + 1
	e.fundo = fundo; e.tinta = cor_borda; e.borda = float(borda); e.sombra = float(sombra)
	e.set_content_margin_all(10)
	# massa de tinta preta -> bloco com filete branco; cor saturada -> tinta hachurada; claro -> papel
	if fundo.a > 0.05:
		if fundo.get_luminance() < 0.14: e.modo = 1
		elif fundo.s > 0.30 and fundo.get_luminance() < 0.55: e.modo = 2
	return e

static func rotulo(txt: String, tam: int = 16, cor: Color = TINTA, al: int = HORIZONTAL_ALIGNMENT_CENTER, titulo: bool = false) -> Label:
	var l := Label.new(); l.text = txt
	l.add_theme_font_override("font", fonte(titulo))
	l.add_theme_font_size_override("font_size", tam)
	l.add_theme_color_override("font_color", cor)
	l.horizontal_alignment = al
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

static func texto(txt: String, tam: int, largura: float, cor: Color = TINTA, al: int = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := rotulo(txt, tam, cor, al)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(largura, 0)
	return l

# botão de etiqueta recortada: bloco de cor com contorno de tinta; ao passar o mouse vira ocre; apertado, afunda (sem sombra)
static func botao(txt: String, acao: Callable, tam: int = 20, fundo: Color = URUCUM, largura: float = 280.0, altura: float = 50.0, emblema: bool = false) -> Button:
	var b := Button.new(); b.text = txt
	b.custom_minimum_size = Vector2(largura, altura)
	b.add_theme_font_override("font", fonte(true)); b.add_theme_font_size_override("font_size", tam)
	if fundo == ANIL or fundo == MATA: fundo = TINTA        # numa gravura azul e verde viram a tinta preta
	elif fundo == BARRO or fundo == IPE: fundo = URUCUM
	var n := caixa(fundo, 4, TINTA, 5); n.filete = false; n.set_content_margin_all(6)
	var h := caixa(URUCUM if fundo != URUCUM else TINTA, 4, TINTA, 5); h.filete = false; h.set_content_margin_all(6)        # passar o mouse inverte a chapa
	var pr := caixa(URUCUM if fundo != URUCUM else TINTA, 4, TINTA, 1); pr.filete = false; pr.set_content_margin_all(6)
	var ds := caixa(PARDO, 3, Color(TINTA.r, TINTA.g, TINTA.b, 0.5), 0); ds.filete = false; ds.set_content_margin_all(6)
	b.add_theme_stylebox_override("normal", n); b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", pr); b.add_theme_stylebox_override("disabled", ds)
	var foco := StyleBoxFlat.new(); foco.draw_center = false; foco.border_color = TINTA; foco.set_border_width_all(3); foco.set_corner_radius_all(0); foco.set_expand_margin_all(7)
	b.add_theme_stylebox_override("focus", foco)
	b.focus_mode = Control.FOCUS_ALL if Ctrl.tem_controle() else Control.FOCUS_NONE
	var claro := fundo.get_luminance() < 0.42
	b.add_theme_color_override("font_color", PAPEL if claro else TINTA)
	for c in ["font_hover_color", "font_pressed_color", "font_hover_pressed_color"]:
		b.add_theme_color_override(c, PAPEL)
	b.add_theme_color_override("font_focus_color", PAPEL if claro else TINTA)
	b.add_theme_color_override("font_disabled_color", Color(TINTA.r, TINTA.g, TINTA.b, 0.6))
	b.add_theme_color_override("font_outline_color", TINTA if claro else Color(1, 1, 1, 0))
	b.add_theme_constant_override("outline_size", 3 if claro else 0)
	if emblema:        # losangos de enfeite nas pontas, como etiqueta de folheto
		b.draw.connect(_emblemas.bind(b, PAPEL if claro else TINTA))
	b.pressed.connect(func(): Som.tocar("clique"))
	b.pressed.connect(acao)
	return b

static func imagem(nome: String, tam: Vector2) -> TextureRect:
	if nome.begins_with("a_"): return IconeGravura.novo(nome.substr(2), tam)       # ícones de carta/habilidade: gravura vetorial
	var t := TextureRect.new(); t.texture = tex(nome)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.custom_minimum_size = tam; t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t

# título de folheto (texto de verdade, em letras de relevo); `altura` ≈ tamanho da letra. As chaves antigas das imagens
# continuam valendo, então quem chama não muda.
const TITULOS := {"t_cordel": "CORDEL", "t_heroi": "ESCOLHA SEU HERÓI", "t_fase": "ESCOLHA A FASE", "t_melhorias": "MELHORIAS",
	"t_nivel": "SUBIU DE NÍVEL!", "t_opcoes": "OPÇÕES", "t_pausa": "PAUSA", "t_caiu": "VOCÊ CAIU NA MATA", "t_venceu": "VOCÊ VENCEU!"}
# cores de raridade das cartas, na paleta de pigmentos (comum, incomum, rara, épica, lendária, mítica)
const COR_RARIDADE := [Color("D4C092"), Color("B26C47"), Color("31566B"), Color("6F2924"), Color("D69A32"), Color("A83226")]

# `claro`: título sobre fundo escuro (letra de papel com relevo ocre)
static func titulo(nome: String, altura: float, claro: bool = false) -> Control:
	var txt: String = TranslationServer.translate(TITULOS.get(nome, nome))
	return TituloGravado.novo(txt, altura * 0.68, PAPEL, URUCUM, true, true)

# fundo de página de folheto: papel poroso com moldura de duas linhas e uma faixa de dentes entalhados entre elas
static func fundo_papel(pai: Control, cor: Color = Color(1, 1, 1), rico: bool = true) -> void:
	var base := ColorRect.new(); base.color = PAPEL; base.set_anchors_preset(Control.PRESET_FULL_RECT); pai.add_child(base)
	var p := TextureRect.new(); p.texture = tex("papel"); p.stretch_mode = TextureRect.STRETCH_TILE
	p.set_anchors_preset(Control.PRESET_FULL_RECT); p.modulate = cor; p.mouse_filter = Control.MOUSE_FILTER_IGNORE; pai.add_child(p)
	var mo := ColorRect.new(); mo.set_anchors_preset(Control.PRESET_FULL_RECT); mo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m := ShaderMaterial.new(); m.shader = load("res://shaders/moldura_rica.gdshader" if rico else "res://shaders/moldura.gdshader"); mo.material = m; pai.add_child(mo)
	if not rico: _cantos_cordel(pai)

# enfeite nos 4 cantos, tipo xilogravura de folheto de cordel (estrela, sol, cacto, passarinho)
static func _cantos_cordel(pai: Control) -> void:
	var cantos := [
		["orna_passaro", Control.PRESET_TOP_LEFT, Vector2(26, 24), Vector2(76, 60)],
		["orna_sol", Control.PRESET_TOP_RIGHT, Vector2(-60, 6), Vector2(34, 34)],
		["orna_cacto", Control.PRESET_BOTTOM_LEFT, Vector2(30, -148), Vector2(60, 90)],
		["orna_estrela", Control.PRESET_BOTTOM_RIGHT, Vector2(-80, -84), Vector2(56, 56)],
	]
	for c in cantos:
		var t := imagem(c[0], c[3]); t.set_anchors_preset(c[1])
		t.position = c[2]; t.modulate = Color(TINTA.r, TINTA.g, TINTA.b, 0.8)
		pai.add_child(t)

static func escuro(pai: Control, a: float = 0.72) -> void:
	var f := ColorRect.new(); f.color = Color.WHITE
	var m := ShaderMaterial.new(); m.shader = load("res://shaders/escuro.gdshader"); m.set_shader_parameter("forca", a); f.material = m
	f.set_anchors_preset(Control.PRESET_FULL_RECT); f.mouse_filter = Control.MOUSE_FILTER_STOP; pai.add_child(f)

static func painel(fundo: Color = PAPEL, borda: int = 5) -> PanelContainer:
	var p := PanelContainer.new()
	var s := caixa(fundo, borda, TINTA, 8); s.set_content_margin_all(24); s.ornamento = true
	p.add_theme_stylebox_override("panel", s)
	return p

# faixa de aviso: tarja de cor entre dois filetes, como cartela de folheto
static func faixa(txt: String, fundo: Color, tam: int = 16, cor_txt: Color = PAPEL) -> PanelContainer:
	var p := PanelContainer.new()
	if fundo == ANIL or fundo == MATA: fundo = TINTA
	elif fundo == BARRO: fundo = URUCUM
	elif fundo == IPE and cor_txt == PAPEL: fundo = TINTA
	var s := caixa(fundo, 3, TINTA, 3); s.filete = fundo != TINTA; s.set_content_margin_all(6)
	p.add_theme_stylebox_override("panel", s); p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(rotulo(txt, tam, cor_txt, HORIZONTAL_ALIGNMENT_CENTER, true))
	return p

# separador ornamental: filete com losango no meio
static func _emblemas(b: Button, cor: Color) -> void:
	var h := b.size.y * 0.5
	var d := minf(7.0, b.size.y * 0.17)
	for x in [18.0, b.size.x - 18.0]:
		b.draw_colored_polygon(PackedVector2Array([Vector2(x, h - d), Vector2(x + d, h), Vector2(x, h + d), Vector2(x - d, h)]), cor)

static var _mat_barra: ShaderMaterial
# material de hachura pras barras do HUD (um só, compartilhado)
static func material_hachura() -> ShaderMaterial:
	if _mat_barra == null:
		_mat_barra = ShaderMaterial.new(); _mat_barra.shader = load("res://shaders/barra.gdshader")
	return _mat_barra

static func separador(largura: float = 260.0) -> Control:
	var c := Control.new(); c.custom_minimum_size = Vector2(largura, 18); c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.draw.connect(func():
		var y := c.size.y * 0.5; var cx := c.size.x * 0.5
		c.draw_line(Vector2(6, y), Vector2(cx - 16, y), TINTA, 3.0); c.draw_line(Vector2(cx + 16, y), Vector2(c.size.x - 6, y), TINTA, 3.0)
		c.draw_line(Vector2(6, y + 5), Vector2(cx - 22, y + 5), TINTA, 1.2); c.draw_line(Vector2(cx + 22, y + 5), Vector2(c.size.x - 6, y + 5), TINTA, 1.2)
		c.draw_colored_polygon(PackedVector2Array([Vector2(cx, y - 8), Vector2(cx + 9, y), Vector2(cx, y + 8), Vector2(cx - 9, y)]), URUCUM)
		c.draw_polyline(PackedVector2Array([Vector2(cx, y - 8), Vector2(cx + 9, y), Vector2(cx, y + 8), Vector2(cx - 9, y), Vector2(cx, y - 8)]), TINTA, 2.0))
	return c

static func ignora_mouse(n: Node) -> void:
	for c in n.get_children():
		if c is Control: c.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ignora_mouse(c)

# número grande legível: 950, 12.4 mil, 3.25 mi, 1.2 bi
static func num(v: float) -> String:
	if v < 1000.0: return str(int(round(v)))
	if v < 1e6: return "%.1f mil" % (v / 1e3)
	if v < 1e9: return "%.2f mi" % (v / 1e6)
	return "%.2f bi" % (v / 1e9)

# ---- opções (volume, mouse, câmera, tela cheia) ----
static func opc(k: String) -> float:
	return float(Salvo.d["opcoes"].get(k, Salvo.OPCOES[k]))

static func _bus(nome: String) -> int:
	var i := AudioServer.get_bus_index(nome)
	if i < 0:
		AudioServer.add_bus(); i = AudioServer.bus_count - 1
		AudioServer.set_bus_name(i, nome); AudioServer.set_bus_send(i, "Master")
	return i

static func aplicar_opcoes() -> void:
	for par in [["Master", "geral"], ["Musica", "musica"], ["Efeitos", "efeitos"]]:
		var i := _bus(par[0]); var v := opc(par[1])
		AudioServer.set_bus_mute(i, v <= 0.001)
		AudioServer.set_bus_volume_db(i, linear_to_db(maxf(v, 0.001)))
	TranslationServer.set_locale(String(Salvo.d.get("idioma", "pt_BR")))
	if DisplayServer.get_name() != "headless" and not Salvo.desligado:
		var quer := DisplayServer.WINDOW_MODE_FULLSCREEN if opc("cheia") > 0.5 else DisplayServer.WINDOW_MODE_WINDOWED
		if DisplayServer.window_get_mode() != quer and not (quer == DisplayServer.WINDOW_MODE_WINDOWED and DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_MAXIMIZED):
			DisplayServer.window_set_mode(quer)
