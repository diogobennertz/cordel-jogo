extends CanvasLayer
class_name Menus
# Todas as telas do jogo no estilo folheto de cordel: capa (título), escolha do herói e da fase,
# melhorias, opções, pausa (ESC), cartas de subir de nível e fim da partida.

var w                         # o mundo
var raiz: Control
var tela := ""                # titulo | herois | melhorias | opcoes | pausa | nivel | fim | ""
var _volta: Callable          # para onde as opções voltam
var _aba := "som"
var _queimando := false        # tela de nível: o próximo folheto clicado vai pro fogo
var _cartas: Array = []       # [carta, botão] da tela de nível, para as teclas 1, 2, 3
var _heroi_nv                 # herói que está subindo de nível
var _abriu := 0
var _capt := ""               # ação esperando uma tecla nova (opções > controles)               # quando a tela de nível abriu (evita clique sem querer)
var _so_tutorial := false     # true: foi pro "escolha de herói" só pra fazer o tutorial (não pra jogar a fase)
var _scr_herois: ScrollContainer   # só pra debug/teste
var _painel_dica: PanelContainer   # dica de como liberar o herói trancado (some ao passar o mouse)
var _lbl_dica: Label

func _init() -> void:
	layer = 10

var _rede_erro := ""
func _ready() -> void:
	raiz = Control.new(); raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	raiz.theme = Tela.tema(); raiz.visible = false
	add_child(raiz)
	Rede.entrou.connect(func(_id): if tela == "coop": coop())
	Rede.saiu.connect(func(_id): if tela == "coop": coop())
	Rede.falhou.connect(func(msg): _rede_erro = msg; coop())
	Rede.mundos_mudaram.connect(func(): if tela == "coop" and not Rede.ativo(): coop())

func _recarregar_coop() -> void:
	if tela == "coop": coop()

func _limpar(nome: String) -> void:
	if tela != "" and nome != "" and tela != nome and w.estado == "menu" and nome in ["herois", "melhorias", "feitos", "coop", "opcoes", "titulo"]:
		w._transicao_pagina(0.55)             # a página do folheto vira entre as telas
	for c in raiz.get_children(): c.queue_free()
	_cartas = []
	tela = nome
	raiz.visible = nome != ""
	if nome != "" and Ctrl.tem_controle(): _foco.call_deferred()

# com controle ligado, o primeiro botão da tela já fica escolhido (A confirma, direcional anda)
func _foco() -> void:
	var b := _primeiro(raiz)
	if b: b.grab_focus()

func _primeiro(n: Node) -> Button:
	for c in n.get_children():
		if c.is_queued_for_deletion(): continue
		if c is Button and not c.disabled:
			c.focus_mode = Control.FOCUS_ALL; return c
		var r := _primeiro(c)
		if r: return r
	return null

func fechar() -> void:
	_limpar("")

func _centro(sep: int = 10) -> VBoxContainer:
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", sep); cc.add_child(vb)
	return vb

func _linha(pai: Control, sep: int = 14) -> HBoxContainer:
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", sep)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER; pai.add_child(hb)
	return hb

func _moedas_tag(esquerda: bool = false) -> void:
	var p := PanelContainer.new()
	var s := Tela.caixa(Tela.TINTA, 3, Tela.TINTA, 4); s.set_content_margin_all(8); s.content_margin_left = 16; s.content_margin_right = 16
	p.add_theme_stylebox_override("panel", s)
	p.add_child(Tela.rotulo(tr("◉ %d moedas") % int(Salvo.d["moedas"]), 20, Tela.PAPEL, HORIZONTAL_ALIGNMENT_CENTER, true))
	if esquerda:
		p.set_anchors_preset(Control.PRESET_TOP_LEFT)
		p.offset_left = 50; p.offset_right = 250; p.offset_top = 26; p.offset_bottom = 66
	else:
		p.set_anchors_preset(Control.PRESET_TOP_RIGHT)
		p.offset_left = -262; p.offset_right = -60; p.offset_top = 56; p.offset_bottom = 98
		p.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	raiz.add_child(p)

# ---------------- capa ----------------
func titulo() -> void:
	_limpar("titulo")
	Tela.fundo_papel(raiz, Color(1, 1, 1), true)
	var cols := HBoxContainer.new(); cols.set_anchors_preset(Control.PRESET_FULL_RECT)
	cols.offset_left = 66; cols.offset_right = -66; cols.offset_top = 62; cols.offset_bottom = -58
	cols.add_theme_constant_override("separation", 30); raiz.add_child(cols)
	# ---------- página da esquerda: a gravura de abertura, em moldura dupla ----------
	var esq := VBoxContainer.new(); esq.alignment = BoxContainer.ALIGNMENT_CENTER; esq.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	esq.add_theme_constant_override("separation", 8); cols.add_child(esq)
	var faixa_t := Tela.faixa(tr("A PELEJA DOS LENDÁRIOS DO BRASIL"), Tela.URUCUM, 15, Tela.PAPEL); esq.add_child(faixa_t)
	var ext := PanelContainer.new(); var se := Tela.caixa(Tela.PAPEL2, 6, Tela.TINTA, 7); se.ornamento = true; se.set_content_margin_all(12)
	ext.add_theme_stylebox_override("panel", se); esq.add_child(ext)
	var inte := PanelContainer.new(); var si := Tela.caixa(Tela.TINTA, 3, Tela.TINTA, 0); si.filete = false; si.set_content_margin_all(6)
	inte.add_theme_stylebox_override("panel", si); ext.add_child(inte)
	var vin := VinhetaCapa.new(); vin.custom_minimum_size = Vector2(560, 372); inte.add_child(vin)
	esq.add_child(Tela.rotulo(tr("Sobreviva 10 minutos, vença o chefe e aguente o quanto der."), 13, Tela.TINTA))
	var preco := PanelContainer.new(); var sp := Tela.caixa(Tela.TINTA, 3, Tela.TINTA, 4); sp.set_content_margin_all(5); sp.content_margin_left = 16; sp.content_margin_right = 16
	preco.add_theme_stylebox_override("panel", sp); preco.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	preco.add_child(Tela.rotulo(tr("PREÇO: ◉ %d moedas") % int(Salvo.d["moedas"]), 16, Tela.PAPEL, HORIZONTAL_ALIGNMENT_CENTER, true))
	esq.add_child(preco)
	# ---------- página da direita: o cabeçalho de folheto e o menu ----------
	var dir := VBoxContainer.new(); dir.alignment = BoxContainer.ALIGNMENT_CENTER; dir.custom_minimum_size = Vector2(500, 0)
	dir.add_theme_constant_override("separation", 6); cols.add_child(dir)
	dir.add_child(Tela.rotulo(tr("LITERATURA DE CORDEL"), 15, Tela.URUCUM, HORIZONTAL_ALIGNMENT_CENTER, true))
	dir.add_child(Tela.separador(420.0))
	dir.add_child(TituloGravado.novo("CORDEL", 80.0, Tela.PAPEL, Tela.URUCUM, false, true))
	dir.add_child(Tela.faixa(tr("LENDAS DO BRASIL"), Tela.TINTA, 17, Tela.PAPEL))
	# sextilha de abertura, como no miolo de um folheto
	var pv := PanelContainer.new(); var sv := Tela.caixa(Color("F6EBCB"), 3, Tela.TINTA, 0); sv.set_content_margin_all(9); pv.add_theme_stylebox_override("panel", sv)
	pv.add_child(Tela.texto(tr("Vem ouvir, meu povo amigo,\na peleja do sertão:\nSaci, Mula e Curupira\ndão pinote no chão,\nmas cangaceiro e baiana\nsegura a tradição."), 13, 430))
	dir.add_child(pv)
	dir.add_child(Tela.separador(420.0))
	var ac_opc := func(): opcoes(titulo)
	var ac_sair := func(): get_tree().quit()
	var ac_tut := func(): _so_tutorial = true; herois()
	var ac_jogar_menu := func(): _so_tutorial = false; herois()
	var b1 := Tela.botao(tr("UM JOGADOR"), ac_jogar_menu, 24, Tela.URUCUM, 500.0, 50.0, true); b1.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; dir.add_child(b1)
	var b2 := Tela.botao(tr("MULTIJOGADOR (LAN)"), coop, 22, Tela.ANIL, 500.0, 46.0, true); b2.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; dir.add_child(b2)
	var feitos_txt := tr("FEITOS") + (tr(" (%d)") % Dados.feitos_prontos() if Dados.feitos_prontos() > 0 else "")
	var l3 := HBoxContainer.new(); l3.alignment = BoxContainer.ALIGNMENT_CENTER; l3.add_theme_constant_override("separation", 10); dir.add_child(l3)
	l3.add_child(Tela.botao(tr("MELHORIAS"), melhorias, 16, Tela.TINTA, 245.0, 40.0, true))
	l3.add_child(Tela.botao(feitos_txt, feitos, 16, Tela.TINTA, 245.0, 40.0, true))
	var l4 := HBoxContainer.new(); l4.alignment = BoxContainer.ALIGNMENT_CENTER; l4.add_theme_constant_override("separation", 10); dir.add_child(l4)
	l4.add_child(Tela.botao(tr("TUTORIAL"), ac_tut, 15, Tela.PAPEL2, 160.0, 36.0))
	l4.add_child(Tela.botao(tr("OPÇÕES"), ac_opc, 15, Tela.PAPEL2, 160.0, 36.0))
	l4.add_child(Tela.botao(tr("SAIR"), ac_sair, 15, Tela.PAPEL2, 160.0, 36.0))

# ---------------- escolha do herói e da fase ----------------
func herois() -> void:
	if not Dados.heroi_desbloqueado(w.sel_heroi): w.sel_heroi = "capoeirista"   # nunca fica selecionado um herói trancado
	_limpar("herois")
	Tela.fundo_papel(raiz, Color(1, 1, 1), false)
	var vb := VBoxContainer.new(); vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 40; vb.offset_right = -40; vb.offset_top = 20; vb.offset_bottom = -16
	vb.add_theme_constant_override("separation", 4); raiz.add_child(vb)
	var tit := Tela.titulo("t_heroi", 36); vb.add_child(tit)
	if _so_tutorial: vb.add_child(Tela.rotulo(tr("escolha quem vai fazer o tutorial"), 15, Tela.URUCUM, HORIZONTAL_ALIGNMENT_CENTER, true))
	var c: Dictionary = Dados.CLASSES[w.sel_heroi]
	var meio := HBoxContainer.new(); meio.alignment = BoxContainer.ALIGNMENT_CENTER; meio.add_theme_constant_override("separation", 18); vb.add_child(meio)
	# ---- esquerda: elenco (lista com etiquetas; rola quando tiver muitos) ----
	var caixa_l := PanelContainer.new(); var sl := Tela.caixa(Tela.PAPEL2, 4, Tela.TINTA, 5); sl.set_content_margin_all(8); caixa_l.add_theme_stylebox_override("panel", sl); meio.add_child(caixa_l)
	var vl := VBoxContainer.new(); vl.add_theme_constant_override("separation", 4); caixa_l.add_child(vl)
	vl.add_child(Tela.rotulo(tr("ELENCO"), 14, Tela.URUCUM, HORIZONTAL_ALIGNMENT_CENTER, true))
	var scr := ScrollContainer.new(); scr.custom_minimum_size = Vector2(334, 300)
	scr.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED; vl.add_child(scr)
	_scr_herois = scr   # só pra debug/teste (rolar até os trancados num print)
	var gr := GridContainer.new(); gr.columns = 4
	gr.add_theme_constant_override("h_separation", 6); gr.add_theme_constant_override("v_separation", 6); scr.add_child(gr)
	for id in Dados.CLASSES: gr.add_child(_chip_heroi(id))
	# ---- centro: o palco, com o herói grande ----
	var centro := VBoxContainer.new(); centro.add_theme_constant_override("separation", 4); meio.add_child(centro)
	centro.add_child(Tela.faixa(String(c["apelido"]).to_upper(), Paleta.snap(c["cor"]).lerp(Tela.IPE, 0.4), 17, Tela.TINTA))
	var palco_box := PanelContainer.new(); var sp := Tela.caixa(Tela.TINTA, 3, Tela.TINTA, 6); sp.filete = false; sp.set_content_margin_all(5); palco_box.add_theme_stylebox_override("panel", sp)
	palco_box.add_child(PalcoGravura.novo(w.sel_heroi, Vector2(300, 282), Paleta.snap(c["cor"]).lerp(Tela.IPE, 0.35), false, true))
	centro.add_child(palco_box)
	centro.add_child(Tela.rotulo(String(c["nome"]), 15, Tela.URUCUM, HORIZONTAL_ALIGNMENT_CENTER, true))
	# ---- direita: a ficha ----
	meio.add_child(_ficha_heroi(w.sel_heroi))
	# dica de como liberar herói trancado: espaço reservado sempre, só preenche ao passar o mouse
	_lbl_dica = Tela.rotulo("", 14, Tela.PAPEL, HORIZONTAL_ALIGNMENT_CENTER, true)
	_painel_dica = PanelContainer.new(); _painel_dica.custom_minimum_size = Vector2(0, 26)
	_painel_dica.add_theme_stylebox_override("panel", StyleBoxEmpty.new())
	_painel_dica.add_child(_lbl_dica); _painel_dica.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(_painel_dica)
	# fileira de fases: rola na horizontal, porque já são 15 e não cabem todas na tela de uma vez
	var scrf := ScrollContainer.new(); scrf.custom_minimum_size = Vector2(1180, 90)
	scrf.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED; vb.add_child(scrf)
	var hf := HBoxContainer.new(); hf.add_theme_constant_override("separation", 12); scrf.add_child(hf)
	var fmax: int = mini(int(Salvo.d["fase_max"]), Dados.FASES.size() - 1)
	w.sel_fase = clampi(w.sel_fase, 0, fmax)
	for i in range(Dados.FASES.size()): hf.add_child(_carta_fase(i, fmax))
	var hbt := _linha(vb, 16)
	hbt.add_child(Tela.botao(tr("VOLTAR"), titulo, 18, Tela.PARDO, 200.0, 46.0))
	var ac_jogar := func():
		if _so_tutorial:
			Salvo.d["tutorial"] = true; Salvo.salvar(); w.iniciar_jogo(w.sel_heroi, 0, true)
		elif bool(Salvo.d["tutorial"]): w.iniciar_jogo(w.sel_heroi, w.sel_fase, false)
		else: perguntar_tutorial()
	hbt.add_child(Tela.botao(tr("FAZER O TUTORIAL") if _so_tutorial else tr("JOGAR"), ac_jogar, 26, Tela.URUCUM, 360.0, 46.0, true))
	_moedas_tag(true)

# etiqueta clicável de cada herói no elenco (retrato pequeno + nome); trancado = silhueta preta
func _chip_heroi(id: String) -> Button:
	var c: Dictionary = Dados.CLASSES[id]
	var sel: bool = id == w.sel_heroi
	var trancado: bool = not Dados.heroi_desbloqueado(id)
	var b := Button.new(); b.custom_minimum_size = Vector2(76, 98); b.clip_contents = true
	_estilo_carta(b, sel)
	var v := _miolo(b, 4, 0)
	var moldura := Panel.new(); moldura.custom_minimum_size = Vector2(62, 70); moldura.clip_contents = true
	moldura.add_theme_stylebox_override("panel", Tela.caixa(Tela.PAPEL, 2, Tela.TINTA, 3))   # o retrato sozinho ficava "solto"
	var ret := _retrato_heroi(id, Vector2(58, 66)); ret.position = Vector2(2, 2)
	if trancado: ret.modulate = Color(0.03, 0.03, 0.03)
	moldura.add_child(ret)
	v.add_child(moldura)
	var nome_curto := String(c["apelido"]).split(" ")[0]
	v.add_child(Tela.rotulo(nome_curto, 10, Tela.URUCUM if sel else Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	b.tooltip_text = String(c["apelido"])
	Tela.ignora_mouse(b)
	if trancado:
		var req := "🔒 Para liberar " + String(c["apelido"]) + ": " + Dados.requisito_heroi(id)
		b.tooltip_text = req
		b.mouse_entered.connect(func():
			_lbl_dica.text = req
			_painel_dica.add_theme_stylebox_override("panel", Tela.caixa(Tela.TINTA, 3, Tela.URUCUM, 4)))
		b.mouse_exited.connect(func():
			_lbl_dica.text = ""
			_painel_dica.add_theme_stylebox_override("panel", StyleBoxEmpty.new()))
	else:
		b.pressed.connect(func():
			w.sel_heroi = id; Salvo.d["heroi"] = id; herois())
	return b

# pergunta (só na primeira vez) se a pessoa quer fazer o tutorial antes da 1ª fase
func perguntar_tutorial() -> void:
	_limpar("pergtut")
	Tela.escuro(raiz, 0.72)
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var p := Tela.painel(Color(1.0, 0.97, 0.86)); cc.add_child(p)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 16); p.add_child(vb)
	vb.add_child(Tela.rotulo("Quer fazer um tutorial rápido antes de começar?", 22, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	vb.add_child(Tela.texto("Ensina os controles e como o jogo funciona. Pode jogar de novo quando quiser, pelo menu principal.", 14, 480))
	var hb := _linha(vb, 16)
	var ac_sim := func():
		Salvo.d["tutorial"] = true; Salvo.salvar(); w.iniciar_jogo(w.sel_heroi, w.sel_fase, true)
	var ac_nao := func():
		Salvo.d["tutorial"] = true; Salvo.salvar(); w.iniciar_jogo(w.sel_heroi, w.sel_fase, false)
	hb.add_child(Tela.botao("SIM", ac_sim, 20, Tela.URUCUM, 190.0, 50.0))
	hb.add_child(Tela.botao("NÃO", ac_nao, 20, Tela.PARDO, 190.0, 50.0))

func _estilo_carta(b: Button, marcado: bool, fundo: Color = Tela.PAPEL) -> void:
	var claro := Color(1.0, 0.97, 0.86)
	b.add_theme_stylebox_override("normal", Tela.caixa(claro if marcado else fundo, 7 if marcado else 4, Tela.URUCUM if marcado else Tela.TINTA, 8 if marcado else 5))
	b.add_theme_stylebox_override("hover", Tela.caixa(claro, 7 if marcado else 5, Tela.URUCUM if marcado else Tela.IPE.darkened(0.15), 8))
	b.add_theme_stylebox_override("pressed", Tela.caixa(claro, 6, Tela.URUCUM, 2))
	b.add_theme_stylebox_override("disabled", Tela.caixa(Tela.PARDO, 3, Color(0.1, 0.07, 0.05, 0.5), 0))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())

func _miolo(b: Button, margem: int = 10, sep: int = 5) -> VBoxContainer:
	var m := MarginContainer.new(); m.set_anchors_preset(Control.PRESET_FULL_RECT)
	for lado in ["left", "right", "top", "bottom"]: m.add_theme_constant_override("margin_" + lado, margem)
	b.add_child(m)
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", sep); m.add_child(v)
	return v

func _pct(v: float) -> String:
	return tr("%d%%") % int(round(v * 100.0))

# ficha completa de quem está selecionado: descrição, medidores entalhados, golpe inicial e habilidades Q/R
func _ficha_heroi(id: String) -> PanelContainer:
	var c: Dictionary = Dados.CLASSES[id]
	var p := PanelContainer.new(); var st := Tela.caixa(Color(1.0, 0.97, 0.86), 5, Tela.URUCUM, 7); st.ornamento = true; st.set_content_margin_all(11)
	p.add_theme_stylebox_override("panel", st); p.custom_minimum_size = Vector2(430, 0)
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 3); p.add_child(v)
	v.add_child(Tela.texto(String(c["desc"]), 13, 400, Tela.ANIL))
	v.add_child(Tela.separador(390.0))
	v.add_child(Medidor.barra(tr("Vida"), float(c["maxhp"]) / 160.0, str(int(c["maxhp"])), Tela.URUCUM, 400.0))
	v.add_child(Medidor.barra(tr("Velocidade"), float(c["speed"]) / 7.5, "%.1f" % float(c["speed"]), Tela.IPE, 400.0))
	v.add_child(Medidor.barra(tr("Crítico"), (Dados.CRIT_BASE + float(c.get("crit", 0.0))) / 0.2, _pct(Dados.CRIT_BASE + float(c.get("crit", 0.0))), Tela.BARRO, 400.0))
	if c.has("dodge"): v.add_child(Medidor.barra(tr("Esquiva"), float(c["dodge"]) / 0.3, _pct(float(c["dodge"])), Tela.ANIL, 400.0))
	if c.has("armor"): v.add_child(Medidor.barra(tr("Defesa"), float(c["armor"]) / 0.3, _pct(float(c["armor"])), Tela.ANIL, 400.0))
	if c.has("regen"): v.add_child(Medidor.barra(tr("Regenera"), float(c["regen"]) / 1.2, "%.1f/s" % float(c["regen"]), Tela.MATA, 400.0))
	v.add_child(Tela.separador(390.0))
	v.add_child(Tela.rotulo(tr("GOLPES"), 12, Tela.URUCUM, HORIZONTAL_ALIGNMENT_LEFT, true))
	var hg := HBoxContainer.new(); hg.add_theme_constant_override("separation", 8); v.add_child(hg)
	var lista: Array = [[String(c["inicial"]), 1]]
	for gid in c["desbloqueia"]: lista.append([String(gid), int(c["desbloqueia"][gid])])
	for it in lista:
		var gd: Dictionary = Dados.GOLPES[it[0]]
		var col := VBoxContainer.new(); col.add_theme_constant_override("separation", 1); hg.add_child(col)
		col.add_child(Tela.imagem("a_" + String(gd["arte"]), Vector2(72, 46)))
		var cap := Tela.rotulo(tr("início") if it[1] == 1 else tr("nível %d") % int(it[1]), 11, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER)
		col.add_child(cap); col.tooltip_text = tr(String(gd["nome"])) + " — " + tr(String(gd["txt"]))
	var hab: Dictionary = Dados.HABILIDADES[id]
	for qr in ["q", "r"]:
		var hq := HBoxContainer.new(); hq.add_theme_constant_override("separation", 8); v.add_child(hq)
		var ic := Tela.imagem("a_hab_%s_%s" % [qr, id], Vector2(40, 40)); ic.size_flags_vertical = Control.SIZE_SHRINK_BEGIN; hq.add_child(ic)
		hq.add_child(Tela.texto(tr("[%s] %s — %s") % [qr.to_upper(), tr(String(hab[qr]["nome"])), tr(String(hab[qr]["txt"]))], 12, 336, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	v.add_child(Tela.texto(tr("★ ") + tr(String(c["pulo"])), 12, 400, Tela.ANIL, HORIZONTAL_ALIGNMENT_LEFT))
	return p

func _carta_fase(i: int, fmax: int) -> Button:
	var f: Dictionary = Dados.FASES[i]
	var fechada := i > fmax
	var b := Button.new(); b.custom_minimum_size = Vector2(298, 86); b.disabled = fechada; b.clip_contents = true
	_estilo_carta(b, i == w.sel_fase and not fechada, Tela.PAPEL2)
	var m := MarginContainer.new(); m.set_anchors_preset(Control.PRESET_FULL_RECT)
	for lado in ["left", "right", "top", "bottom"]: m.add_theme_constant_override("margin_" + lado, 9)
	b.add_child(m)
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 10); m.add_child(hb)
	var im := _retrato_bicho(String(f["chefe"]), Vector2(52, 62))
	if fechada: im.modulate = Color(0.1, 0.08, 0.06, 0.75)
	hb.add_child(im)
	var v := VBoxContainer.new(); v.alignment = BoxContainer.ALIGNMENT_CENTER; v.add_theme_constant_override("separation", 2); hb.add_child(v)
	v.add_child(Tela.rotulo(tr("%d · %s") % [i + 1, tr(String(f["nome"]))], 14, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true))
	var l2 := tr("Chefe: %s") % tr(String(f["chefe_nome"])).capitalize()
	var rec := float(Salvo.d["recordes"].get(str(i), -1.0))
	if rec >= 0.0: l2 += tr("\nRecorde extra: %s") % w._mmss(rec)
	if fechada: l2 = "Fechada — vença o\nchefe da fase anterior"
	v.add_child(Tela.rotulo(l2, 12, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	Tela.ignora_mouse(b)
	b.pressed.connect(func():
		w.sel_fase = i; Salvo.d["fase"] = i; herois())
	return b

# ---------------- multijogador: abrir sala (1 clique) e entrar com um código curto ----------------
func coop() -> void:
	_limpar("coop")
	Tela.fundo_papel(raiz)
	for sinal in [Rede.upnp_mudou, Rede.entrou, Rede.saiu]:
		if not sinal.is_connected(_recarregar_coop): sinal.connect(_recarregar_coop)
	var vb := VBoxContainer.new(); vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 70; vb.offset_right = -70; vb.offset_top = 22; vb.offset_bottom = -24
	vb.add_theme_constant_override("separation", 5); raiz.add_child(vb)
	vb.add_child(TituloGravado.novo(tr("MULTIJOGADOR"), 32.0, Tela.PAPEL, Tela.URUCUM, true, true))
	vb.add_child(Tela.rotulo(tr("Até 5 jogadores · na mesma casa ou pela internet"), 16, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	if _rede_erro != "":
		vb.add_child(Tela.faixa(tr(_rede_erro), Tela.URUCUM, 14, Tela.PAPEL)); _rede_erro = ""
	var ln := _linha(vb, 10)
	ln.add_child(Tela.rotulo(tr("Seu nome:"), 16, Tela.TINTA, HORIZONTAL_ALIGNMENT_RIGHT, true))
	var le_nome := LineEdit.new(); le_nome.placeholder_text = tr("aparece em cima do seu boneco"); le_nome.text = String(Salvo.d["nome_jogador"]); le_nome.max_length = 16
	le_nome.custom_minimum_size = Vector2(300, 38); le_nome.alignment = HORIZONTAL_ALIGNMENT_CENTER; le_nome.add_theme_font_size_override("font_size", 16)
	le_nome.text_changed.connect(func(t): Salvo.d["nome_jogador"] = t; Salvo.salvar())
	ln.add_child(le_nome)
	if Rede.ativo(): _coop_sala(vb)
	else: _coop_escolha(vb)
	var ac_voltar := func(): Rede.sair(); titulo()
	var bv := Tela.botao(tr("VOLTAR"), ac_voltar, 16, Tela.PARDO, 220.0, 40.0); bv.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(bv)

# linha com ◀ herói ▶ (e, pro anfitrião, ◀ fase ▶): é o que cada um vai jogar nesta sala
func _escolhas_coop(pai: Control, com_fase: bool) -> void:
	var livres: Array = []
	for hid in Dados.CLASSES:
		if Dados.heroi_desbloqueado(hid): livres.append(hid)
	if not livres.has(w.sel_heroi): w.sel_heroi = livres[0]
	var li: int = livres.find(w.sel_heroi)
	var ln := _linha(pai, 8)
	var ac_a := func(): w.sel_heroi = livres[(li - 1 + livres.size()) % livres.size()]; Salvo.d["heroi"] = w.sel_heroi; coop()
	var ac_p := func(): w.sel_heroi = livres[(li + 1) % livres.size()]; Salvo.d["heroi"] = w.sel_heroi; coop()
	ln.add_child(Tela.botao("◀", ac_a, 16, Tela.PARDO, 46.0, 40.0))
	var ret := _retrato_heroi(w.sel_heroi, Vector2(40, 52)); ln.add_child(ret)
	var ch: Dictionary = Dados.CLASSES[w.sel_heroi]
	ln.add_child(Tela.rotulo(tr("Seu herói: ") + String(ch["apelido"]), 16, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	ln.add_child(Tela.botao("▶", ac_p, 16, Tela.PARDO, 46.0, 40.0))
	if com_fase:
		var fmax: int = mini(int(Salvo.d["fase_max"]), Dados.FASES.size() - 1)
		w.sel_fase = clampi(w.sel_fase, 0, fmax)
		var lf := _linha(pai, 8)
		var ac_fa := func(): w.sel_fase = (w.sel_fase - 1 + fmax + 1) % (fmax + 1); Salvo.d["fase"] = w.sel_fase; coop()
		var ac_fp := func(): w.sel_fase = (w.sel_fase + 1) % (fmax + 1); Salvo.d["fase"] = w.sel_fase; coop()
		lf.add_child(Tela.botao("◀", ac_fa, 16, Tela.PARDO, 46.0, 36.0))
		lf.add_child(Tela.rotulo(tr("Fase %d · %s") % [w.sel_fase + 1, tr(String(Dados.FASES[w.sel_fase]["nome"]))], 15, Tela.URUCUM, HORIZONTAL_ALIGNMENT_CENTER, true))
		lf.add_child(Tela.botao("▶", ac_fp, 16, Tela.PARDO, 46.0, 36.0))

func _cartao_coop(titulo_txt: String, cor: Color) -> VBoxContainer:
	var p := PanelContainer.new(); var st := Tela.caixa(Color(1.0, 0.97, 0.86), 5, Tela.TINTA, 7); st.ornamento = true; st.set_content_margin_all(16)
	p.add_theme_stylebox_override("panel", st); p.custom_minimum_size = Vector2(480, 380)
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 10); p.add_child(v)
	v.add_child(Tela.faixa(titulo_txt, cor, 18, Tela.PAPEL))
	v.set_meta("painel", p)
	return v

func _coop_escolha(vb: VBoxContainer) -> void:
	var duas := HBoxContainer.new(); duas.alignment = BoxContainer.ALIGNMENT_CENTER; duas.add_theme_constant_override("separation", 26); vb.add_child(duas)
	# ---- criar sala ----
	var cr := _cartao_coop(tr("CRIAR SALA"), Tela.URUCUM); duas.add_child(cr.get_meta("painel"))
	cr.add_child(Tela.texto(tr("Clique no botão: o jogo abre a porta sozinho e mostra um CÓDIGO curto. É só passar o código pro seu amigo."), 14, 440))
	var le_sala := LineEdit.new(); le_sala.placeholder_text = tr("nome da sala (opcional)"); le_sala.max_length = 24
	le_sala.custom_minimum_size = Vector2(300, 38); le_sala.alignment = HORIZONTAL_ALIGNMENT_CENTER; le_sala.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	cr.add_child(le_sala)
	_escolhas_coop(cr, true)
	var esp1 := Control.new(); esp1.size_flags_vertical = Control.SIZE_EXPAND_FILL; cr.add_child(esp1)
	var ac_host := func():
		var erro := Rede.hospedar(le_sala.text)
		if erro != "": _rede_erro = erro
		coop()
	var bh := Tela.botao(tr("ABRIR SALA"), ac_host, 30, Tela.URUCUM, 400.0, 70.0, true); bh.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; cr.add_child(bh)
	cr.add_child(Tela.rotulo(tr("Na mesma casa a sala aparece sozinha pro seu amigo."), 12, Tela.TINTA))
	# ---- entrar na sala ----
	var en := _cartao_coop(tr("ENTRAR NA SALA"), Tela.ANIL); duas.add_child(en.get_meta("painel"))
	en.add_child(Tela.texto(tr("Digite o código que o anfitrião mostrou na tela dele:"), 14, 440))
	var le := LineEdit.new(); le.placeholder_text = "XXXX-XXXX"; le.max_length = 9
	le.custom_minimum_size = Vector2(300, 62); le.alignment = HORIZONTAL_ALIGNMENT_CENTER; le.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	le.add_theme_font_override("font", Tela.fonte(true)); le.add_theme_font_size_override("font_size", 34)
	le.text_changed.connect(func(t: String):
		var tt := t.to_upper()
		if tt != t:
			var col := le.caret_column; le.text = tt; le.caret_column = col)
	var ac_join := func():
		var erro2 = await Rede.entrar(le.text)
		if erro2 != "": _rede_erro = erro2
		coop()
	le.text_submitted.connect(func(_t): ac_join.call())
	en.add_child(le)
	_escolhas_coop(en, false)
	var achados: Array = Rede.mundos_disponiveis()
	if achados.size() > 0:
		en.add_child(Tela.rotulo(tr("Salas achadas na sua casa:"), 13, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
		for m in achados.slice(0, 2):
			var ip: String = m["ip"]; var nome_m: String = m["nome"]
			var ac_entrar_achado := func():
				var erro3 = await Rede.entrar(ip)
				if erro3 != "": _rede_erro = erro3
				coop()
			var bm := Tela.botao(tr("ENTRAR EM: %s") % nome_m, ac_entrar_achado, 15, Tela.IPE, 400.0, 36.0); bm.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; en.add_child(bm)
	var esp2 := Control.new(); esp2.size_flags_vertical = Control.SIZE_EXPAND_FILL; en.add_child(esp2)
	var bj := Tela.botao(tr("ENTRAR"), ac_join, 26, Tela.ANIL, 400.0, 60.0, true); bj.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; en.add_child(bj)

var _ajuda_porta := false

# uma linha da lista de passos da sala: [nº] TÍTULO ........ [ESTADO em bloco de tinta/vermelho]  + detalhe legível embaixo
func _passo(pai: Control, num: int, titulo_txt: String, estado_txt: String, tipo: String, detalhe: String = "") -> HBoxContainer:
	var caixa := VBoxContainer.new(); caixa.add_theme_constant_override("separation", 2); pai.add_child(caixa)
	var l := HBoxContainer.new(); l.add_theme_constant_override("separation", 10); caixa.add_child(l)
	var num_b := PanelContainer.new(); var sn := StyleBoxFlat.new(); sn.bg_color = Tela.TINTA; sn.set_corner_radius_all(15); sn.set_content_margin_all(3); num_b.add_theme_stylebox_override("panel", sn)
	var ln := Tela.rotulo(str(num), 20, Tela.PAPEL, HORIZONTAL_ALIGNMENT_CENTER, true); ln.custom_minimum_size = Vector2(24, 0); num_b.add_child(ln)
	l.add_child(num_b)
	var t := Tela.rotulo(titulo_txt, 18, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true); t.size_flags_horizontal = Control.SIZE_EXPAND_FILL; l.add_child(t)
	var est := PanelContainer.new()
	var fundo: Color = Tela.TINTA if tipo == "ok" else (Tela.URUCUM if tipo == "erro" else Tela.IPE)
	var corte: Color = Tela.TINTA if tipo == "espera" else Tela.PAPEL
	var se := Tela.caixa(fundo, 3, Tela.TINTA, 3); se.filete = false; se.set_content_margin_all(5); se.content_margin_left = 12; se.content_margin_right = 12
	est.add_theme_stylebox_override("panel", se); est.add_child(Tela.rotulo(estado_txt, 17, corte, HORIZONTAL_ALIGNMENT_CENTER, true)); est.custom_minimum_size = Vector2(250, 0)
	l.add_child(est)
	if detalhe != "":
		var d := Tela.texto(detalhe, 14, 700, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT); d.add_theme_font_override("font", Tela.fonte(true)); caixa.add_child(d)
	var acoes := HBoxContainer.new(); acoes.add_theme_constant_override("separation", 10); acoes.alignment = BoxContainer.ALIGNMENT_END; caixa.add_child(acoes)
	return acoes

func _coop_sala(vb: VBoxContainer) -> void:
	var p := PanelContainer.new(); var st := Tela.caixa(Color(1.0, 0.97, 0.86), 5, Tela.TINTA, 7); st.ornamento = true; st.set_content_margin_all(14)
	p.add_theme_stylebox_override("panel", st); p.custom_minimum_size = Vector2(800, 0)
	var rolagem := ScrollContainer.new(); rolagem.custom_minimum_size = Vector2(840, 400); rolagem.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	rolagem.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED; rolagem.add_child(p); vb.add_child(rolagem)
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 6); p.add_child(v)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if Rede.sou_host():
		var fw: String = Rede.firewall_estado
		var up: String = Rede.upnp_estado
		var fw_ok: bool = fw == "ok" or fw == "naoaplica"
		var internet: bool = up == "aberto"
		# ---- resumo: uma frase que diz o que está acontecendo ----
		var resumo := ""; var tipo_r := "espera"
		if fw_ok and internet: resumo = tr("✔ TUDO PRONTO — seu amigo, de qualquer lugar, entra com o código abaixo."); tipo_r = "ok"
		elif up == "procurando" or fw == "pedindo": resumo = tr("⏳ Preparando a sala… espere alguns segundos."); tipo_r = "espera"
		elif not fw_ok: resumo = tr("⚠ O Windows está bloqueando o jogo: seu amigo NÃO consegue entrar. Resolva o passo 1."); tipo_r = "erro"
		else: resumo = tr("⚠ A porta do roteador não abriu: só amigos na MESMA CASA (ou na mesma VPN) entram. Resolva o passo 2."); tipo_r = "erro"
		var fr := Tela.faixa(resumo, Tela.TINTA if tipo_r == "ok" else (Tela.URUCUM if tipo_r == "erro" else Tela.IPE), 17, Tela.PAPEL if tipo_r != "espera" else Tela.TINTA)
		v.add_child(fr)
		# ---- passo 1: firewall ----
		if fw != "naoaplica":
			var a1: HBoxContainer
			match fw:
				"ok": a1 = _passo(v, 1, tr("WINDOWS (Firewall)"), tr("✔ LIBERADO"), "ok")
				"pedindo": a1 = _passo(v, 1, tr("WINDOWS (Firewall)"), tr("⏳ CLIQUE EM SIM"), "espera", tr("Apareceu uma janela do Windows pedindo permissão? Clique em SIM."))
				_: a1 = _passo(v, 1, tr("WINDOWS (Firewall)"), tr("✖ BLOQUEADO"), "erro", tr("O Windows precisa de permissão pra receber seu amigo. É só um clique: o jogo pede e você confirma."))
			if fw == "faltando" or fw == "":
				a1.add_child(Tela.botao(tr("LIBERAR NO WINDOWS"), Rede.pedir_firewall, 15, Tela.URUCUM, 260.0, 36.0))
		# ---- passo 2: roteador ----
		var a2: HBoxContainer
		match up:
			"aberto": a2 = _passo(v, 2, tr("ROTEADOR (porta UDP %d)") % Rede.PORTA, tr("✔ ABERTA"), "ok")
			"procurando": a2 = _passo(v, 2, tr("ROTEADOR (porta UDP %d)") % Rede.PORTA, tr("⏳ ABRINDO…"), "espera", tr("O jogo está pedindo pro roteador abrir a porta sozinho."))
			_: a2 = _passo(v, 2, tr("ROTEADOR (porta UDP %d)") % Rede.PORTA, tr("✖ NÃO ABRIU"), "erro", tr(Rede.upnp_motivo) if Rede.upnp_motivo != "" else tr("O roteador não respondeu."))
		if up == "falhou":
			a2.add_child(Tela.botao(tr("TENTAR DE NOVO"), Rede.tentar_porta_de_novo, 15, Tela.TINTA, 200.0, 36.0))
			var ac_ajuda := func(): _ajuda_porta = not _ajuda_porta; coop()
			a2.add_child(Tela.botao(tr("COMO ABRIR À MÃO") if not _ajuda_porta else tr("FECHAR AJUDA"), ac_ajuda, 15, Tela.PAPEL2, 220.0, 36.0))
			if _ajuda_porta:
				var ips: Array = Rede.meus_enderecos()
				var meu_ip: String = String(ips[0]) if ips.size() > 0 else tr("(o IP deste PC)")
				var ap := PanelContainer.new(); var sa := Tela.caixa(Tela.PAPEL2, 3, Tela.TINTA, 0); sa.filete = false; sa.set_content_margin_all(10); ap.add_theme_stylebox_override("panel", sa)
				ap.add_child(Tela.texto(tr("1) Abra o painel do roteador no navegador (geralmente 192.168.0.1 ou 192.168.1.1).\n2) Procure \"Redirecionamento de portas\" (Port Forwarding / Servidor virtual).\n3) Crie uma regra: protocolo UDP, porta 7777, destino %s.\n4) Salve e clique em TENTAR DE NOVO.\n\nSe nada disso for possível (provedor com CGNAT), use o Tailscale: veja COMO-JOGAR-ONLINE.txt.") % meu_ip, 14, 740, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
				v.add_child(ap)
		# ---- passo 3: código ----
		v.add_child(Tela.separador(300.0))
		var ends: Array = Rede.enderecos_da_sala()
		var a3 := _passo(v, 3, tr("CÓDIGO PRA PASSAR PRO AMIGO"), tr("de FORA de casa") if internet else tr("só na MESMA CASA/VPN"), "ok" if internet else "erro")
		if ends.is_empty():
			v.add_child(Tela.rotulo(tr("sem endereço de rede — confira o Wi-Fi ou o cabo"), 17, Tela.URUCUM, HORIZONTAL_ALIGNMENT_CENTER, true))
		else:
			var cod: String = ends[0]["codigo"]
			v.add_child(TituloGravado.novo(cod, 56.0, Tela.PAPEL, Tela.URUCUM, false, true))
			var ac_copiar := func(): DisplayServer.clipboard_set(cod); Som.tocar("clique")
			a3.add_child(Tela.botao(tr("COPIAR CÓDIGO"), ac_copiar, 15, Tela.URUCUM, 220.0, 34.0))
			v.add_child(Tela.rotulo(tr("Este código vale para: %s") % tr(String(ends[0]["rotulo"])), 15, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
			if ends.size() > 1:
				var outros := ""
				for i in range(1, ends.size()): outros += ("   |   " if outros != "" else "") + "%s: %s" % [tr(String(ends[i]["rotulo"])), ends[i]["codigo"]]
				v.add_child(Tela.rotulo(tr("Outros códigos — ") + outros, 13, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER))
	else:
		v.add_child(Tela.faixa(tr("CONECTADO À SALA"), Tela.TINTA, 17, Tela.PAPEL))
	_escolhas_coop(v, Rede.sou_host())
	v.add_child(Tela.separador(300.0))
	var lug := _linha(v, 8)
	var n := Rede.ids().size()
	for i in range(Rede.MAX_JOGADORES):
		var q := PanelContainer.new(); var sq := Tela.caixa(Tela.TINTA if i < n else Tela.PAPEL2, 3, Tela.TINTA, 3); sq.filete = false; sq.set_content_margin_all(6)
		q.add_theme_stylebox_override("panel", sq); q.custom_minimum_size = Vector2(140, 40)
		q.add_child(Tela.rotulo((tr("ANFITRIÃO") if i == 0 else tr("AMIGO %d") % i) if i < n else tr("vago"), 14, Tela.PAPEL if i < n else Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
		lug.add_child(q)
	if Rede.sou_host():
		var ac_comecar := func(): Rede.comecar(w.sel_fase)
		var bc := Tela.botao(tr("COMEÇAR"), ac_comecar, 26, Tela.URUCUM, 360.0, 50.0, true); bc.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; vb.add_child(bc)
	else:
		vb.add_child(Tela.rotulo(tr("Esperando o anfitrião começar…"), 17, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var ac_sair := func(): Rede.sair(); coop()
	var bs := Tela.botao(tr("SAIR DA SALA"), ac_sair, 14, Tela.PAPEL2, 220.0, 32.0); bs.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; vb.add_child(bs)

# ---------------- melhorias permanentes ----------------
func melhorias() -> void:
	_limpar("melhorias")
	Tela.fundo_papel(raiz, Color(1, 1, 1), false)
	var vb := VBoxContainer.new(); vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 40; vb.offset_right = -40; vb.offset_top = 26; vb.offset_bottom = -22
	vb.add_theme_constant_override("separation", 8); raiz.add_child(vb)
	vb.add_child(Tela.titulo("t_melhorias", 40))
	vb.add_child(Tela.rotulo(tr("Cada herói tem as suas: quem você não treinou continua do zero."), 14, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER))
	var livres: Array = []
	for hid in Dados.CLASSES:
		if Dados.heroi_desbloqueado(hid): livres.append(hid)      # treino só vale pra quem já tem o herói liberado
	var atual: String = String(Salvo.d["heroi"])
	if not livres.has(atual) and not livres.is_empty(): atual = livres[0]
	var meio := HBoxContainer.new(); meio.alignment = BoxContainer.ALIGNMENT_CENTER; meio.add_theme_constant_override("separation", 22); vb.add_child(meio)
	# ---- esquerda: quem está treinando (palco + troca de herói com setas) ----
	var ch: Dictionary = Dados.CLASSES[atual]
	var esq := VBoxContainer.new(); esq.add_theme_constant_override("separation", 6); meio.add_child(esq)
	var troca := HBoxContainer.new(); troca.add_theme_constant_override("separation", 6); esq.add_child(troca)
	var i_at: int = livres.find(atual)
	var ac_ant := func():
		var h2: String = livres[(i_at - 1 + livres.size()) % livres.size()]
		w.sel_heroi = h2; Salvo.d["heroi"] = h2; Salvo.salvar(); melhorias()
	var ac_prox := func():
		var h3: String = livres[(i_at + 1) % livres.size()]
		w.sel_heroi = h3; Salvo.d["heroi"] = h3; Salvo.salvar(); melhorias()
	troca.add_child(Tela.botao("◀", ac_ant, 18, Tela.PARDO, 52.0, 42.0))
	var nome_h := Tela.faixa(String(ch["apelido"]).to_upper(), Paleta.snap(ch["cor"]).lerp(Tela.IPE, 0.4), 17, Tela.TINTA); nome_h.custom_minimum_size = Vector2(170, 42); nome_h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	troca.add_child(nome_h)
	troca.add_child(Tela.botao("▶", ac_prox, 18, Tela.PARDO, 52.0, 42.0))
	var pbox := PanelContainer.new(); var sp := Tela.caixa(Tela.TINTA, 3, Tela.TINTA, 6); sp.filete = false; sp.set_content_margin_all(5); pbox.add_theme_stylebox_override("panel", sp)
	pbox.add_child(PalcoGravura.novo(atual, Vector2(300, 290), Paleta.snap(ch["cor"]).lerp(Tela.IPE, 0.35), false, true)); esq.add_child(pbox)
	var total := 0; var maximo_total := 0
	for id in Dados.MELHORIAS: total += Salvo.nivel(id); maximo_total += int(Dados.MELHORIAS[id]["max"])
	esq.add_child(Medidor.barra(tr("Treino"), float(total) / maxf(1.0, float(maximo_total)), "%d/%d" % [total, maximo_total], Tela.MATA, 300.0))
	# ---- direita: as melhorias, em duas colunas de recibos ----
	var gr := GridContainer.new(); gr.columns = 2
	gr.add_theme_constant_override("h_separation", 12); gr.add_theme_constant_override("v_separation", 10); meio.add_child(gr)
	for id in Dados.MELHORIAS:
		var m: Dictionary = Dados.MELHORIAS[id]
		var nv := Salvo.nivel(id); var custo := Dados.custo_melhoria(id, nv)
		var cheio: bool = nv >= int(m["max"])
		var p := PanelContainer.new(); p.custom_minimum_size = Vector2(392, 88)
		var s2 := Tela.caixa(Color(1.0, 0.97, 0.86), 4, Tela.URUCUM if cheio else Tela.TINTA, 6); s2.set_content_margin_all(8); p.add_theme_stylebox_override("panel", s2); gr.add_child(p)
		var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 10); p.add_child(hb)
		var im := Tela.imagem("a_" + String(m["arte"]), Vector2(84, 62)); im.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		hb.add_child(im)
		var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 3); v.alignment = BoxContainer.ALIGNMENT_CENTER; v.size_flags_horizontal = Control.SIZE_EXPAND_FILL; hb.add_child(v)
		v.add_child(Tela.rotulo(m["nome"], 16, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true))
		v.add_child(Tela.texto(tr(String(m["txt"])) + tr(" por nível"), 12, 170, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
		v.add_child(Medidor.pips(nv, int(m["max"])))
		var ac_compra := func():
			Salvo.d["moedas"] = int(Salvo.d["moedas"]) - custo
			Salvo.subir(id)
			Salvo.salvar(); melhorias()
		var bt := Tela.botao(tr("MÁXIMO") if cheio else "◉ %d" % custo, ac_compra, 15, Tela.ANIL, 96.0, 38.0)
		bt.disabled = cheio or int(Salvo.d["moedas"]) < custo; bt.tooltip_text = tr("COMPRAR"); bt.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		hb.add_child(bt)
	var volta := Tela.botao(tr("VOLTAR"), titulo, 18, Tela.PARDO, 220.0, 44.0); volta.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(volta)
	_moedas_tag(true)

# ---------------- feitos (metas que pagam moedas) ----------------
func feitos() -> void:
	_limpar("feitos")
	Tela.fundo_papel(raiz, Color(1, 1, 1), false)
	var vb := _centro(6)
	vb.add_child(TituloGravado.novo(tr("FEITOS"), 30.0, Tela.PAPEL, Tela.URUCUM, true, true))
	vb.add_child(Tela.rotulo("Cumpra as metas jogando e pegue as moedas aqui.", 15))
	var gr := GridContainer.new(); gr.columns = 2
	gr.add_theme_constant_override("h_separation", 14); gr.add_theme_constant_override("v_separation", 5); vb.add_child(gr)
	for f in Dados.FEITOS:
		var tem := int(Salvo.d["contadores"].get(f["c"], 0)); var meta := int(f["meta"])
		var pego: bool = Salvo.d["feitos"].has(f["id"])
		var pronto: bool = tem >= meta and not pego
		var p := PanelContainer.new(); p.custom_minimum_size = Vector2(560, 46)
		var st := Tela.caixa(Color(1.0, 0.97, 0.86) if not pego else Tela.PAPEL2, 5 if pronto else 3, Tela.URUCUM if pronto else Tela.TINTA, 5); st.set_content_margin_all(9)
		p.add_theme_stylebox_override("panel", st); gr.add_child(p)
		var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 10); p.add_child(hb)
		var v := VBoxContainer.new(); v.size_flags_horizontal = Control.SIZE_EXPAND_FILL; v.add_theme_constant_override("separation", 1); hb.add_child(v)
		v.add_child(Tela.rotulo(f["nome"], 18, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true))
		v.add_child(Tela.rotulo(tr("%s  ·  %d / %d") % [tr(String(f["txt"])), mini(tem, meta), meta], 14, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
		var barra := ProgressBar.new(); barra.max_value = meta; barra.value = mini(tem, meta); barra.show_percentage = false; barra.custom_minimum_size = Vector2(0, 8)
		var bf := StyleBoxFlat.new(); bf.bg_color = Tela.PARDO; var bc := StyleBoxFlat.new(); bc.bg_color = Tela.MATA if pego else Tela.URUCUM
		barra.add_theme_stylebox_override("background", bf); barra.add_theme_stylebox_override("fill", bc); v.add_child(barra)
		var id: String = f["id"]; var premio := int(f["premio"])
		var ac := func():
			Salvo.d["feitos"][id] = true
			Salvo.d["moedas"] = int(Salvo.d["moedas"]) + premio
			Salvo.salvar(); feitos()
		var bt := Tela.botao(tr("FEITO ✔") if pego else tr("PEGAR ◉ %d") % premio if pronto else tr("◉ %d") % premio, ac, 15, Tela.URUCUM if pronto else Tela.PARDO, 150.0, 40.0)
		bt.disabled = not pronto; bt.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		hb.add_child(bt)
	var volta := Tela.botao("VOLTAR", titulo, 18, Tela.PARDO, 220.0, 46.0); volta.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(volta)
	_moedas_tag()

# ---------------- opções ----------------
func opcoes(volta: Callable) -> void:
	_volta = volta
	_limpar("opcoes")
	if w.estado == "menu": Tela.fundo_papel(raiz)
	else: Tela.escuro(raiz, 0.7)
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var p := Tela.painel(Color(1.0, 0.97, 0.86)); cc.add_child(p)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 12); p.add_child(vb)
	vb.add_child(Tela.titulo("t_opcoes", 48))
	var meio := HBoxContainer.new(); meio.add_theme_constant_override("separation", 22); vb.add_child(meio)
	# ---- abas na lateral, como índice de folheto ----
	var lat := VBoxContainer.new(); lat.add_theme_constant_override("separation", 8); meio.add_child(lat)
	for par in [["som", "SOM"], ["jogo", "JOGO"], ["controles", "CONTROLES"], ["idioma", "IDIOMA"]]:
		var k: String = par[0]
		var ac_aba := func():
			_aba = k; opcoes(_volta)
		var ativa: bool = k == _aba
		lat.add_child(Tela.botao(("▶ " if ativa else "") + tr(par[1]), ac_aba, 17, Tela.IPE if ativa else Tela.PARDO, 200.0, 50.0))
	# ---- conteúdo da aba ----
	var pagina := PanelContainer.new(); var sp := Tela.caixa(Color("F6EBCB"), 3, Tela.TINTA, 4); sp.filete = false; sp.set_content_margin_all(16); pagina.add_theme_stylebox_override("panel", sp); meio.add_child(pagina)
	var corpo := VBoxContainer.new(); corpo.custom_minimum_size = Vector2(640, 300); corpo.add_theme_constant_override("separation", 10)
	pagina.add_child(corpo)
	var nomes_aba := {"som": "SOM", "jogo": "JOGO", "controles": "CONTROLES", "idioma": "IDIOMA"}
	corpo.add_child(Tela.faixa(tr(nomes_aba[_aba]), Tela.URUCUM, 15, Tela.PAPEL))
	match _aba:
		"som":
			_deslizante(corpo, "Volume geral", "geral", 0.0, 1.0, true)
			_deslizante(corpo, "Música", "musica", 0.0, 1.0, true)
			_deslizante(corpo, "Efeitos sonoros", "efeitos", 0.0, 1.0, true)
			corpo.add_child(Tela.texto("Sons, vozes e música são provisórios — servem para sentir o jogo; os definitivos entram depois.", 12, 600, Tela.PARDO.darkened(0.3)))
		"jogo":
			_deslizante(corpo, "Sensibilidade do mouse", "sens", 0.3, 2.5, false)
			_deslizante(corpo, "Distância da câmera", "camera", 7.0, 22.0, false)
			_chave(corpo, "Tela cheia", "cheia")
			_chave(corpo, "Números de dano", "numeros")
			if w.estado == "menu":
				var ac_tut := func(): _so_tutorial = true; herois()
				var bt_tut := Tela.botao(tr("JOGAR O TUTORIAL DE NOVO"), ac_tut, 15, Tela.ANIL, 320.0, 40.0, true); bt_tut.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
				corpo.add_child(bt_tut)
		"controles":
			var gr := GridContainer.new(); gr.columns = 4
			gr.add_theme_constant_override("h_separation", 10); gr.add_theme_constant_override("v_separation", 6); corpo.add_child(gr)
			for it in Ctrl.ACOES:
				var a: String = it[0]
				var l := Tela.rotulo(tr(it[1]), 13, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT); l.custom_minimum_size = Vector2(150, 0); gr.add_child(l)
				var ac_tecla := func():
					_capt = a; opcoes(_volta)
				gr.add_child(Tela.botao(tr("aperte uma tecla…") if _capt == a else Ctrl.nome(a), ac_tecla, 13, Tela.IPE if _capt == a else Tela.PAPEL2, 100.0, 30.0))
			var ac_pad := func():
				Salvo.d["teclas"] = {}; _capt = ""; Salvo.salvar(); opcoes(_volta)
			var bp := Tela.botao(tr("VOLTAR AO PADRÃO"), ac_pad, 13, Tela.PARDO, 220.0, 32.0); bp.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
			corpo.add_child(bp)
			corpo.add_child(Tela.texto("As setas também andam. Controle de Xbox ou PlayStation: analógico esquerdo anda, direito gira a câmera, A/✕ pula, B/○ arranca, X/□ especial, Y/△ ultimate, LB/L1 mostra a build, Start pausa.", 12, 600))
		"idioma":
			var idioma_atual: String = String(Salvo.d.get("idioma", "pt_BR"))
			for par2 in [["pt_BR", "PORTUGUÊS (BRASIL)"], ["en", "ENGLISH"]]:
				var cod: String = par2[0]
				var ac_idioma := func():
					Salvo.d["idioma"] = cod; Salvo.salvar(); Tela.aplicar_opcoes(); opcoes(_volta)
				var bt_idioma := Tela.botao(("✔ " if cod == idioma_atual else "") + par2[1], ac_idioma, 18, Tela.MATA if cod == idioma_atual else Tela.PAPEL2, 340.0, 48.0, cod == idioma_atual)
				bt_idioma.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; corpo.add_child(bt_idioma)
			corpo.add_child(Tela.texto("Mais idiomas entram antes do lançamento na Steam.", 13, 600))
	var ac_volta := func():
		_capt = ""; Salvo.salvar(); _volta.call()
	var bv := Tela.botao(tr("VOLTAR"), ac_volta, 18, Tela.URUCUM, 240.0, 46.0, true)
	bv.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; vb.add_child(bv)

func _mudou(k: String, v: float) -> void:
	Salvo.d["opcoes"][k] = v
	Tela.aplicar_opcoes(); w.aplicar_opcoes()

func _deslizante(pai: Control, nome: String, k: String, mn: float, mx: float, pct: bool) -> void:
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 14); pai.add_child(hb)
	var l := Tela.rotulo(nome, 18, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT); l.custom_minimum_size = Vector2(250, 0); hb.add_child(l)
	var sl := HSlider.new(); sl.min_value = mn; sl.max_value = mx; sl.step = 0.05 if mx <= 3.0 else 0.5
	sl.value = Tela.opc(k); sl.custom_minimum_size = Vector2(290, 30); sl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(sl)
	var val := Tela.rotulo("", 18, Tela.TINTA, HORIZONTAL_ALIGNMENT_RIGHT, true); val.custom_minimum_size = Vector2(70, 0); hb.add_child(val)
	var mostra := func(v: float): val.text = _pct(v) if pct else ("%.1f" % v)
	mostra.call(sl.value)
	sl.value_changed.connect(func(v: float):
		mostra.call(v); _mudou(k, v))
	sl.drag_ended.connect(func(_m: bool): Salvo.salvar())

func _chave(pai: Control, nome: String, k: String) -> void:
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 14); pai.add_child(hb)
	var l := Tela.rotulo(nome, 18, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT); l.custom_minimum_size = Vector2(250, 0); l.tooltip_text = ""; hb.add_child(l)
	var lig := Tela.opc(k) > 0.5
	var cx := CheckBox.new(); cx.text = tr("LIGADO") if lig else tr("DESLIGADO"); cx.button_pressed = lig
	cx.add_theme_font_override("font", Tela.fonte(true)); cx.add_theme_font_size_override("font_size", 16)
	cx.custom_minimum_size = Vector2(200, 36); cx.focus_mode = Control.FOCUS_ALL if Ctrl.tem_controle() else Control.FOCUS_NONE
	cx.toggled.connect(func(lig_novo: bool):
		Som.tocar("clique"); _mudou(k, 1.0 if lig_novo else 0.0); Salvo.salvar(); opcoes(_volta))
	hb.add_child(cx)

# ---------------- pausa (ESC) ----------------
func pausa() -> void:
	_limpar("pausa")
	Tela.escuro(raiz, 0.62)
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var p := Tela.painel(Color(1.0, 0.97, 0.86)); cc.add_child(p)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 14); p.add_child(vb)
	vb.add_child(Tela.titulo("t_pausa", 58))
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 26); vb.add_child(hb)
	var esq := VBoxContainer.new(); esq.custom_minimum_size = Vector2(400, 0); esq.add_theme_constant_override("separation", 6); hb.add_child(esq)
	var j = w.player
	var f: Dictionary = Dados.FASES[w.fase]
	esq.add_child(Tela.faixa(tr("%s · NÍVEL %d") % [String(Dados.CLASSES[j.classe]["apelido"]).to_upper(), j.level], Dados.CLASSES[j.classe]["cor"], 15, Tela.TINTA))
	for g in j.golpes:
		var lg := HBoxContainer.new(); lg.add_theme_constant_override("separation", 8); esq.add_child(lg)
		lg.add_child(Tela.imagem("a_" + String(Dados.GOLPES[g["id"]]["arte"]), Vector2(56, 36)))
		var nm := Tela.rotulo(Dados.GOLPES[g["id"]]["nome"], 16, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT); nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lg.add_child(nm)
		lg.add_child(Tela.rotulo(tr("MÁX") if g["nivel"] >= Dados.NIVEL_MAX else tr("Nv %d") % g["nivel"], 16, Tela.URUCUM, HORIZONTAL_ALIGNMENT_RIGHT, true))
	var at := tr("Vida %d / %d  ·  Dano +%s\nCrítico %s (×%.1f)  ·  Vel. de ataque +%s\nÁrea +%s  ·  Defesa %s  ·  Regenera %.1f/s") % [
		int(ceil(j.hp)), int(j.max_hp), _pct(j.dano_mult - 1.0), _pct(j.crit), j.crit_dano, _pct(j.atk_speed - 1.0),
		_pct(j.area_mult - 1.0), _pct(j.armor), j.regen]
	esq.add_child(Tela.texto(at, 14, 400, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	esq.add_child(Tela.faixa(tr("FASE %d · %s") % [w.fase + 1, tr(String(f["nome"])).to_upper()], Tela.PAPEL2, 14, Tela.TINTA))
	esq.add_child(Tela.texto(tr("Tempo %s  ·  %d abates  ·  ◉ %d moedas\nMaior golpe: %s  ·  Dano total: %s") % [
		w._mmss(w.time), w.kills, int(w.moedas), Tela.num(w.maior_dano), Tela.num(w.dano_total)], 14, 400, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	var dir := VBoxContainer.new(); dir.add_theme_constant_override("separation", 12); dir.alignment = BoxContainer.ALIGNMENT_CENTER; hb.add_child(dir)
	dir.add_child(Tela.botao("CONTINUAR", w.continuar, 22, Tela.URUCUM, 300.0, 56.0))
	var ac_opc := func(): opcoes(pausa)
	var ac_fechar := func(): get_tree().quit()
	dir.add_child(Tela.botao("OPÇÕES", ac_opc, 18, Tela.MATA, 300.0, 46.0))
	dir.add_child(Tela.botao("SAIR PARA O ARRAIAL", w.sair_da_fase, 16, Tela.ANIL, 300.0, 46.0))
	dir.add_child(Tela.botao("FECHAR O JOGO", ac_fechar, 16, Tela.PARDO, 300.0, 42.0))
	if not w.chefe_morto:
		dir.add_child(Tela.texto("Sair antes de vencer o chefe leva só metade das moedas.", 12, 300))
	vb.add_child(Tela.texto(tr("%s%s%s%s anda · mouse gira a câmera · rodinha aproxima · %s pula · %s arranca · %s especial · %s ultimate · %s mostra a build") % [
		Ctrl.nome("cima"), Ctrl.nome("esq"), Ctrl.nome("baixo"), Ctrl.nome("dir"), Ctrl.nome("pulo"), Ctrl.nome("dash"), Ctrl.nome("q"), Ctrl.nome("r"), Ctrl.nome("info")], 13, 720))

# ---------------- subir de nível: folhetos no varal ----------------
func nivel(p, ofertas: Array, tipo: String = "nivel") -> void:
	_limpar("nivel")
	_heroi_nv = p; _abriu = Time.get_ticks_msec()
	Tela.escuro(raiz, 0.8)
	var vb := _centro(6)
	if tipo == "bau":
		vb.add_child(Tela.rotulo("BAÚ ABERTO!", 50, Tela.IPE, HORIZONTAL_ALIGNMENT_CENTER, true))
		vb.add_child(Tela.rotulo("Folhetos de sorte: no mínimo raros — escolha um", 20, Tela.PAPEL))
	elif tipo == "contrabando":
		vb.add_child(Tela.rotulo("CONTRABANDO", 50, Tela.IPE, HORIZONTAL_ALIGNMENT_CENTER, true))
		vb.add_child(Tela.rotulo("Mercadoria fina: épica ou melhor — escolha uma", 20, Tela.PAPEL))
	elif tipo == "caminho":
		vb.add_child(Tela.rotulo("ABRE-CAMINHO", 50, Color(1.0, 0.4, 0.4), HORIZONTAL_ALIGNMENT_CENTER, true))
		vb.add_child(Tela.rotulo("A Pomba Gira abriu o caminho: escolha uma", 20, Tela.PAPEL))
	elif tipo == "oratorio":
		vb.add_child(Tela.rotulo("BENÇÃO DO ORATÓRIO", 46, Color(0.6, 0.9, 1.0), HORIZONTAL_ALIGNMENT_CENTER, true))
		vb.add_child(Tela.rotulo("Escolha uma graça", 20, Tela.PAPEL))
	else:
		vb.add_child(Tela.titulo("t_nivel", 62, true))
		vb.add_child(Tela.rotulo(tr("Nível %d — escolha um folheto") % p.level, 20, Tela.PAPEL))
	var larg := 270.0; var vao := 34.0
	var area := Control.new(); area.custom_minimum_size = Vector2(ofertas.size() * larg + (ofertas.size() - 1) * vao, 450); vb.add_child(area)
	var corda := ColorRect.new(); corda.color = Tela.PAPEL2; corda.position = Vector2(-60, 12); corda.size = Vector2(area.custom_minimum_size.x + 120, 4)
	area.add_child(corda)
	for i in range(ofertas.size()):
		var b := _folheto(p, ofertas[i], i, Vector2(larg, 414))
		b.position = Vector2(i * (larg + vao), 26); area.add_child(b)
		var preg := Panel.new(); preg.position = Vector2(i * (larg + vao) + larg * 0.5 - 9, 0); preg.size = Vector2(18, 42)
		preg.add_theme_stylebox_override("panel", Tela.caixa(Tela.PARDO, 2, Tela.TINTA, 0, 3)); preg.mouse_filter = Control.MOUSE_FILTER_IGNORE
		area.add_child(preg)
		_cartas.append([ofertas[i], b])
	# controle da sorte: jogar búzios (rola tudo de novo) e queimar folheto (some e não volta nesta partida)
	_queimando = false
	var hb := _linha(vb, 18)
	var bz := Tela.botao(tr("JOGAR BÚZIOS (%d)  [B]") % p.buzios, w.rolar_buzios, 17, Tela.ANIL, 280.0, 44.0)
	bz.disabled = p.buzios <= 0; hb.add_child(bz)
	var bq := Tela.botao(tr("QUEIMAR FOLHETO (%d)  [X]") % p.queimas, _alternar_queima, 17, Tela.URUCUM, 300.0, 44.0)
	bq.disabled = p.queimas <= 0; hb.add_child(bq)

func _alternar_queima() -> void:
	if tela != "nivel" or _heroi_nv == null or _heroi_nv.queimas <= 0: return
	_queimando = not _queimando
	for par in _cartas:            # folhetos em brasa: o próximo clicado queima
		var bt: Button = par[1]
		bt.modulate = Color(1.0, 0.55, 0.45) if _queimando and par[0]["tipo"] != "golpe_evo" else Color.WHITE

func _folheto(p, card: Dictionary, i: int, tam: Vector2) -> Button:
	var ri: int = card.get("rar", 0)
	var r: Dictionary = Dados.RARIDADES[ri]
	var info: Dictionary = p.info_carta(card)
	var cor_r: Color = Tela.COR_RARIDADE[ri]
	var mitica := ri == 5
	var b := Button.new(); b.custom_minimum_size = tam; b.size = tam; b.pivot_offset = tam * 0.5; b.clip_contents = true
	var papel := Color(1.0, 0.97, 0.86)
	var borda: Color = Tela.TINTA if ri == 0 else cor_r.darkened(0.25)
	b.add_theme_stylebox_override("normal", Tela.caixa(papel, 8 if mitica else 5, borda, 7))
	b.add_theme_stylebox_override("hover", Tela.caixa(Color(1, 1, 0.94), 8 if mitica else 6, Tela.URUCUM, 10))
	b.add_theme_stylebox_override("pressed", Tela.caixa(Color(1, 1, 0.94), 6, Tela.URUCUM, 2))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var v := _miolo(b, 12, 6)
	var nome_r := tr(String(r["nome"])).to_upper()
	if card["tipo"] == "golpe_novo": nome_r = tr("GOLPE NOVO"); cor_r = Tela.URUCUM
	v.add_child(Tela.faixa((tr("✦ %s ✦") % nome_r) if mitica else nome_r, cor_r, 15, Tela.PAPEL if cor_r.get_luminance() < 0.45 else Tela.TINTA))
	v.add_child(Tela.imagem("a_" + String(info["arte"]), Vector2(tam.x - 24, (tam.x - 24) * 0.65)))
	var nm := Tela.texto(info["nome"], 21, tam.x - 28); nm.add_theme_font_override("font", Tela.fonte(true)); v.add_child(nm)
	if card["tipo"] != "golpe_novo": v.add_child(Tela.rotulo(info["selo"], 14, Tela.URUCUM, HORIZONTAL_ALIGNMENT_CENTER, true))
	v.add_child(Tela.texto(info["txt"], 15, tam.x - 28))
	var esp := Control.new(); esp.size_flags_vertical = Control.SIZE_EXPAND_FILL; v.add_child(esp)
	if Dados.PIADAS.has(card["id"]): v.add_child(Tela.texto(tr("“%s”") % tr(String(Dados.PIADAS[card["id"]])), 12, tam.x - 28, Tela.ANIL))
	v.add_child(Tela.rotulo(tr("tecla %d") % (i + 1), 12, Tela.PARDO.darkened(0.2)))
	Tela.ignora_mouse(b)
	b.mouse_entered.connect(func(): create_tween().tween_property(b, "scale", Vector2(1.06, 1.06), 0.08))
	b.mouse_exited.connect(func(): create_tween().tween_property(b, "scale", Vector2.ONE, 0.08))
	b.pressed.connect(func(): _pegar(card))
	if mitica:
		var tw := b.create_tween().set_loops()
		tw.tween_property(b, "modulate", Color(1.25, 1.1, 1.1), 0.45); tw.tween_property(b, "modulate", Color.WHITE, 0.45)
	return b

func _pegar(card: Dictionary) -> void:
	if tela != "nivel" or Time.get_ticks_msec() - _abriu < 350: return
	if _queimando:
		if card["tipo"] == "golpe_evo": return
		_queimando = false; w.queimar_carta(card); return
	w._escolher_carta(_heroi_nv, card)

func _input(event: InputEvent) -> void:
	if _capt != "" and event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode != KEY_ESCAPE:
			Salvo.d["teclas"][_capt] = int(event.physical_keycode); Salvo.salvar()
		_capt = ""; get_viewport().set_input_as_handled()
		if tela == "opcoes": opcoes(_volta)
		return
	if event is InputEventJoypadButton and event.pressed and event.button_index == JOY_BUTTON_B and tela in ["opcoes", "herois", "melhorias", "feitos", "loja", "lore", "npc", "pausa", "pergtut"]:
		esc(); return
	if tela == "lore" and event is InputEventKey and event.pressed and not event.echo and event.physical_keycode in [KEY_ENTER, KEY_KP_ENTER, KEY_SPACE]:
		get_viewport().set_input_as_handled(); w.fechar_loja(); return
	if tela == "nivel" and event is InputEventKey and event.pressed and not event.echo:
		var n: int = [KEY_1, KEY_2, KEY_3].find(event.physical_keycode)
		if n < 0: n = [KEY_KP_1, KEY_KP_2, KEY_KP_3].find(event.physical_keycode)
		if n >= 0 and n < _cartas.size(): _pegar(_cartas[n][0])
		elif event.physical_keycode == KEY_B: w.rolar_buzios()
		elif event.physical_keycode == KEY_X: _alternar_queima()

# ---------------- Bodega do Lampião ----------------
func loja() -> void:
	_limpar("loja")
	Tela.escuro(raiz, 0.72)
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var p := Tela.painel(Color(1.0, 0.97, 0.86)); cc.add_child(p)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 9); p.add_child(vb)
	vb.add_child(Tela.rotulo("BODEGA DO LAMPIÃO", 40, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	vb.add_child(Tela.faixa(tr("Você tem ◉ %d moedas nesta partida") % int(w.moedas), Tela.IPE, 16, Tela.TINTA))
	for it in Dados.LOJA:
		var id: String = it["id"]
		var preco: int = w.loja_preco(id)
		var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 14); vb.add_child(hb)
		var v := VBoxContainer.new(); v.custom_minimum_size = Vector2(560, 0); v.add_theme_constant_override("separation", 0); hb.add_child(v)
		v.add_child(Tela.rotulo(it["nome"], 18, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true))
		v.add_child(Tela.texto(it["txt"], 13, 560, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
		var ac := func(): w.comprar_loja(id)
		var txt := tr("◉ %d") % preco if preco > 0 else tr("DE GRAÇA")
		if id == "pacto" and w.pacto_feito: txt = tr("FEITO")
		var bt := Tela.botao(txt, ac, 16, Tela.URUCUM, 150.0, 42.0); bt.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		bt.disabled = not w.loja_pode(id)
		hb.add_child(bt)
	var bs := Tela.botao("SEGUIR VIAGEM  (Esc)", w.fechar_loja, 18, Tela.PARDO, 300.0, 46.0); bs.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(bs)

# ---------------- gente do mapa: retrato, balão de fala e o que oferece ----------------
# nome de arquivo mais curto pra quem tem o "id" comprido — o caminho completo do cache de import
# do Godot pode passar dos 260 caracteres do Windows com o id inteiro (aconteceu de verdade aqui)
const APELIDO_ARQUIVO := {"maracatuzeiro": "maracatu", "cangaceiro_chefe": "cangchefe"}
# retrato: usa a arte 2D (desenhada à mão ou gerada) se já existir; senão cai pro boneco 3D ao vivo
func _retrato_heroi(id: String, tam: Vector2) -> Control:
	if Gravador.disponivel(): return _retrato_papel(id, tam)
	var arq: String = APELIDO_ARQUIVO.get(id, id)
	if Tela.tex("s_" + arq): return Tela.imagem("s_" + arq, tam)
	return _retrato3d(id, tam)

# retrato = a própria figura de papel gravada do personagem (mesma de campo), não uma ilustração à parte
func _retrato_papel(tipo: String, tam: Vector2) -> TextureRect:
	var t := TextureRect.new(); t.texture = Gravador.retrato(tipo)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.custom_minimum_size = tam; t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t

# bicho/chefe: usa o retrato 2D se já existir; senão (chefes novos, tipo o Minhocão) mostra o boneco 3D
func _retrato_bicho(tipo: String, tam: Vector2) -> Control:
	if Gravador.disponivel(): return _retrato_papel(tipo, tam)
	if Tela.tex("s_" + tipo): return Tela.imagem("s_" + tipo, tam)
	return _retrato3d(tipo, tam)

func _retrato3d(tipo: String, tam: Vector2) -> SubViewportContainer:
	var c := SubViewportContainer.new(); c.custom_minimum_size = tam; c.stretch = true; c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sv := SubViewport.new(); sv.own_world_3d = true; sv.transparent_bg = true; sv.size = Vector2i(tam)
	sv.render_target_update_mode = SubViewport.UPDATE_ALWAYS; c.add_child(sv)
	var b := Modelo.criar(tipo)
	sv.add_child(b)
	# bichos gigantes (corpo comprido, saindo da origem) precisam encolher, recentralizar e virar de frente pra caber no retrato
	var ajuste: Dictionary = {"minhocao": {"esc": 0.3, "pos": Vector3(0, -0.4, 2.0), "rot": 0.0, "cam_y": 0.35}}.get(tipo, {"esc": 1.0, "pos": Vector3.ZERO, "rot": 0.4, "cam_y": 1.12})
	b.scale = Vector3.ONE * float(ajuste["esc"]); b.position = ajuste["pos"]; b.rotation.y = float(ajuste["rot"])
	var cam := Camera3D.new(); cam.fov = 30.0; cam.position = Vector3(0, float(ajuste["cam_y"]), 4.6); sv.add_child(cam)
	# luz de três pontos (tipo foto de produto): principal + preenchimento + contorno por trás
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-32, 28, 0); l.light_energy = 1.25; l.light_color = Color(1.0, 0.98, 0.92); sv.add_child(l)
	var fill := DirectionalLight3D.new(); fill.rotation_degrees = Vector3(-18, -150, 0); fill.light_energy = 0.45; fill.light_color = Color(0.75, 0.85, 1.0); sv.add_child(fill)
	var rim := DirectionalLight3D.new(); rim.rotation_degrees = Vector3(25, 165, 0); rim.light_energy = 0.55; rim.light_color = Color(1.0, 0.95, 0.8); sv.add_child(rim)
	var env := Environment.new(); env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.ambient_light_color = Color.WHITE; env.ambient_light_energy = 0.55
	var we := WorldEnvironment.new(); we.environment = env; sv.add_child(we)
	# sombra suave no chão (gradiente radial via shader), pra dar um ar de "foto de produto" em vez de flutuar no vazio
	var sombra := MeshInstance3D.new(); var qm := QuadMesh.new(); qm.size = Vector2(1.5, 1.5) * float(ajuste["esc"])
	sombra.mesh = qm; sombra.rotation.x = -PI / 2.0; sombra.position = Vector3(ajuste["pos"].x, -0.02, ajuste["pos"].z)
	var ssh := Shader.new(); ssh.code = """
shader_type spatial;
render_mode unshaded, cull_disabled, blend_mix, depth_draw_never;
void fragment() {
	float d = length(UV - vec2(0.5));
	ALBEDO = vec3(0.08, 0.06, 0.05);
	ALPHA = smoothstep(0.5, 0.1, d) * 0.3;
}
"""
	var sm := ShaderMaterial.new(); sm.shader = ssh
	sombra.material_override = sm; sv.add_child(sombra)
	return c

func npc(tipo: String, fala: int) -> void:
	_limpar("npc")
	Tela.escuro(raiz, 0.72)
	var d: Dictionary = Dados.NPCS[tipo]
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var p := Tela.painel(Color(1.0, 0.97, 0.86)); cc.add_child(p)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 8); p.add_child(vb)
	var topo := HBoxContainer.new(); topo.add_theme_constant_override("separation", 16); vb.add_child(topo)
	var qd := PanelContainer.new(); qd.add_theme_stylebox_override("panel", Tela.caixa(Tela.PAPEL2, 3, Tela.TINTA, 4)); topo.add_child(qd)
	qd.add_child(_retrato3d(tipo, Vector2(150, 176)))
	var dv := VBoxContainer.new(); dv.add_theme_constant_override("separation", 6); dv.alignment = BoxContainer.ALIGNMENT_CENTER; topo.add_child(dv)
	dv.add_child(Tela.rotulo(tr(String(d["nome"])).to_upper(), 34, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true))
	dv.add_child(Tela.rotulo(d["de"], 14, Tela.URUCUM, HORIZONTAL_ALIGNMENT_LEFT, true))
	var balao := PanelContainer.new()
	var sb := Tela.caixa(Color.WHITE, 3, Tela.TINTA, 4, 14); sb.set_content_margin_all(12); sb.corner_radius_bottom_left = 0
	balao.add_theme_stylebox_override("panel", sb); dv.add_child(balao)
	var falas: Array = d["falas"]
	balao.add_child(Tela.texto(tr("“%s”") % tr(String(falas[fala % falas.size()])), 18, 520, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	vb.add_child(Tela.texto(d["txt"], 13, 720, Color(0.1, 0.07, 0.05, 0.8)))
	vb.add_child(Tela.faixa(tr("Você tem ◉ %d moedas nesta partida") % int(w.moedas), Tela.IPE, 15, Tela.TINTA))
	for it in d["itens"]:
		var id: String = it["id"]
		var preco: int = w.npc_preco(id, int(it["preco"]))
		var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 14); vb.add_child(hb)
		var v := VBoxContainer.new(); v.custom_minimum_size = Vector2(556, 0); v.add_theme_constant_override("separation", 0); hb.add_child(v)
		v.add_child(Tela.rotulo(tr(String(it["nome"])) + (tr("  (só uma vez)") if it.get("vez", false) else ""), 17, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true))
		v.add_child(Tela.texto(it["txt"], 13, 556, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
		var ac := func(): w.npc_comprar(tipo, it, preco, fala)
		var txt := tr("◉ %d") % preco if preco > 0 else tr("ACEITAR")
		if w.npc_feito.has(id): txt = tr("FEITO")
		var bt := Tela.botao(txt, ac, 16, Tela.URUCUM, 150.0, 40.0); bt.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		bt.disabled = w.npc_feito.has(id) or w.moedas < preco or not w.npc_pode(id)
		hb.add_child(bt)
	var bs := Tela.botao("AGRADECER E SEGUIR  (Esc)", w.fechar_loja, 17, Tela.PARDO, 320.0, 44.0); bs.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(bs)

# ---------------- ficha de apresentação de criatura ----------------
func lore(tipo: String) -> void:
	_limpar("lore")
	Tela.escuro(raiz, 0.7)
	var l: Dictionary = Dados.LORE[tipo]
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var p := Tela.painel(Color(1.0, 0.97, 0.86)); cc.add_child(p)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 10); p.add_child(vb)
	var topo := HBoxContainer.new(); vb.add_child(topo)
	var tit := Tela.rotulo(tr(String(l["nome"])).to_upper(), 38, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT, true); tit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	topo.add_child(tit)
	topo.add_child(Tela.botao("X", w.fechar_loja, 18, Tela.PARDO, 44.0, 40.0))
	vb.add_child(Tela.faixa(l["de"], Tela.URUCUM, 14))
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 18); vb.add_child(hb)
	var qd := PanelContainer.new(); qd.add_theme_stylebox_override("panel", Tela.caixa(Tela.PAPEL2, 3, Tela.TINTA, 4)); hb.add_child(qd)
	qd.add_child(_retrato_bicho(tipo, Vector2(170, 200)))
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 12); v.alignment = BoxContainer.ALIGNMENT_CENTER; hb.add_child(v)
	v.add_child(Tela.texto(l["txt"], 17, 470, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	v.add_child(Tela.texto(tr("No jogo: ") + tr(String(l["jeito"])), 15, 470, Tela.ANIL, HORIZONTAL_ALIGNMENT_LEFT))
	var ok := Tela.botao("OK", w.fechar_loja, 22, Tela.URUCUM, 220.0, 50.0); ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(ok)

# ---------------- fim da partida ----------------
# Resumo de fim de partida em formato de "capa de cordel": retrato + título gerado conforme a corrida,
# ficha de números e os golpes que o jogador montou — pensado pra virar print e passar de mão em mão.
func fim(titulo_txt: String, img: String, linhas: String, ganho: int, classe: String = "", cordel: String = "", golpes: Array = []) -> void:
	_limpar("fim")
	Tela.escuro(raiz, 0.7)
	var cc := CenterContainer.new(); cc.set_anchors_preset(Control.PRESET_FULL_RECT); raiz.add_child(cc)
	var p := Tela.painel(Color(1.0, 0.97, 0.86)); cc.add_child(p)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 10); p.add_child(vb)
	if img != "" and Tela.tex(img): vb.add_child(Tela.titulo(img, 48))
	if cordel != "":
		vb.add_child(Tela.texto(cordel.to_upper(), 20, 620, Tela.URUCUM))
	var corpo := HBoxContainer.new(); corpo.add_theme_constant_override("separation", 18); vb.add_child(corpo)
	if classe != "":
		var c: Dictionary = Dados.CLASSES[classe]
		var esq := VBoxContainer.new(); esq.add_theme_constant_override("separation", 4); corpo.add_child(esq)
		var palco_box := Control.new(); palco_box.custom_minimum_size = Vector2(190, 182); esq.add_child(palco_box)
		palco_box.add_child(PalcoGravura.novo(classe, Vector2(190, 182), Paleta.snap(c["cor"]).lerp(Tela.IPE, 0.35), false, false))
		esq.add_child(Tela.rotulo(tr(String(c["apelido"])), 16, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var dir := VBoxContainer.new(); dir.add_theme_constant_override("separation", 8); dir.custom_minimum_size = Vector2(360, 0); corpo.add_child(dir)
	dir.add_child(Tela.texto(linhas, 16, 360, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	if not golpes.is_empty():
		dir.add_child(Tela.rotulo(tr("GOLPES DA CORRIDA"), 13, Tela.PARDO, HORIZONTAL_ALIGNMENT_LEFT, true))
		var gi := GridContainer.new(); gi.columns = 6; gi.add_theme_constant_override("h_separation", 4); dir.add_child(gi)
		for g in golpes:
			var ic := Tela.imagem("a_" + String(Dados.GOLPES[g["id"]]["arte"]), Vector2(38, 26)); ic.tooltip_text = tr(String(Dados.GOLPES[g["id"]]["nome"])) + " — nível %d" % int(g["nivel"])
			gi.add_child(ic)
	var fx := Tela.faixa(tr("◉ +%d moedas") % ganho, Tela.IPE, 24, Tela.TINTA); vb.add_child(fx)
	var linha_bt := HBoxContainer.new(); linha_bt.add_theme_constant_override("separation", 10); linha_bt.alignment = BoxContainer.ALIGNMENT_CENTER; vb.add_child(linha_bt)
	var bt_print := Tela.botao("SALVAR PRINT DA CAPA", func(): pass, 15, Tela.IPE.darkened(0.15), 230.0, 48.0)
	bt_print.pressed.connect(func(): _salvar_capa(bt_print))
	linha_bt.add_child(bt_print)
	var ac_arraial := func(): get_tree().reload_current_scene()
	var bt := Tela.botao("VOLTAR AO ARRAIAL  (Enter)", ac_arraial, 18, Tela.URUCUM, 300.0, 52.0)
	linha_bt.add_child(bt)

func _salvar_capa(bt: Button) -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://capas"))
	var caminho := ProjectSettings.globalize_path("user://capas/capa_%d.png" % Time.get_unix_time_from_system())
	await get_tree().process_frame
	var img := get_viewport().get_texture().get_image()
	img.save_png(caminho)
	var original := bt.text
	bt.text = "SALVO! " + caminho.get_file()
	await get_tree().create_timer(2.5).timeout
	if is_instance_valid(bt): bt.text = original

# ESC: volta um passo na tela em que estiver
func esc() -> void:
	match tela:
		"pausa": w.continuar()
		"loja", "lore", "npc": w.fechar_loja()
		"opcoes": Salvo.salvar(); _volta.call()
		"herois", "melhorias", "feitos": titulo()
		"coop": Rede.sair(); titulo()
		"pergtut": herois()
