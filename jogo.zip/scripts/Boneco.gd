extends Node3D
class_name Boneco
# O boneco que o jogo usa (heróis, bichos, chefes, gente do mapa). Interface única e estável:
#   criar(tipo, destaque), animar(delta, andando, ritmo), atacar(), girar(), bater(),
#   tonto, saltita, cor_base, rotation.y (pra onde olha), scale.
# Por dentro hoje é uma FIGURA DE PAPEL GRAVADA (Cartao + Gravador): uma xilogravura recortada, em pé, virada pra
# câmera, que se mexe como boneco de mamulengo. Sem tela (testes automáticos) ou se a gravura estiver desligada,
# cai no modelo 3D antigo (Modelo.gd), que se comporta exatamente como antes.

var _modelo: Modelo          # só no modo 3D
var cartao: Cartao           # só no modo gravura
var corpo: Node3D
var perna_e: Node3D
var perna_d: Node3D
var braco_e: Node3D
var braco_d: Node3D
var saltita := false
var cor_base := Color.WHITE
var tonto := false
var t := 0.0
var atk_t := 0.0
var giro_t := 0.0
var bate_t := 0.0

static func criar(tipo: String, destaque = null) -> Boneco:
	var b := Boneco.new()
	b._montar(tipo, destaque)
	return b

func _montar(tipo: String, destaque) -> void:
	if not Gravador.disponivel():
		_modelo = Modelo.criar(tipo, destaque)
		add_child(_modelo)
		corpo = _modelo.corpo; perna_e = _modelo.perna_e; perna_d = _modelo.perna_d
		braco_e = _modelo.braco_e; braco_d = _modelo.braco_d
		cor_base = _modelo.cor_base; saltita = _modelo.saltita
		return
	corpo = Node3D.new(); add_child(corpo)
	cartao = Cartao.novo(tipo, destaque, true)
	corpo.add_child(cartao)
	saltita = tipo == "saci"
	cor_base = Gravador.cor_base(tipo, destaque)

func atacar() -> void:
	if _modelo: _modelo.atacar()
	else: atk_t = 0.28
func girar() -> void:
	if _modelo: _modelo.girar()
	else: giro_t = 0.32
func bater() -> void:
	if _modelo: _modelo.bater()
	else: bate_t = 0.12

func animar(delta: float, andando: bool, ritmo: float = 1.0) -> void:
	if _modelo:
		_modelo.tonto = tonto
		_modelo.animar(delta, andando, ritmo)
		return
	cartao.animar(self, delta, andando, ritmo)
