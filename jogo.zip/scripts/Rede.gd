extends Node
# Rede: a base do co-op por LAN (rede local), até 5 pessoas — 1 anfitrião + 4 convidados.
# Autoload (acessa-se por "Rede" de qualquer script). Usa o sistema de multiplayer de alto nível do Godot (ENet).
#
# ESTADO DE VERDADE (pra não enganar ninguém): isso aqui já conecta de verdade — bicho, chefe (de fase e a Cuca
# do portal), mapa (pote/baú/oratório/loja/portal/gente), dano, XP e moeda já são compartilhados de verdade
# (autoridade do anfitrião, ver World.gd). O que AINDA NÃO FOI FEITO: a carta de nível de cada um não aparece
# visualmente pro parceiro (hoje cada um ainda sobe sozinho, sem avisar o outro — funciona, só não é visto).

const PORTA := 7777
const MAX_JOGADORES := 5     # contando o anfitrião
const PORTA_DESCOBERTA := 7778   # UDP à parte, só pra anunciar/achar mundo hospedado na rede local

# ---------- RELAY (joga com qualquer um, sem abrir porta — roda na casa de quem hospeda o relay) ----------
# server/relay.py fica numa casa (porta UDP liberada uma vez só) e repassa pacote por código de sala;
# server/tunel.py roda local (anfitrião e convidado) fazendo o ENet conversar com o relay. Ver server/LEIA-ME.md.
const RELAY_HOST := "cordel-diogo.duckdns.org"   # relay rodando na casa do Diogo (server/relay.py)
const RELAY_PORTA := 40000
const PORTA_TUNEL_CONVIDADO := 17777             # porta local onde o túnel do convidado escuta (o ENet cliente conecta aqui)
# ---- SERVIDOR DEDICADO (rodando no PC do Diogo): ninguém é anfitrião, todo mundo entra como convidado ----
const SERVIDOR_HOST := "cordel-diogo.duckdns.org"
const SERVIDOR_PORTA := 40000
var dedicado := false          # a sala é de um servidor dedicado: o id 1 é só a máquina que roda o mundo, não é jogador
var partida_rolando := false   # (servidor) já começou: não aceita mais ninguém até o mundo reiniciar
var _no_lobby := {}            # (servidor) quem já voltou pro lobby depois da partida
var _alvo_servidor := false    # (cliente) estou tentando entrar no servidor dedicado
var _sala_relay := ""        # código da sala quando a conexão usa o relay (anfitrião ou convidado)
var _pid_tunel := -1         # processo do tunel.py rodando agora (pra matar ao sair)

var _udp_escuta: PacketPeerUDP    # sempre ligado: escuta quem está anunciando mundo na rede
var _udp_anuncio: PacketPeerUDP  # só quando eu sou o anfitrião: manda o anúncio
var _anuncio_t := 0.0
var _nome_mundo_host := ""
var mundos_vistos := {}          # ip (String) -> {"nome": String, "visto": float}
signal mundos_mudaram()

var heroi_por_id := {}       # peer_id (int) -> id da classe escolhida por essa pessoa
var nome_por_id := {}        # peer_id (int) -> nome que a pessoa digitou
var _ligado := false         # o Godot sempre bota um "OfflineMultiplayerPeer" por padrão, então
                              # não dá pra usar "multiplayer_peer != null" pra saber se o co-op tá de verdade ligado

# --- co-op pela internet: o anfitrião tenta abrir a porta no roteador sozinho (UPnP) ---
# upnp_estado: "" (não tentou) | "procurando" | "aberto" | "falhou"
var upnp_estado := ""
var upnp_motivo := ""          # por que não abriu (texto pra mostrar na tela)
var ip_publico := ""
var _upnp: UPNP
var _upnp_thread: Thread
signal upnp_mudou()

signal nome_mudou(id: int)
signal entrou(id: int)
signal saiu(id: int)
signal partida_comecou(fase: int)
signal falhou(motivo: String)

func _ready() -> void:
	multiplayer.peer_connected.connect(func(id):
		entrou.emit(id)
		if sou_host():
			if dedicado: _avisar_dedicado.rpc_id(id)      # servidor dedicado: cada um joga com o PRÓPRIO progresso
			else: _mandar_mundo.rpc_id(id, Salvo.d))     # novo convidado: recebe o progresso deste mundo emprestado
	multiplayer.peer_disconnected.connect(func(id):
		heroi_por_id.erase(id); nome_por_id.erase(id); _no_lobby.erase(id); saiu.emit(id))
	multiplayer.connection_failed.connect(func():
		_ligado = false; Salvo.sair_mundo()
		falhou.emit("Servidor do Diogo: não consegui conectar. Pode ter uma partida rolando (espere acabar) ou o PC dele estar desligado." if _alvo_servidor else "Não consegui conectar. Confira o código e a internet. Se a partida já começou, a sala está fechada: peça pro anfitrião abrir outra."))
	multiplayer.server_disconnected.connect(func(): _ligado = false; Salvo.sair_mundo(); falhou.emit("O anfitrião saiu da sala."))
	_udp_escuta = PacketPeerUDP.new()
	if _udp_escuta.bind(PORTA_DESCOBERTA) != OK: _udp_escuta = null   # porta já em uso (ex.: 2 instâncias no mesmo PC) — sem problema, só não descobre sozinho

func _process(delta: float) -> void:
	if ativo() and sou_host():
		_anuncio_t -= delta
		if _anuncio_t <= 0.0: _anuncio_t = 1.5; _anunciar()
	_escutar_anuncios()
	var agora := Time.get_ticks_msec() / 1000.0
	for ip in mundos_vistos.keys().duplicate():
		if agora - mundos_vistos[ip]["visto"] > 4.0: mundos_vistos.erase(ip); mundos_mudaram.emit()

func _anunciar() -> void:
	if _udp_anuncio == null:
		_udp_anuncio = PacketPeerUDP.new()
		_udp_anuncio.set_broadcast_enabled(true)
		_udp_anuncio.set_dest_address("255.255.255.255", PORTA_DESCOBERTA)
	_udp_anuncio.put_packet(("CORDEL_MUNDO:" + _nome_mundo_host).to_utf8_buffer())

func _escutar_anuncios() -> void:
	if _udp_escuta == null: return
	while _udp_escuta.get_available_packet_count() > 0:
		var pct := _udp_escuta.get_packet()
		var ip := _udp_escuta.get_packet_ip()
		var txt := pct.get_string_from_utf8()
		if txt.begins_with("CORDEL_MUNDO:") and ip != "":
			var nome := txt.substr(17)
			var novo := not mundos_vistos.has(ip)
			mundos_vistos[ip] = {"nome": nome, "visto": Time.get_ticks_msec() / 1000.0}
			if novo: mundos_mudaram.emit()

@rpc("authority", "call_remote", "reliable")
func _mandar_mundo(dados: Dictionary) -> void:
	Salvo.entrar_mundo_visitante(dados)

# servidor dedicado: sem UPnP, sem relay, sem anúncio — o roteador já encaminha a porta e o firewall já libera
func hospedar_servidor(porta: int = SERVIDOR_PORTA) -> String:
	var peer := ENetMultiplayerPeer.new()
	var erro := peer.create_server(porta, MAX_JOGADORES)
	if erro != OK: return "Não consegui abrir a porta UDP %d (erro %d). Outro programa já usa ela? (o relay antigo?)" % [porta, erro]
	multiplayer.multiplayer_peer = peer
	_ligado = true; dedicado = true; partida_rolando = false
	heroi_por_id.clear(); nome_por_id.clear(); _no_lobby.clear()
	return ""

@rpc("authority", "call_remote", "reliable")
func _avisar_dedicado() -> void:
	dedicado = true
	entrou.emit(1)                      # a tela da sala se refaz (agora com o botão de começar)

# qualquer um da sala pode pedir pra começar (não tem anfitrião sentado na frente do servidor)
func pedir_comecar(fase: int) -> void:
	if sou_host(): comecar(fase)
	else: _pedir_comecar.rpc_id(1, fase)

@rpc("any_peer", "call_remote", "reliable")
func _pedir_comecar(fase: int) -> void:
	if not (sou_host() and dedicado) or partida_rolando or ids().is_empty(): return
	comecar(clampi(fase, 0, Dados.FASES.size() - 1))

# (cliente) voltei pro lobby depois da partida: o servidor só reinicia o mundo quando todo mundo voltou
func avisar_lobby() -> void:
	if ativo() and dedicado and not sou_host(): _estou_no_lobby.rpc_id(1)

@rpc("any_peer", "call_remote", "reliable")
func _estou_no_lobby() -> void:
	if sou_host(): _no_lobby[multiplayer.get_remote_sender_id()] = true

func todos_no_lobby() -> bool:
	for id in ids():
		if not _no_lobby.has(id): return false
	return true

# (servidor) mundo novo: quem ainda não voltou pro lobby é desconectado, depois a sala reabre
func reabrir_sala(expulsar_fora_do_lobby: bool = false) -> void:
	if expulsar_fora_do_lobby and multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		for id in ids():
			if not _no_lobby.has(id): (multiplayer.multiplayer_peer as ENetMultiplayerPeer).disconnect_peer(id)
	_no_lobby.clear(); partida_rolando = false
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer: (multiplayer.multiplayer_peer as ENetMultiplayerPeer).refuse_new_connections = false

func hospedar(nome_mundo: String) -> String:
	if nome_mundo.strip_edges() == "":
		var nj := String(Salvo.d.get("nome_jogador", "")).strip_edges()
		nome_mundo = "Mundo de " + (nj if nj != "" else "Cordel")
	var peer := ENetMultiplayerPeer.new()
	var erro := peer.create_server(PORTA, MAX_JOGADORES - 1)
	if erro != OK: return "Não consegui abrir a porta %d (erro %d). Outro programa já está usando ela?" % [PORTA, erro]
	multiplayer.multiplayer_peer = peer
	_ligado = true
	_nome_mundo_host = nome_mundo.strip_edges()
	Salvo.entrar_mundo(_nome_mundo_host)
	heroi_por_id.clear(); nome_por_id.clear()
	_abrir_porta_upnp()
	firewall_estado = ""; checar_firewall()
	_iniciar_relay_anfitriao()
	return ""

# ---------- RELAY: caminho alternativo que não depende de porta aberta em NENHUM roteador ----------
func _caminho_tunel() -> String:
	var candidatos := [
		ProjectSettings.globalize_path("res://../server/tunel.py"),       # rodando de dentro do projeto (editor/teste)
		OS.get_executable_path().get_base_dir() + "/server/tunel.py",     # jogo instalado: tunel.py do lado do Cordel.exe
	]
	for c in candidatos:
		if FileAccess.file_exists(c): return c
	return ""

func _gerar_codigo_relay() -> String:
	return "%05d" % (randi() % 100000)   # só 5 dígitos: mais fácil de ditar/digitar que o de 8

func _matar_tunel() -> void:
	if _pid_tunel > 0 and OS.is_process_running(_pid_tunel): OS.kill(_pid_tunel)
	_pid_tunel = -1

# OS.create_process() não faz a busca de PATH que um terminal faz ("python" sozinho falha mesmo
# instalado) e passar por "cmd.exe /c" pra resolver isso tem um problema clássico de requoting (o cmd
# reinterpreta aspas do caminho e quebra com espaço/hífen) — então acha o .exe de verdade UMA vez com
# "where"/"which" e chama ele direto, sem nenhum interpretador de comando no meio.
var _python_resolvido := ""
func _python() -> String:
	if _python_resolvido != "": return _python_resolvido
	var saida := []
	var cmd := "where" if OS.get_name() == "Windows" else "which"
	var nome := "python" if OS.get_name() == "Windows" else "python3"
	OS.execute(cmd, [nome], saida, true)
	var linhas := String(saida[0] if saida.size() > 0 else "").split("\n")
	for l in linhas:
		var p := l.strip_edges()
		if p != "" and FileAccess.file_exists(p): _python_resolvido = p; break
	return _python_resolvido

func _lancar_tunel(args: PackedStringArray) -> int:
	var py := _python()
	if py == "": return -1
	return OS.create_process(py, args)

# anfitrião: o servidor ENet já está escutando em PORTA; só falta o túnel levar os pacotes até o relay
func _iniciar_relay_anfitriao() -> void:
	var tunel := _caminho_tunel()
	if tunel == "": _sala_relay = ""; return   # sem tunel.py disponível: esse jeito de conectar some da lista sozinho
	_sala_relay = _gerar_codigo_relay()
	_pid_tunel = _lancar_tunel(["-u", tunel,
		"--papel", "anfitriao", "--sala", _sala_relay, "--relay", "%s:%d" % [RELAY_HOST, RELAY_PORTA],
		"--porta-jogo", str(PORTA)])
	if _pid_tunel <= 0: _sala_relay = ""   # sem Python disponível: esse jeito de conectar some da lista sozinho

# convidado: lança o túnel (que finge ser "o anfitrião" em 127.0.0.1:PORTA_TUNEL_CONVIDADO) e conecta nele
func _entrar_relay(codigo: String) -> String:
	var tunel := _caminho_tunel()
	if tunel == "": return "Este jeito de entrar precisa do jogo instalado de verdade (faltam os arquivos do túnel)."
	_sala_relay = codigo
	_pid_tunel = _lancar_tunel(["-u", tunel,
		"--papel", "convidado", "--sala", codigo, "--relay", "%s:%d" % [RELAY_HOST, RELAY_PORTA],
		"--porta-local", str(PORTA_TUNEL_CONVIDADO)])
	if _pid_tunel <= 0: return "Não consegui iniciar o túnel (precisa de Python instalado)."
	await get_tree().create_timer(0.4).timeout   # dá tempo do túnel abrir a porta local antes do ENet tentar conectar
	return await entrar("127.0.0.1:%d" % PORTA_TUNEL_CONVIDADO)

static func parece_codigo_relay(txt: String) -> bool:
	var c := txt.strip_edges()
	return c.length() == 5 and c.is_valid_int()

# Procura o roteador e pede pra encaminhar a porta UDP. Roda numa thread (a busca demora ~2s).
# Não funciona em todo roteador/provedor (CGNAT, UPnP desligado): nesse caso o menu avisa e o amigo
# pode entrar por VPN (Tailscale/ZeroTier) usando o endereço dela.
func _abrir_porta_upnp() -> void:
	if _upnp_thread != null: return
	upnp_estado = "procurando"; ip_publico = ""
	upnp_mudou.emit()
	_upnp_thread = Thread.new()
	_upnp_thread.start(_upnp_trabalho)

# botão "tentar de novo" do menu (se o UPnP falhou, por exemplo porque o roteador demorou a responder)
func tentar_porta_de_novo() -> void:
	if sou_host() and upnp_estado == "falhou": _abrir_porta_upnp()

func _upnp_trabalho() -> void:
	var u := UPNP.new()
	var ok := false
	var ip := ""
	var motivo := ""
	var r := u.discover(2500, 2, "InternetGatewayDevice")
	if r != UPNP.UPNP_RESULT_SUCCESS or u.get_gateway() == null or not u.get_gateway().is_valid_gateway():
		r = u.discover(4000, 4, "")                       # segunda tentativa: busca mais larga
	var gw := u.get_gateway()
	if r != UPNP.UPNP_RESULT_SUCCESS or gw == null or not gw.is_valid_gateway():
		motivo = "Não achei o roteador: o UPnP deve estar desligado nele (ou o PC está em Wi-Fi de visitantes / VPN)."
	else:
		# muitos roteadores só aceitam mapeamento PERMANENTE (lease 0); outros recusam se já existe um igual: tenta os dois jeitos
		var cod := u.add_port_mapping(PORTA, PORTA, "Cordel", "UDP", 7200)
		if cod != UPNP.UPNP_RESULT_SUCCESS:
			u.delete_port_mapping(PORTA, "UDP")
			cod = u.add_port_mapping(PORTA, PORTA, "Cordel", "UDP", 0)
		if cod == UPNP.UPNP_RESULT_SUCCESS:
			ok = true
			ip = u.query_external_address()
			if ip == "" or ip == "0.0.0.0": ok = false; motivo = "O roteador abriu a porta mas não disse qual é o seu endereço na internet."
			elif _ip_privado(ip):
				ok = false
				motivo = "Seu provedor compartilha o endereço com outras casas (CGNAT): a porta aberta no roteador não chega na internet. Use uma VPN (Tailscale)."
		else:
			motivo = "O roteador recusou abrir a porta (erro %d). Abra a porta UDP %d à mão no roteador, ou use uma VPN (Tailscale)." % [cod, PORTA]
	_upnp = u
	_upnp_fim.call_deferred(ok, ip, motivo)

static func _ip_privado(ip: String) -> bool:
	var p := ip.split(".")
	if p.size() != 4: return false
	var a := int(p[0]); var b := int(p[1])
	return a == 10 or a == 127 or (a == 192 and b == 168) or (a == 172 and b >= 16 and b <= 31) or (a == 100 and b >= 64 and b <= 127) or (a == 169 and b == 254)

func _upnp_fim(ok: bool, ip: String, motivo: String = "") -> void:
	if _upnp_thread != null:
		_upnp_thread.wait_to_finish(); _upnp_thread = null
	if not _ligado:     # a pessoa já saiu da sala enquanto procurava
		_fechar_upnp(); upnp_estado = ""; return
	ip_publico = ip if ok else ""
	upnp_motivo = motivo
	upnp_estado = "aberto" if ok and ip != "" else "falhou"
	upnp_mudou.emit()

# ---------- FIREWALL DO WINDOWS: a regra "Cordel" (UDP 7777). Sem ela o Windows pode bloquear os amigos mesmo com o roteador aberto ----------
var firewall_estado := ""          # "" (não olhei) | "ok" | "faltando" | "pedindo" | "naoaplica" (não é Windows)
var _fw_tentativas := 0

static func _windows() -> bool:
	return OS.get_name() == "Windows"

func checar_firewall() -> void:
	if not _windows(): firewall_estado = "naoaplica"; upnp_mudou.emit(); return
	var saida := []
	var cod := OS.execute("netsh", ["advfirewall", "firewall", "show", "rule", "name=Cordel"], saida, true)
	firewall_estado = "ok" if cod == 0 else ("pedindo" if firewall_estado == "pedindo" and _fw_tentativas < 45 else "faltando")
	upnp_mudou.emit()

# pede ao Windows (janela do "Controle de Conta de Usuário": o usuário clica em SIM) pra criar a regra do Firewall
func pedir_firewall() -> void:
	if not _windows(): return
	firewall_estado = "pedindo"; _fw_tentativas = 0; upnp_mudou.emit()
	OS.create_process("powershell", ["-NoProfile", "-WindowStyle", "Hidden", "-Command",
		"Start-Process -FilePath netsh -Verb RunAs -WindowStyle Hidden -ArgumentList 'advfirewall firewall add rule name=Cordel dir=in action=allow protocol=UDP localport=%d profile=any'" % PORTA])
	_esperar_firewall()

func _esperar_firewall() -> void:
	await get_tree().create_timer(1.5).timeout
	_fw_tentativas += 1
	checar_firewall()
	if firewall_estado == "pedindo" and _ligado: _esperar_firewall()

func _fechar_upnp() -> void:
	if _upnp != null:
		var gw := _upnp.get_gateway()
		if gw != null and gw.is_valid_gateway(): _upnp.delete_port_mapping(PORTA, "UDP")
		_upnp = null

func _exit_tree() -> void:
	_fechar_upnp()
	_matar_tunel()   # se o jogo fechar sem clicar em "sair" da sala, o túnel não fica rodando sozinho pra sempre

func entrar(ip: String) -> String:
	var alvo := ip.strip_edges()
	if alvo == "": return "Digite o código da sala."
	_alvo_servidor = alvo.to_lower().begins_with(SERVIDOR_HOST)
	if parece_codigo_relay(alvo):
		return await _entrar_relay(alvo)
	if parece_codigo(alvo):
		alvo = ip_de_codigo(alvo)
		if alvo == "": return "Código inválido: confira as letras e números (são 8, tipo K7QM-4TZ9)."
	var porta := PORTA
	if alvo.count(":") == 1:                 # "ip:porta" (quando o anfitrião usa outra porta no roteador)
		var partes := alvo.split(":"); alvo = partes[0].strip_edges(); porta = int(partes[1])
		if porta < 1 or porta > 65535: return "Porta inválida."
	var peer := ENetMultiplayerPeer.new()
	var erro := peer.create_client(alvo, porta)
	if erro != OK: return "Endereço inválido."
	multiplayer.multiplayer_peer = peer
	_ligado = true
	heroi_por_id.clear(); nome_por_id.clear()
	return ""

func sair() -> void:
	dedicado = false; partida_rolando = false; _no_lobby.clear(); _alvo_servidor = false
	if multiplayer.multiplayer_peer: multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null
	_ligado = false
	_nome_mundo_host = ""
	if _udp_anuncio: _udp_anuncio.close(); _udp_anuncio = null
	if _upnp_thread == null: _fechar_upnp()
	upnp_estado = ""; ip_publico = ""
	_matar_tunel(); _sala_relay = ""
	Salvo.sair_mundo()
	heroi_por_id.clear(); nome_por_id.clear()

func ativo() -> bool:
	return _ligado

func sou_host() -> bool:
	return ativo() and multiplayer.is_server()

func meu_id() -> int:
	return multiplayer.get_unique_id()

# todo mundo conectado (inclusive eu), sempre na mesma ordem em todas as máquinas
func ids() -> Array:
	if not ativo(): return [meu_id()]
	var r: Array = multiplayer.get_peers()
	r.append(meu_id())
	r.sort()
	if dedicado: r.erase(1)            # servidor dedicado: o id 1 é a máquina, não um jogador
	return r

# endereços desta máquina na rede local (pra mostrar pro anfitrião passar pros amigos)
# ---------- CÓDIGO CURTO DA SALA ----------
# O código é o endereço IPv4 do anfitrião escrito em 8 letras/números (7 + 1 de conferência), tipo "K7QM-4TZ9".
# Alfabeto sem 0/O/1/I pra ninguém confundir. Quem entra digita o código; o jogo decodifica e conecta.
const ALFA := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

static func codigo_de_ip(ip: String) -> String:
	var p := ip.split(".")
	if p.size() != 4: return ""
	var n := 0
	for x in p:
		if not x.is_valid_int(): return ""
		var v := int(x)
		if v < 0 or v > 255: return ""
		n = (n << 8) | v
	var letras := ""; var soma := 0
	for i in range(6, -1, -1):
		var idx := (n >> (5 * i)) & 31
		letras += ALFA[idx]; soma += idx
	letras += ALFA[(soma * 7 + 3) % 32]
	return letras.substr(0, 4) + "-" + letras.substr(4)

# devolve o IP, ou "" se o código estiver errado (letra trocada, faltando...)
static func ip_de_codigo(codigo: String) -> String:
	var c := codigo.to_upper().replace("-", "").replace(" ", "").strip_edges()
	if c.length() != 8: return ""
	var n := 0; var soma := 0
	for i in range(7):
		var idx := ALFA.find(c[i])
		if idx < 0: return ""
		n = (n << 5) | idx; soma += idx
	if ALFA.find(c[7]) != (soma * 7 + 3) % 32: return ""
	return "%d.%d.%d.%d" % [(n >> 24) & 255, (n >> 16) & 255, (n >> 8) & 255, n & 255]

static func parece_codigo(txt: String) -> bool:
	var t := txt.strip_edges()
	return t != "" and not t.contains(".") and not t.contains(":")

# os jeitos de achar esta sala, do melhor pro pior: [{"rotulo","ip","codigo"}]
func enderecos_da_sala() -> Array:
	var r: Array = []
	if ip_publico != "": r.append({"rotulo": "Internet", "ip": ip_publico, "codigo": codigo_de_ip(ip_publico)})
	if _sala_relay != "": r.append({"rotulo": "Relay (sem abrir porta)", "ip": "", "codigo": _sala_relay})
	for ip in IP.get_local_addresses():
		var p := String(ip).split(".")
		if p.size() == 4 and int(p[0]) == 100 and int(p[1]) >= 64 and int(p[1]) <= 127:
			r.append({"rotulo": "VPN", "ip": ip, "codigo": codigo_de_ip(ip)})
	for ip in meus_enderecos():
		r.append({"rotulo": "Mesma casa", "ip": ip, "codigo": codigo_de_ip(ip)})
	return r

static func meus_enderecos() -> Array:
	var r := []
	for ip in IP.get_local_addresses():
		if ip.begins_with("192.168.") or ip.begins_with("10.") or ip.begins_with("172."):
			r.append(ip)
	return r

# mundos hospedados vistos agora na rede local, pra listar na tela de entrar em vez de pedir o IP na mão
func mundos_disponiveis() -> Array:
	var r := []
	for ip in mundos_vistos: r.append({"ip": ip, "nome": mundos_vistos[ip]["nome"]})
	r.sort_custom(func(a, b): return a["nome"] < b["nome"])
	return r

# Nome do jogador local. É AQUI que entra o nome da Steam no futuro (Steam.getPersonaName()): o resto do jogo só chama isto.
static func nome_local() -> String:
	return limpar_nome(String(Salvo.d.get("nome_jogador", "")))

# tira espaços e caracteres de controle, limita o tamanho. Vazio continua vazio (quem recebe escolhe "Jogador N").
static func limpar_nome(n: String) -> String:
	var r := ""
	for ch in n.strip_edges():
		if ch.unicode_at(0) >= 32 and ch.unicode_at(0) != 127: r += ch
	return r.substr(0, 16).strip_edges()

@rpc("any_peer", "call_local", "reliable")
func _apresentar(id: int, heroi: String, nome: String) -> void:
	var quem := multiplayer.get_remote_sender_id()
	if quem != 0: id = quem            # o nome é de quem mandou: ninguém se apresenta no lugar de outro
	if not Dados.CLASSES.has(heroi): heroi = "capoeirista"
	heroi_por_id[id] = heroi
	var n := limpar_nome(nome)
	nome_por_id[id] = n if n != "" else ("Jogador %03d" % (absi(id) % 1000))      # igual em todas as máquinas (sai do próprio id)
	nome_mudou.emit(id)

func apresentar_se(heroi: String, nome: String) -> void:
	_apresentar.rpc(meu_id(), heroi, nome_local() if nome == "" else nome)

@rpc("authority", "call_local", "reliable")
func _comecar(fase: int) -> void:
	partida_comecou.emit(fase)

# só o anfitrião manda começar, pra todo mundo ao mesmo tempo
func comecar(fase: int = 0) -> void:
	if not sou_host(): return
	# a sala fecha quando a partida começa: quem chegasse depois ficaria preso no menu (sem o mapa e os bichos que já existem)
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer: (multiplayer.multiplayer_peer as ENetMultiplayerPeer).refuse_new_connections = true
	partida_rolando = true
	_comecar.rpc(fase)
