extends Node
# Rede: a base do co-op por LAN (rede local), até 5 pessoas — 1 anfitrião + 4 convidados.
# Autoload (acessa-se por "Rede" de qualquer script). Usa o sistema de multiplayer de alto nível do Godot (ENet).
#
# ESTADO DE VERDADE (pra não enganar ninguém): isso aqui já conecta de verdade — bicho, chefe (de fase e a Cuca
# do portal), mapa (pote/baú/oratório/loja/portal/gente), dano, XP e moeda já são compartilhados de verdade
# (autoridade do anfitrião, ver World.gd). O que AINDA NÃO FOI FEITO: a carta de nível de cada um não aparece
# visualmente pro parceiro (hoje cada um ainda sobe sozinho, sem avisar o outro — funciona, só não é visto).

const PORTA := 7777
const MAX_JOGADORES := 5     # contando o anfitrião
const PORTA_DESCOBERTA := 7778   # UDP à parte, só pra anunciar/achar mundo hospedado na rede local

var _udp_escuta: PacketPeerUDP    # sempre ligado: escuta quem está anunciando mundo na rede
var _udp_anuncio: PacketPeerUDP  # só quando eu sou o anfitrião: manda o anúncio
var _anuncio_t := 0.0
var _nome_mundo_host := ""
var mundos_vistos := {}          # ip (String) -> {"nome": String, "visto": float}
signal mundos_mudaram()

var heroi_por_id := {}       # peer_id (int) -> id da classe escolhida por essa pessoa
var nome_por_id := {}        # peer_id (int) -> nome que a pessoa digitou
var _ligado := false         # o Godot sempre bota um "OfflineMultiplayerPeer" por padrão, então
                              # não dá pra usar "multiplayer_peer != null" pra saber se o co-op tá de verdade ligado

# --- co-op pela internet: o anfitrião tenta abrir a porta no roteador sozinho (UPnP) ---
# upnp_estado: "" (não tentou) | "procurando" | "aberto" | "falhou"
var upnp_estado := ""
var ip_publico := ""
var _upnp: UPNP
var _upnp_thread: Thread
signal upnp_mudou()

signal entrou(id: int)
signal saiu(id: int)
signal partida_comecou()
signal falhou(motivo: String)

func _ready() -> void:
	multiplayer.peer_connected.connect(func(id):
		entrou.emit(id)
		if sou_host(): _mandar_mundo.rpc_id(id, Salvo.d))     # novo convidado: recebe o progresso deste mundo emprestado
	multiplayer.peer_disconnected.connect(func(id):
		heroi_por_id.erase(id); nome_por_id.erase(id); saiu.emit(id))
	multiplayer.connection_failed.connect(func(): _ligado = false; Salvo.sair_mundo(); falhou.emit("Não consegui conectar. Confira o endereço e se os dois estão na mesma rede."))
	multiplayer.server_disconnected.connect(func(): _ligado = false; Salvo.sair_mundo(); falhou.emit("O anfitrião saiu da sala."))
	_udp_escuta = PacketPeerUDP.new()
	if _udp_escuta.bind(PORTA_DESCOBERTA) != OK: _udp_escuta = null   # porta já em uso (ex.: 2 instâncias no mesmo PC) — sem problema, só não descobre sozinho

func _process(delta: float) -> void:
	if ativo() and sou_host():
		_anuncio_t -= delta
		if _anuncio_t <= 0.0: _anuncio_t = 1.5; _anunciar()
	_escutar_anuncios()
	var agora := Time.get_ticks_msec() / 1000.0
	for ip in mundos_vistos.keys().duplicate():
		if agora - mundos_vistos[ip]["visto"] > 4.0: mundos_vistos.erase(ip); mundos_mudaram.emit()

func _anunciar() -> void:
	if _udp_anuncio == null:
		_udp_anuncio = PacketPeerUDP.new()
		_udp_anuncio.set_broadcast_enabled(true)
		_udp_anuncio.set_dest_address("255.255.255.255", PORTA_DESCOBERTA)
	_udp_anuncio.put_packet(("CORDEL_MUNDO:" + _nome_mundo_host).to_utf8_buffer())

func _escutar_anuncios() -> void:
	if _udp_escuta == null: return
	while _udp_escuta.get_available_packet_count() > 0:
		var pct := _udp_escuta.get_packet()
		var ip := _udp_escuta.get_packet_ip()
		var txt := pct.get_string_from_utf8()
		if txt.begins_with("CORDEL_MUNDO:") and ip != "":
			var nome := txt.substr(17)
			var novo := not mundos_vistos.has(ip)
			mundos_vistos[ip] = {"nome": nome, "visto": Time.get_ticks_msec() / 1000.0}
			if novo: mundos_mudaram.emit()

@rpc("authority", "call_remote", "reliable")
func _mandar_mundo(dados: Dictionary) -> void:
	Salvo.entrar_mundo_visitante(dados)

func hospedar(nome_mundo: String) -> String:
	if nome_mundo.strip_edges() == "":
		var nj := String(Salvo.d.get("nome_jogador", "")).strip_edges()
		nome_mundo = "Mundo de " + (nj if nj != "" else "Cordel")
	var peer := ENetMultiplayerPeer.new()
	var erro := peer.create_server(PORTA, MAX_JOGADORES - 1)
	if erro != OK: return "Não consegui abrir a porta %d (erro %d). Outro programa já está usando ela?" % [PORTA, erro]
	multiplayer.multiplayer_peer = peer
	_ligado = true
	_nome_mundo_host = nome_mundo.strip_edges()
	Salvo.entrar_mundo(_nome_mundo_host)
	heroi_por_id.clear(); nome_por_id.clear()
	_abrir_porta_upnp()
	return ""

# Procura o roteador e pede pra encaminhar a porta UDP. Roda numa thread (a busca demora ~2s).
# Não funciona em todo roteador/provedor (CGNAT, UPnP desligado): nesse caso o menu avisa e o amigo
# pode entrar por VPN (Tailscale/ZeroTier) usando o endereço dela.
func _abrir_porta_upnp() -> void:
	if _upnp_thread != null: return
	upnp_estado = "procurando"; ip_publico = ""
	upnp_mudou.emit()
	_upnp_thread = Thread.new()
	_upnp_thread.start(_upnp_trabalho)

# botão "tentar de novo" do menu (se o UPnP falhou, por exemplo porque o roteador demorou a responder)
func tentar_porta_de_novo() -> void:
	if sou_host() and upnp_estado == "falhou": _abrir_porta_upnp()

func _upnp_trabalho() -> void:
	var u := UPNP.new()
	var ok := false
	var ip := ""
	if u.discover(2000, 2, "InternetGatewayDevice") == UPNP.UPNP_RESULT_SUCCESS:
		var gw := u.get_gateway()
		if gw != null and gw.is_valid_gateway():
			ok = u.add_port_mapping(PORTA, PORTA, "Cordel", "UDP", 7200) == UPNP.UPNP_RESULT_SUCCESS
			ip = u.query_external_address()
	_upnp = u
	_upnp_fim.call_deferred(ok, ip)

func _upnp_fim(ok: bool, ip: String) -> void:
	if _upnp_thread != null:
		_upnp_thread.wait_to_finish(); _upnp_thread = null
	if not _ligado:     # a pessoa já saiu da sala enquanto procurava
		_fechar_upnp(); upnp_estado = ""; return
	ip_publico = ip if ok else ""
	upnp_estado = "aberto" if ok and ip != "" else "falhou"
	upnp_mudou.emit()

func _fechar_upnp() -> void:
	if _upnp != null:
		var gw := _upnp.get_gateway()
		if gw != null and gw.is_valid_gateway(): _upnp.delete_port_mapping(PORTA, "UDP")
		_upnp = null

func _exit_tree() -> void:
	_fechar_upnp()

func entrar(ip: String) -> String:
	var alvo := ip.strip_edges()
	if alvo == "": return "Digite o código da sala."
	if parece_codigo(alvo):
		alvo = ip_de_codigo(alvo)
		if alvo == "": return "Código inválido: confira as letras e números (são 8, tipo K7QM-4TZ9)."
	var porta := PORTA
	if alvo.count(":") == 1:                 # "ip:porta" (quando o anfitrião usa outra porta no roteador)
		var partes := alvo.split(":"); alvo = partes[0].strip_edges(); porta = int(partes[1])
		if porta < 1 or porta > 65535: return "Porta inválida."
	var peer := ENetMultiplayerPeer.new()
	var erro := peer.create_client(alvo, porta)
	if erro != OK: return "Endereço inválido."
	multiplayer.multiplayer_peer = peer
	_ligado = true
	heroi_por_id.clear(); nome_por_id.clear()
	return ""

func sair() -> void:
	if multiplayer.multiplayer_peer: multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null
	_ligado = false
	_nome_mundo_host = ""
	if _udp_anuncio: _udp_anuncio.close(); _udp_anuncio = null
	if _upnp_thread == null: _fechar_upnp()
	upnp_estado = ""; ip_publico = ""
	Salvo.sair_mundo()
	heroi_por_id.clear(); nome_por_id.clear()

func ativo() -> bool:
	return _ligado

func sou_host() -> bool:
	return ativo() and multiplayer.is_server()

func meu_id() -> int:
	return multiplayer.get_unique_id()

# todo mundo conectado (inclusive eu), sempre na mesma ordem em todas as máquinas
func ids() -> Array:
	if not ativo(): return [meu_id()]
	var r: Array = multiplayer.get_peers()
	r.append(meu_id())
	r.sort()
	return r

# endereços desta máquina na rede local (pra mostrar pro anfitrião passar pros amigos)
# ---------- CÓDIGO CURTO DA SALA ----------
# O código é o endereço IPv4 do anfitrião escrito em 8 letras/números (7 + 1 de conferência), tipo "K7QM-4TZ9".
# Alfabeto sem 0/O/1/I pra ninguém confundir. Quem entra digita o código; o jogo decodifica e conecta.
const ALFA := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

static func codigo_de_ip(ip: String) -> String:
	var p := ip.split(".")
	if p.size() != 4: return ""
	var n := 0
	for x in p:
		if not x.is_valid_int(): return ""
		var v := int(x)
		if v < 0 or v > 255: return ""
		n = (n << 8) | v
	var letras := ""; var soma := 0
	for i in range(6, -1, -1):
		var idx := (n >> (5 * i)) & 31
		letras += ALFA[idx]; soma += idx
	letras += ALFA[(soma * 7 + 3) % 32]
	return letras.substr(0, 4) + "-" + letras.substr(4)

# devolve o IP, ou "" se o código estiver errado (letra trocada, faltando...)
static func ip_de_codigo(codigo: String) -> String:
	var c := codigo.to_upper().replace("-", "").replace(" ", "").strip_edges()
	if c.length() != 8: return ""
	var n := 0; var soma := 0
	for i in range(7):
		var idx := ALFA.find(c[i])
		if idx < 0: return ""
		n = (n << 5) | idx; soma += idx
	if ALFA.find(c[7]) != (soma * 7 + 3) % 32: return ""
	return "%d.%d.%d.%d" % [(n >> 24) & 255, (n >> 16) & 255, (n >> 8) & 255, n & 255]

static func parece_codigo(txt: String) -> bool:
	var t := txt.strip_edges()
	return t != "" and not t.contains(".") and not t.contains(":")

# os jeitos de achar esta sala, do melhor pro pior: [{"rotulo","ip","codigo"}]
func enderecos_da_sala() -> Array:
	var r: Array = []
	if ip_publico != "": r.append({"rotulo": "Internet", "ip": ip_publico, "codigo": codigo_de_ip(ip_publico)})
	for ip in IP.get_local_addresses():
		var p := String(ip).split(".")
		if p.size() == 4 and int(p[0]) == 100 and int(p[1]) >= 64 and int(p[1]) <= 127:
			r.append({"rotulo": "VPN", "ip": ip, "codigo": codigo_de_ip(ip)})
	for ip in meus_enderecos():
		r.append({"rotulo": "Mesma casa", "ip": ip, "codigo": codigo_de_ip(ip)})
	return r

static func meus_enderecos() -> Array:
	var r := []
	for ip in IP.get_local_addresses():
		if ip.begins_with("192.168.") or ip.begins_with("10.") or ip.begins_with("172."):
			r.append(ip)
	return r

# mundos hospedados vistos agora na rede local, pra listar na tela de entrar em vez de pedir o IP na mão
func mundos_disponiveis() -> Array:
	var r := []
	for ip in mundos_vistos: r.append({"ip": ip, "nome": mundos_vistos[ip]["nome"]})
	r.sort_custom(func(a, b): return a["nome"] < b["nome"])
	return r

@rpc("any_peer", "call_local", "reliable")
func _apresentar(id: int, heroi: String, nome: String) -> void:
	heroi_por_id[id] = heroi
	nome_por_id[id] = nome if nome.strip_edges() != "" else ("Jogador %d" % (ids().find(id) + 1))

func apresentar_se(heroi: String, nome: String) -> void:
	_apresentar.rpc(meu_id(), heroi, nome)

@rpc("authority", "call_local", "reliable")
func _comecar() -> void:
	partida_comecou.emit()

# só o anfitrião manda começar, pra todo mundo ao mesmo tempo
func comecar() -> void:
	if sou_host(): _comecar.rpc()
