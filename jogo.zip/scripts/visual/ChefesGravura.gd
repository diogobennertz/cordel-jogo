extends Node2D
class_name ChefesGravura
# Os CHEFES desenhados à mão (em código), como gravuras de capa de folheto: massa de tinta com cortes de papel, pontas
# vermelhas e ocre. Não são o modelo 3D: cada chefe tem uma silhueta própria e reconhecível. O Gravador imprime 4 poses
# (parado, passo A, passo B, ataque) e faz o recorte de papel, como com qualquer outro personagem.
# Espaço de desenho: 400 x 300, origem no meio do chão (x) e nos pés (y); y negativo = pra cima.

const T := Color("201A17")
const P := Color("F0E9D7")
const R := Color("A83226")
const O := Color("D69A32")
const K := Color("874C35")
const KE := Color("5C3526")
const TEM := {"mapinguari": 2.2, "mula": 1.9, "boitata": 1.6, "cuca": 1.95, "minhocao": 2.5, "lobisomem": 2.3}      # altura do desenho em metros
const COR_BASE := {"mapinguari": Color("874C35"), "mula": Color("D69A32"), "boitata": Color("D69A32"), "cuca": Color("6F2924"), "minhocao": Color("874C35"), "lobisomem": Color("5C3526")}

var chefe := "mapinguari"
var pose := 0

func _bob() -> float: return [0.0, 7.0, 0.0, -4.0][pose]
func _pata() -> float: return [0.0, 1.0, -1.0, 0.0][pose]
func _boca() -> float: return [0.12, 0.12, 0.2, 1.0][pose]
func _atq() -> float: return 1.0 if pose == 3 else 0.0

func _v(a: Array) -> PackedVector2Array:
	var r := PackedVector2Array()
	for q in a: r.append(Vector2(q[0], q[1]))
	return r

func _poli(a: Array, col: Color) -> void: draw_colored_polygon(_v(a), col)

func _linha(a: Array, b: Array, w: float, col: Color) -> void: draw_line(Vector2(a[0], a[1]), Vector2(b[0], b[1]), col, w, true)

func _circ(x: float, y: float, r: float, col: Color) -> void: draw_circle(Vector2(x, y), r, col)

# elipse com a borda em dentes (pelo, escama): n pontas, amplitude amp
func _felpuda(cx: float, cy: float, rx: float, ry: float, n: int, amp: float, col: Color, fase: float = 0.0) -> void:
	var pts := PackedVector2Array()
	for i in range(n * 2):
		var a := TAU * i / (n * 2) + fase
		var k := 1.0 + (amp / rx if i % 2 == 0 else -amp * 0.5 / rx)
		pts.append(Vector2(cx + cos(a) * rx * k, cy + sin(a) * ry * k))
	draw_colored_polygon(pts, col)

func _chama(x: float, y: float, w: float, h: float, col: Color, sem: float = 0.0) -> void:
	var pts := [[x - w, y]]
	var n := 4
	for i in range(n):
		var tx := x - w + (i + 0.5) * (2.0 * w / n)
		var th := h * (0.62 + 0.38 * sin(sem * 3.1 + i * 2.3 + pose * 1.7))
		pts.append([tx - w / n * 0.35, y - th * 0.45]); pts.append([tx + sin(sem + i) * 6.0, y - th]); pts.append([tx + w / n * 0.35, y - th * 0.45])
	pts.append([x + w, y])
	_poli(pts, col)

func _draw() -> void:
	match chefe:
		"mapinguari": _mapinguari()
		"mula": _mula()
		"boitata": _boitata()
		"cuca": _cuca()
		"minhocao": _minhocao()
		"lobisomem": _lobisomem()

# ---------------- MAPINGUARI: peludão de um olho só, boca na barriga, garras enormes ----------------
func _mapinguari() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(0.88, 0.88))
	var b := _bob(); var pt := _pata(); var atq := _atq()
	for sx in [-1.0, 1.0]:                                          # pernas de tronco, com garras
		var x0: float = sx * 62.0 + sx * pt * 8.0
		_poli([[x0 - 34, -110 + b], [x0 + 34, -110 + b], [x0 + 42, -8], [x0 - 42, -8]], T)
		_poli([[x0 - 26, -104 + b], [x0 + 26, -104 + b], [x0 + 34, -14], [x0 - 34, -14]], K)
		for k in range(-1, 2):
			_poli([[x0 + k * 24 - 9, -10], [x0 + k * 24 + 9, -10], [x0 + k * 24, 12]], P)
	_felpuda(0, -170 + b, 142, 104, 15, 20, T)                      # o corpanzil peludo (contorno de tinta)
	_felpuda(0, -170 + b, 132, 94, 15, 18, K)
	_felpuda(0, -158 + b, 92, 68, 12, 11, O, 0.15)
	for i in range(18):                                             # fios de pelo em papel
		var a := i * 0.7 + 0.3
		var cx := cos(a) * 82.0 * (0.5 + 0.5 * fmod(i * 0.37, 1.0)); var cy := -160.0 + b + sin(a) * 52.0 * (0.4 + 0.6 * fmod(i * 0.53, 1.0))
		_linha([cx, cy], [cx + cos(a) * 15, cy + sin(a) * 15 + 8], 3.0, P)
	for sx in [-1.0, 1.0]:                                          # braços compridos
		var ombro := [sx * 118.0, -215.0 + b]
		var mao := [sx * (176.0 + atq * 14.0), -78.0 - atq * 120.0 + b]
		_linha(ombro, mao, 40.0, T); _linha(ombro, mao, 30.0, K)
		_circ(mao[0], mao[1], 28.0, T)
		for k in range(4):
			var ang := (-0.55 + k * 0.37) + (0.0 if sx > 0 else PI) * 0.0
			var base := Vector2(mao[0] + sx * (k - 1.5) * 12.0, mao[1] + 14.0)
			_poli([[base.x - 7, base.y], [base.x + 7, base.y], [base.x + sx * (k - 1.5) * 5.0, base.y + 46 + atq * 10]], P)
	_felpuda(0, -272 + b, 58, 52, 8, 12, T)                         # cabeça
	_circ(0, -272 + b, 47, K)
	_circ(0, -274 + b, 28, P); draw_arc(Vector2(0, -274 + b), 28, 0, TAU, 28, R, 5.0, true)      # o olho único
	_poli([[0, -296 + b], [11, -274 + b], [0, -252 + b], [-11, -274 + b]], T)
	for k in range(-2, 3): _poli([[k * 20 - 8, -318 + b + abs(k) * 6], [k * 20 + 8, -318 + b + abs(k) * 6], [k * 20, -340 + b + abs(k) * 8]], T)      # tufos
	var bo := _boca()                                               # a boca na barriga
	var mh := 18.0 + 58.0 * bo
	_poli([[-64, -146 + b], [64, -146 + b], [58, -146 + b + mh], [-58, -146 + b + mh]], T)
	_poli([[-52, -140 + b], [52, -140 + b], [46, -146 + b + mh - 8], [-46, -146 + b + mh - 8]], R)
	for k in range(10):
		var x := -54.0 + k * 12.0
		_poli([[x, -146 + b], [x + 12, -146 + b], [x + 6, -128 + b]], P)
		_poli([[x, -146 + b + mh], [x + 12, -146 + b + mh], [x + 6, -146 + b + mh - 16]], P)

# ---------------- MULA SEM CABEÇA: cavalo de lado, pescoço que acaba em labareda ----------------
func _mula() -> void:
	var b := _bob(); var pt := _pata(); var atq := _atq()
	_chama(-138, -150 + b, 30, 86, R, 1.0)                          # rabo de fogo
	_chama(-138, -150 + b, 18, 60, O, 2.0)
	for i in range(4):                                              # patas
		var x0: float = [-102.0, -66.0, 62.0, 100.0][i]
		var fase: float = pt * (1.0 if i % 2 == 0 else -1.0) * 16.0
		var topo: Array = [x0, -92.0 + b]; var pe: Array = [x0 + fase, -10.0]
		_linha(topo, [x0 + fase * 0.5 - 6.0, -52.0], 24.0, T); _linha([x0 + fase * 0.5 - 6.0, -52.0], pe, 18.0, T)
		_poli([[pe[0] - 15, pe[1] - 6], [pe[0] + 15, pe[1] - 6], [pe[0] + 18, pe[1] + 8], [pe[0] - 14, pe[1] + 8]], O)
	_felpuda(-6, -128 + b, 124, 62, 14, 8, T)                       # o corpo
	_felpuda(-6, -128 + b, 114, 52, 14, 7, K)
	_poli([[-34, -172 + b], [44, -172 + b], [38, -146 + b], [-28, -146 + b]], R)      # a manta
	_linha([-30, -158 + b], [40, -158 + b], 3.0, P)
	_poli([[58, -168 + b], [96, -184 + b], [126, -250 + b - atq * 10], [92, -262 + b - atq * 10], [64, -214 + b]], T)    # o pescoço
	_chama(110, -250 + b - atq * 10, 40, 110 + atq * 30, R, 3.0)    # a labareda no lugar da cabeça
	_chama(110, -250 + b - atq * 10, 28, 84 + atq * 24, O, 4.0)
	_chama(110, -250 + b - atq * 10, 15, 56 + atq * 16, P, 5.0)
	for k in range(5): _circ(80 + k * 17, -284 + b - (k % 2) * 22 - atq * 14, 3.5, O)       # faíscas

# ---------------- BOITATÁ: a cobra de fogo ----------------
func _boitata() -> void:
	var b := _bob(); var atq := _atq()
	var n := 46
	var centros := []
	for i in range(n):
		var t := float(i) / (n - 1)
		var x := -172.0 + t * 296.0
		var y := -46.0 - 46.0 * sin(t * TAU * 1.3 + _pata() * 0.4) - t * 62.0 + b * t
		centros.append(Vector2(x, y))
	for i in range(n):
		var t := float(i) / (n - 1)
		var rr := 9.0 + 27.0 * t
		_circ(centros[i].x, centros[i].y, rr + 3.0, T)
	for i in range(n):
		var t := float(i) / (n - 1)
		var rr := 9.0 + 27.0 * t
		_circ(centros[i].x, centros[i].y, rr * 0.74, O if i % 2 == 0 else K)
		if i % 3 == 0: _chama(centros[i].x, centros[i].y - rr * 0.8, rr * 0.7, 26 + rr, R if i % 6 == 0 else O, i * 0.6)
	var h: Vector2 = centros[n - 1] + Vector2(18, -26 + b)                # a cabeça erguida
	_circ(h.x, h.y, 50, T); _circ(h.x, h.y, 40, O)
	for sx in [-1.0, 1.0]:
		_circ(h.x + sx * 17 - 6, h.y - 8, 15, P); _circ(h.x + sx * 17 - 6, h.y - 8, 6, T)
	var mh := 14.0 + 40.0 * (atq + 0.15)
	_poli([[h.x - 8, h.y + 12], [h.x + 52, h.y + 12], [h.x + 46, h.y + 12 + mh], [h.x - 4, h.y + 12 + mh]], T)
	_poli([[h.x - 2, h.y + 16], [h.x + 44, h.y + 16], [h.x + 40, h.y + 8 + mh], [h.x + 2, h.y + 8 + mh]], R)
	for k in range(5): _poli([[h.x + k * 9, h.y + 12], [h.x + k * 9 + 9, h.y + 12], [h.x + k * 9 + 4, h.y + 28]], P)
	_chama(h.x - 6, h.y - 46, 30, 70, R, 7.0); _chama(h.x - 6, h.y - 46, 18, 48, O, 8.0)

# ---------------- CUCA: a bruxa jacaré de chapéu, caldeirão ao lado ----------------
func _cuca() -> void:
	var b := _bob(); var atq := _atq()
	_circ(-120, -42, 44, T); _poli([[-168, -62], [-72, -62], [-80, -76], [-160, -76]], KE)      # o caldeirão
	for k in range(3): _circ(-142 + k * 22, -86 - (k % 2) * 10 + b * 0.5, 7 + k * 2, O)
	_poli([[-78, -8], [84, -8], [56, -172 + b], [-44, -172 + b]], T)                              # o manto
	_poli([[-66, -14], [72, -14], [50, -164 + b], [-38, -164 + b]], KE)
	_poli([[-58, -8], [64, -8], [50, -30], [-52, -30]], R)
	_linha([-48, -150 + b], [50, -150 + b], 4.0, P)
	for sx in [-1.0, 1.0]:                                                                         # os braços e dedos
		var ombro := [sx * 44.0 + 4.0, -158.0 + b]
		var mao := [sx * (104.0 + atq * 22.0), -104.0 - atq * 70.0 + b]
		_linha(ombro, mao, 20.0, T)
		for k in range(4):
			_linha(mao, [mao[0] + sx * (16 + k * 4), mao[1] - 20 + k * 12], 4.0, P)
	_poli([[26, -206 + b], [136, -196 + b - atq * 10], [140, -178 + b + atq * 24], [34, -168 + b]], T)   # focinho de jacaré
	_poli([[34, -202 + b], [128, -196 + b - atq * 10], [130, -186 + b], [40, -184 + b]], K)
	for k in range(7):
		var x := 52.0 + k * 11.0
		_poli([[x, -176 + b + atq * 14], [x + 8, -176 + b + atq * 14], [x + 4, -163 + b + atq * 18]], P)
	_circ(34, -204 + b, 34, T); _circ(40, -214 + b, 14, O); _poli([[40, -224 + b], [44, -214 + b], [40, -204 + b], [36, -214 + b]], T)
	_poli([[-14, -230 + b], [82, -230 + b], [40, -318 + b]], T)                                    # o chapéu de bruxa
	_poli([[-34, -226 + b], [100, -226 + b], [100, -236 + b], [-34, -236 + b]], T)
	_poli([[-8, -244 + b], [76, -244 + b], [72, -262 + b], [-4, -262 + b]], R)
	_poli([[26, -246 + b], [44, -246 + b], [44, -260 + b], [26, -260 + b]], O)

# ---------------- MINHOCÃO: o verme gigante que sobe da terra, boca redonda de dentes ----------------
func _minhocao() -> void:
	var b := _bob(); var atq := _atq()
	var n := 12
	for i in range(n):                                                                             # o corpo em anéis
		var t := float(i) / (n - 1)
		var y := -8.0 - t * 175.0
		var x := sin(t * 3.2 + pose * 0.5) * 22.0 * t
		var rr := 68.0 - t * 16.0
		_felpuda(x, y + b * t, rr, rr * 0.52, 9, 4, T)
		_felpuda(x, y - 2 + b * t, rr * 0.82, rr * 0.4, 9, 3, K if i % 2 == 0 else KE)
		_linha([x - rr * 0.7, y + 8 + b * t], [x + rr * 0.7, y + 8 + b * t], 3.0, P)
	var hx := sin(3.2 + pose * 0.5) * 22.0; var hy := -196.0 + b
	_circ(hx, hy, 88, T); _circ(hx, hy, 76, K)
	var abre := 52.0 + 14.0 * _boca() + 20.0 * atq
	_circ(hx, hy + 6, abre + 8, T); _circ(hx, hy + 6, abre, R)                                    # a bocarra redonda
	for k in range(16):                                                                            # dentes em coroa
		var a := TAU * k / 16.0
		var p1 := Vector2(hx + cos(a - 0.14) * abre, hy + 6 + sin(a - 0.14) * abre)
		var p2 := Vector2(hx + cos(a + 0.14) * abre, hy + 6 + sin(a + 0.14) * abre)
		var p3 := Vector2(hx + cos(a) * (abre * 0.55), hy + 6 + sin(a) * (abre * 0.55))
		draw_colored_polygon(PackedVector2Array([p1, p2, p3]), P)
	_circ(hx, hy + 6, abre * 0.28, T)
	for sx in [-1.0, 1.0]:
		_linha([hx + sx * 74, hy - 40], [hx + sx * 118, hy - 74], 7.0, T); _circ(hx + sx * 118, hy - 74, 8, O)      # antenas

# ---------------- LOBISOMEM: lobo corcunda de pé, focinho aberto, garras de papel ----------------
func _lobisomem() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(0.8, 0.8))      # o lobo é mais alto que o espaço: encolhe pra caber
	var b := _bob(); var pt := _pata(); var atq := _atq()
	_felpuda(-112, -118 + b, 30, 14, 5, 7, T, 0.4)                                                   # rabo peludo
	for sx in [-1.0, 1.0]:                                                                          # pernas dobradas
		var x0: float = sx * 52.0 + sx * pt * 8.0
		_poli([[x0 - 30, -112 + b], [x0 + 30, -112 + b], [x0 + 36 - sx * 8, -40], [x0 + 22, -8], [x0 - 36, -8], [x0 - 22, -48]], T)
		_poli([[x0 - 22, -106 + b], [x0 + 22, -106 + b], [x0 + 26 - sx * 6, -44], [x0 + 14, -14], [x0 - 28, -14], [x0 - 16, -50]], K)
		for k in range(3): _poli([[x0 + k * 16 - 20, -10], [x0 + k * 16 - 11, -10], [x0 + k * 16 - 15, 8]], P)
	_felpuda(-6, -180 + b, 128, 92, 13, 18, T, 0.2)                                                  # o tronco corcunda
	_felpuda(-6, -178 + b, 118, 82, 13, 16, K, 0.2)
	_felpuda(10, -160 + b, 70, 54, 9, 9, O, 0.1)                                                     # o peito claro
	for i in range(10):
		var a := i * 0.63 + 0.2
		var cx := cos(a) * 80.0 - 6.0; var cy := -190.0 + b + sin(a) * 56.0
		_linha([cx, cy], [cx + cos(a) * 12, cy + sin(a) * 12 + 7], 3.0, T)
	for sx in [-1.0, 1.0]:                                                                           # braços e garras
		var ombro := [sx * 108.0 - 6.0, -226.0 + b]
		var mao := [sx * (150.0 + atq * 20.0), -80.0 - atq * 140.0 + b]
		_linha(ombro, mao, 34.0, T); _linha(ombro, mao, 24.0, K)
		_circ(mao[0], mao[1], 22.0, T)
		for k in range(4):
			var bx: float = mao[0] + (k - 1.5) * 11.0
			_poli([[bx - 5, mao[1] + 10], [bx + 5, mao[1] + 10], [bx + sx * 4.0, mao[1] + 52 + atq * 10]], P)
	var hy := -262.0 + b                                                                             # a cabeça de lobo
	_poli([[-34, hy - 40], [-8, hy - 44], [-22, hy - 108]], T); _poli([[34, hy - 40], [62, hy - 36], [54, hy - 104]], T)      # orelhas
	_poli([[-28, hy - 44], [-12, hy - 46], [-22, hy - 90]], R); _poli([[40, hy - 42], [58, hy - 40], [52, hy - 88]], R)
	_felpuda(14, hy, 56, 50, 8, 10, T); _circ(14, hy, 45, K)
	var abre := 12.0 + 40.0 * _boca()
	_poli([[34, hy - 14], [126, hy - 4 - atq * 12], [128, hy + 12], [34, hy + 14]], T)                # focinho de cima
	_poli([[36, hy + 14 + 4], [118, hy + 14 + abre * 0.4], [120, hy + 18 + abre], [38, hy + 20 + abre * 0.7]], T)    # queixo de baixo
	_poli([[40, hy + 16], [112, hy + 14], [114, hy + 14 + abre], [42, hy + 18 + abre * 0.7]], R)       # boca
	for k in range(7):
		var x := 46.0 + k * 11.0
		_poli([[x, hy + 14], [x + 9, hy + 14], [x + 4, hy + 30]], P)
		_poli([[x, hy + 18 + abre * 0.7], [x + 9, hy + 18 + abre * 0.7], [x + 4, hy + 4 + abre * 0.7]], P)
	_circ(124, hy + 2, 8, T)                                                                          # o nariz
	for sx in [-1.0, 1.0]:
		_circ(14 + sx * 22.0 + 12.0, hy - 14, 11, O); _poli([[14 + sx * 22.0 + 12.0 - 2, hy - 22], [14 + sx * 22.0 + 12.0 + 2, hy - 22], [14 + sx * 22.0 + 12.0, hy - 6]], T)
	_linha([-12, hy - 30], [22, hy - 22], 5.0, T); _linha([52, hy - 28], [26, hy - 20], 5.0, T)
