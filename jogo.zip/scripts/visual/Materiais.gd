extends RefCounted
class_name Materiais
# Biblioteca central de materiais do Cordel. Ninguém mais cria StandardMaterial3D solto pelo código:
# pede aqui. Um material por (cor, tipo), reaproveitado.

const SH_XILO: Shader = preload("res://shaders/xilogravura.gdshader")
const SH_CONTORNO: Shader = preload("res://shaders/contorno.gdshader")
const SH_CEU: Shader = preload("res://shaders/ceu.gdshader")
const SH_PAPEL: Shader = preload("res://shaders/papel.gdshader")

static var modo_gravura := false          # montando um molde de gravura: materiais próprios, sol de frente, sem tema
static var sol_gravura := Vector3(0.4, 0.6, 0.7)
static var _cache := {}
static var _todos: Array = []          # pra poder girar o "sol" de todos de uma vez
static var sol_dir := Vector3(0.45, 0.75, 0.48).normalized()

# Material de tinta chapada (o padrão de tudo). `brilho` > 0 = emissivo (fogo, vaga-lume).
static func tinta(cor: Color, brilho: float = 0.0, contorno: float = 0.0, hachura: bool = true, enchimento: float = 0.2) -> ShaderMaterial:
	var c := Paleta.snap(cor) if brilho <= 0.0 else cor
	var k := ("G" if modo_gravura else "") + "%s:%s:%s:%s:%s" % [c.to_html(), brilho, contorno, hachura, enchimento]
	if _cache.has(k): return _cache[k]
	var m := ShaderMaterial.new(); m.shader = SH_XILO
	m.set_shader_parameter("cor", c)
	m.set_shader_parameter("sol_dir", sol_gravura if modo_gravura else sol_dir)
	m.set_shader_parameter("emissao", brilho)
	m.set_shader_parameter("hachura", 1.0 if hachura else 0.0)
	m.set_shader_parameter("preenchimento", enchimento)
	if modo_gravura:
		# a figura impressa aparece pequena na tela: risco fino e granulado viravam chuvisco borrado
		m.set_shader_parameter("escala_hachura", 3.2); m.set_shader_parameter("granulado", 0.3)
	if contorno > 0.0: m.next_pass = _contorno(contorno)
	_cache[k] = m
	if not modo_gravura:
		_todos.append(m); _aplicar_tema(m)
	return m

static func _aplicar_tema(m: ShaderMaterial) -> void:
	if _tema_mix > 0.0:
		var l := _tema_cor.srgb_to_linear()
		m.set_shader_parameter("verde_para", Vector3(l.r, l.g, l.b)); m.set_shader_parameter("verde_mix", _tema_mix)

static func _contorno(esp: float) -> ShaderMaterial:
	var k := "contorno:%s" % esp
	if _cache.has(k): return _cache[k]
	var m := ShaderMaterial.new(); m.shader = SH_CONTORNO
	m.set_shader_parameter("espessura", esp)
	_cache[k] = m
	return m

# Material do chão: cor por vértice (já na paleta), hachura mais larga.
static func chao() -> ShaderMaterial:
	if _cache.has("chao"): return _cache["chao"]
	var m := ShaderMaterial.new(); m.shader = SH_XILO
	m.set_shader_parameter("cor_vertice", true)
	m.set_shader_parameter("sol_dir", sol_dir)
	m.set_shader_parameter("escala_hachura", 5.0)
	m.set_shader_parameter("relevo", 1.0)
	_cache["chao"] = m; _todos.append(m)
	return m

# Cor por vértice para MultiMesh (capim, flores): sem hachura, sem sombra recebida.
static func tinta_vertice() -> ShaderMaterial:
	if _cache.has("vertice"): return _cache["vertice"]
	var m := ShaderMaterial.new(); m.shader = SH_XILO
	m.set_shader_parameter("cor_vertice", true)
	m.set_shader_parameter("sol_dir", sol_dir)
	m.set_shader_parameter("hachura", 0.0)
	_cache["vertice"] = m; _todos.append(m)
	return m

# Tema de cor da fase: o verde do mundo vira `cor` (sRGB). mistura 0 = sem tema.
static var _tema_cor := Color.BLACK
static var _tema_mix := 0.0
static func definir_tema(cor: Color, mistura: float) -> void:
	_tema_cor = cor; _tema_mix = mistura
	var lin := cor.srgb_to_linear(); Gravador.aplicar_tema(Vector3(lin.r, lin.g, lin.b), mistura)
	for m in _todos:
		m.set_shader_parameter("verde_para", Vector3(cor.srgb_to_linear().r, cor.srgb_to_linear().g, cor.srgb_to_linear().b))
		m.set_shader_parameter("verde_mix", mistura)

static func definir_sol(dir_para_o_sol: Vector3) -> void:
	sol_dir = dir_para_o_sol.normalized()
	for m in _todos: m.set_shader_parameter("sol_dir", sol_dir)

static func ceu() -> ShaderMaterial:
	var m := ShaderMaterial.new(); m.shader = SH_CEU
	return m

# Camada de papel/impressão por cima do 3D.
static var papel_mat: ShaderMaterial
static func camada_papel(pai: Node) -> CanvasLayer:
	var cl := CanvasLayer.new(); cl.layer = 0; pai.add_child(cl)
	var r := ColorRect.new(); r.set_anchors_preset(Control.PRESET_FULL_RECT); r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m := ShaderMaterial.new(); m.shader = SH_PAPEL; r.material = m
	papel_mat = m
	cl.add_child(r)
	return cl

# papel colorido e quanto clarear a chapa de cor, por fase (cordel de verdade é impresso em papel colorido)
static func papel_da_fase(cor: Color, levanta: float, rigor: float = 1.0) -> void:
	if papel_mat == null: return
	papel_mat.set_shader_parameter("cor_papel", Vector3(cor.r, cor.g, cor.b))
	papel_mat.set_shader_parameter("levanta", levanta)
	papel_mat.set_shader_parameter("rigor", rigor)
