extends Node
class_name Gravador
# O "ateliê de gravura": pega a matriz 3D de um personagem (Modelo.gd), monta num molde com luz de frente,
# imprime 4 quadros (parado, passo A, passo B, ataque), faz o RECORTE DE PAPEL (shader recorte.gdshader) e entrega
# a folha de gravuras pronta pros Cartões. Tudo na hora, em lote, uma vez por personagem (fica em cache).
# Também imprime outras coisas (árvores, mata) via `construtores`: chave "@tipo:arg:arg" -> Callable que monta o 3D.

const CW := 192                 # largura de um quadro (px)
const CH := 288                 # altura de um quadro (px)
const PPU := 112.0              # pixels por metro no molde
const QUADROS := 4
const LINHAS_POR_LOTE := 6
# personagens ficam perto da câmera: impressos em 1x a figura era esticada na tela e borrava
const RES_PERSONAGEM := 2.0
const LUZ_GRAUS := Vector3(-38.0, 22.0, 0.0)     # a luz do molde vem de frente e de cima
# bichos compridos / de quatro patas aparecem de 3/4 (giro em Y, rad) pra mostrar o corpo
const VISTA := {"mula": 1.15, "minhocao": 0.2, "boitata": 0.5}

static var inst: Gravador
static var ligado := true                 # desliga pra voltar ao 3D antigo (opção/depuração)
static var construtores := {}             # prefixo -> Callable(args: Array) -> Node3D
static var moldes := {}                   # chave -> Node3D com as malhas de um objeto do mapa (o construtor "objeto" devolve cópias)
static var dump_dir := ""                 # depuração: salva a folha impressa como PNG aqui
static var tema_vec := Vector3.ZERO
static var tema_mix := 0.0

var cache := {}                           # chave -> info
var pendentes: Array = []                 # [chave, tipo, destaque]
var esperando := {}                       # chave -> [Cartao]
var ocupado := false
var _mats: Array = []
var _mat_mancha: ShaderMaterial
var _n_dump := 0

# true quando não há nada na fila nem sendo impresso (os testes de captura esperam isso)
static func ocioso() -> bool:
	return inst == null or (inst.pendentes.is_empty() and not inst.ocupado)

static func _construtor_objeto(args: Array) -> Node3D:
	var m: Node3D = moldes.get(String(args[0]), null)
	return m.duplicate() if m != null else Node3D.new()

static func disponivel() -> bool:
	return ligado and DisplayServer.get_name() != "headless"

static func _garantir() -> Gravador:
	if not construtores.has("objeto"): construtores["objeto"] = Callable(Gravador, "_construtor_objeto")
	if inst == null or not is_instance_valid(inst):
		inst = Gravador.new(); inst.name = "Gravador"
		(Engine.get_main_loop() as SceneTree).root.add_child.call_deferred(inst)
	return inst

static func chave(tipo: String, destaque) -> String:
	return tipo if destaque == null else tipo + "#" + Color(destaque).to_html()

static func cor_base(tipo: String, destaque) -> Color:
	var g := _garantir(); var k := chave(tipo, destaque)
	return g.cache[k]["cor_base"] if g.cache.has(k) else Color(0.9, 0.85, 0.7)

static func material_mancha() -> ShaderMaterial:
	var g := _garantir()
	if g._mat_mancha == null:
		g._mat_mancha = ShaderMaterial.new(); g._mat_mancha.shader = load("res://shaders/mancha.gdshader")
	return g._mat_mancha

# devolve a info se a folha já está pronta; senão {} e avisa o cartão quando ficar pronta
static func pedir(c: Cartao, tipo: String, destaque) -> Dictionary:
	var g := _garantir(); var k := chave(tipo, destaque)
	if g.cache.has(k): return g.cache[k]
	if not g.esperando.has(k):
		g.esperando[k] = []; g.pendentes.append([k, tipo, destaque])
	g.esperando[k].append(c)
	return {}

# Retrato de um personagem = o quadro "parado" da própria folha de gravuras (a mesma figura que aparece em campo).
# Devolve na hora uma textura que se preenche sozinha quando a impressão termina.
static func retrato(tipo: String, destaque = null, quadro: int = 0) -> AtlasTexture:
	var g := _garantir(); var k := chave(tipo, destaque)
	var at := AtlasTexture.new()
	var pronto := func(inf: Dictionary):
		at.atlas = inf["folha"]; at.region = Rect2(minf(quadro, int(inf["nq"]) - 1) * int(inf["cw"]), 0, int(inf["cw"]), int(inf["ch"]))
	if g.cache.has(k): pronto.call(g.cache[k])
	else:
		if not g.esperando.has(k):
			g.esperando[k] = []; g.pendentes.append([k, tipo, destaque])
		g.esperando[k].append(pronto)
	return at

static func aplicar_tema(cor_lin: Vector3, mistura: float) -> void:
	tema_vec = cor_lin; tema_mix = mistura
	if inst == null: return
	for m in inst._mats:
		m.set_shader_parameter("verde_para", cor_lin); m.set_shader_parameter("verde_mix", mistura)

func _process(_d: float) -> void:
	if ocupado or pendentes.is_empty(): return
	var lote: Array = []
	var tipo0 := _classe(String(pendentes[0][1]))        # plantas, chefes desenhados e personagens imprimem em moldes diferentes
	while not pendentes.is_empty() and lote.size() < LINHAS_POR_LOTE and _classe(String(pendentes[0][1])) == tipo0:
		lote.append(pendentes.pop_front())
	_assar(lote, 1.5 if tipo0 == 1 else RES_PERSONAGEM, tipo0 == 2)

func _classe(tipo: String) -> int:
	if tipo.begins_with("@"): return 1
	if ChefesGravura.TEM.has(tipo) and not tipo.begins_with("@"): return 2
	return 0

# ---------- limites e poses ----------
func _limites(n: Node3D, xf: Transform3D, acc: Array) -> void:
	var t := xf * n.transform
	if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
		var a: AABB = t * (n as MeshInstance3D).get_aabb()
		if acc.is_empty(): acc.append(a)
		else: acc[0] = (acc[0] as AABB).merge(a)
	for c in n.get_children():
		if c is Node3D: _limites(c, t, acc)

func _pose(m: Modelo, q: int) -> void:
	match q:
		0: m.animar(0.0, false, 1.0)
		1: m.t = PI / 2.0; m.animar(0.0, true, 1.0)
		2: m.t = -PI / 2.0; m.animar(0.0, true, 1.0)
		3: m.atk_t = 0.14; m.animar(0.0, false, 1.0)

# monta uma linha (um personagem, N quadros) no molde; devolve os dados de tamanho
func _linha(sv: SubViewport, r: int, tipo: String, destaque, cw: int, ch: int, ppu: float) -> Dictionary:
	var yaw: float = VISTA.get(tipo, 0.0)
	if ChefesGravura.TEM.has(tipo):                          # chefe DESENHADO (2D), não o modelo 3D
		var rs := {"cor_base": ChefesGravura.COR_BASE[tipo], "nq": QUADROS, "planta": false}
		var alt_m: float = float(ChefesGravura.TEM[tipo]) / 0.84
		rs["alt"] = alt_m; rs["larg"] = alt_m * float(cw) / float(ch); rs["desce"] = alt_m * 0.05; rs["dx"] = 0.0
		var esc := float(ch) * 0.84 / 300.0
		for q in range(QUADROS):
			var d := ChefesGravura.new(); d.chefe = tipo; d.pose = q
			d.position = Vector2((q + 0.5) * cw, (r + 1) * ch - ch * 0.05 - 14.0 * esc); d.scale = Vector2(esc, esc)
			sv.add_child(d)
		return rs
	var planta := tipo.begins_with("@")
	var nq := 1 if planta else QUADROS
	var res := {"cor_base": Color(0.9, 0.85, 0.7), "nq": nq, "planta": planta}
	var fs := 1.0; var centro := Vector3.ZERO; var base_y := 0.0
	for q in range(nq):
		var m: Node3D
		if planta:
			var partes := tipo.substr(1).split(":")
			var cb: Callable = construtores.get(partes[0], Callable())
			if not cb.is_valid(): return res
			m = cb.call(Array(partes.slice(1)))
		else:
			var mo := Modelo.criar(tipo, destaque)
			_pose(mo, q); m = mo
			res["cor_base"] = mo.cor_base
		m.rotation.y = yaw
		if q == 0:
			var acc: Array = []
			_limites(m, Transform3D.IDENTITY, acc)
			var lim: AABB = acc[0] if not acc.is_empty() else AABB(Vector3(-0.5, 0, -0.5), Vector3(1, 2, 1))
			if not planta:                                  # a silhueta própria do personagem (largura/altura)
				var fm := Modelo.forma(tipo)
				lim = AABB(lim.position * fm, lim.size * fm)
			fs = minf(minf(cw * 0.86 / ppu / maxf(lim.size.x, 0.01), ch * 0.88 / ppu / maxf(lim.size.y, 0.01)), 1.25)
			centro = lim.position + lim.size * 0.5
			base_y = lim.position.y
			res["larg"] = cw / ppu / fs; res["alt"] = ch / ppu / fs; res["desce"] = (ch * 0.06 / ppu) / fs - base_y; res["dx"] = centro.x
		m.scale = Vector3.ONE * fs * (Vector3.ONE if planta else Modelo.forma(tipo))
		m.position = Vector3((q + 0.5) * cw / ppu - fs * centro.x,
			-(r + 1) * ch / ppu + ch * 0.06 / ppu - fs * base_y, 0.0)
		sv.add_child(m)
	return res

# ---------- impressão em lote ----------
func _assar(lote: Array, mult: float, largo: bool = false) -> void:
	ocupado = true
	var linhas := lote.size()
	var cw := int(CW * mult * (2.0 if largo else 1.0)); var ch := int(CH * mult); var ppu := PPU * mult
	var W := cw * QUADROS; var H := ch * linhas
	var luz_basis := Basis.from_euler(Vector3(deg_to_rad(LUZ_GRAUS.x), deg_to_rad(LUZ_GRAUS.y), 0.0))
	# etapa 1: o 3D, de frente, com luz de frente
	var sv := SubViewport.new(); sv.size = Vector2i(W, H); sv.transparent_bg = true; sv.own_world_3d = true
	sv.msaa_3d = Viewport.MSAA_4X; sv.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(sv)
	var cam := Camera3D.new(); cam.projection = Camera3D.PROJECTION_ORTHOGONAL; cam.size = H / ppu
	cam.keep_aspect = Camera3D.KEEP_HEIGHT; cam.near = 0.1; cam.far = 200.0
	cam.position = Vector3(W / (2.0 * ppu), -H / (2.0 * ppu), 60.0)
	var env := Environment.new(); env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.ambient_light_color = Color(0.8, 0.74, 0.66); env.ambient_light_energy = 0.5
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	cam.environment = env
	sv.add_child(cam)
	var luz := DirectionalLight3D.new(); luz.rotation_degrees = LUZ_GRAUS; luz.light_energy = 1.05; luz.light_color = Color(1.0, 0.96, 0.86)
	luz.shadow_enabled = false; luz.position = Vector3(0, 0, 60); sv.add_child(luz)
	Materiais.modo_gravura = true; Materiais.sol_gravura = luz_basis.z; Modelo.modo_gravura = true
	var dados: Array = []
	for r in range(linhas): dados.append(_linha(sv, r, lote[r][1], lote[r][2], cw, ch, ppu))
	Materiais.modo_gravura = false; Modelo.modo_gravura = false
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	if dump_dir != "":
		var i1 := sv.get_texture().get_image(); i1.save_png("%s/folha_%d_etapa1.png" % [dump_dir, _n_dump])
	# etapa 2: recorte de papel
	var sv2 := SubViewport.new(); sv2.size = Vector2i(W, H); sv2.transparent_bg = true; sv2.disable_3d = true
	sv2.render_target_update_mode = SubViewport.UPDATE_ONCE
	var tr := TextureRect.new(); tr.texture = sv.get_texture(); tr.size = Vector2(W, H)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; tr.stretch_mode = TextureRect.STRETCH_SCALE
	var mat := ShaderMaterial.new(); mat.shader = load("res://shaders/recorte.gdshader")
	mat.set_shader_parameter("tam_total", Vector2(W, H)); mat.set_shader_parameter("escala", mult); tr.material = mat
	sv2.add_child(tr); add_child(sv2)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var img := sv2.get_texture().get_image()
	img.convert(Image.FORMAT_RGBA8)
	if dump_dir != "":
		img.save_png("%s/folha_%d.png" % [dump_dir, _n_dump]); _n_dump += 1
	sv.queue_free(); sv2.queue_free()
	# entrega
	for r in range(linhas):
		var k: String = lote[r][0]; var d: Dictionary = dados[r]
		if not d.has("larg"): esperando.erase(k); continue
		var nq: int = d["nq"]
		var sl := img.get_region(Rect2i(0, r * ch, cw * nq, ch))
		sl.generate_mipmaps()
		var sm := ShaderMaterial.new(); sm.shader = load("res://shaders/cartao.gdshader")
		sm.set_shader_parameter("folha", ImageTexture.create_from_image(sl))
		sm.set_shader_parameter("tam", Vector2(float(d["larg"]), float(d["alt"])))
		sm.set_shader_parameter("quadros", float(nq))
		sm.set_shader_parameter("vento", 1.0 if d["planta"] else 0.0)
		sm.set_shader_parameter("desloca", float(d["dx"]))
		sm.set_shader_parameter("verde_para", tema_vec); sm.set_shader_parameter("verde_mix", tema_mix)
		_mats.append(sm)
		var info := {"folha": sm.get_shader_parameter("folha"), "cw": cw, "ch": ch, "mat": sm, "larg": d["larg"], "alt": d["alt"], "desce": d["desce"], "dx": d["dx"], "cor_base": d["cor_base"], "nq": nq}
		cache[k] = info
		for c in esperando.get(k, []):
			if c is Callable: c.call(info)
			elif is_instance_valid(c): c.pronto(info)
		esperando.erase(k)
	ocupado = false
