extends StyleBox
class_name StyleEntalhe
# Moldura de interface desenhada à mão, no lugar do retângulo chapado: papel de borda levemente irregular e de cantos
# chanfrados, sombra de TINTA CHAPADA (sem desfoque), contorno de duas passadas de espessura diferente, filete interno
# fino e ornamento nos cantos. A irregularidade é fixa pro mesmo tamanho (não treme), e varia de um painel pra outro.

var fundo := Color("E8D7AE")
var tinta := Color("201A17")         # cor do contorno (muda pra destacar seleção)
var borda := 4.0
var sombra := 5.0
var filete := true
var ornamento := false
var semente := 1
const TINTA_FIXA := Color("201A17")

# compatibilidade com o jeito antigo (StyleBoxFlat), pra não mexer em quem já usa
var corner_radius_bottom_left := 0
var bg_color: Color:
	get: return fundo
	set(v): fundo = v
var border_color: Color:
	get: return tinta
	set(v): tinta = v

func _contorno(r: Rect2, jit: float, rng: RandomNumberGenerator, chanfro: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var cantos := [r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)]
	var c := minf(chanfro, minf(r.size.x, r.size.y) * 0.25)
	for i in range(4):
		var a: Vector2 = cantos[i]; var b: Vector2 = cantos[(i + 1) % 4]
		var u := (b - a).normalized()
		var ini := a + u * c; var fim := b - u * c
		var n := maxi(1, int(ini.distance_to(fim) / 28.0))
		for k in range(n + 1):
			var p := ini.lerp(fim, float(k) / n)
			pts.append(p + Vector2(rng.randf_range(-jit, jit), rng.randf_range(-jit, jit)))
	return pts

func _draw(canvas: RID, rect: Rect2) -> void:
	if rect.size.x < 4.0 or rect.size.y < 4.0: return
	var rng := RandomNumberGenerator.new()
	rng.seed = semente * 7919 + int(rect.size.x) * 31 + int(rect.size.y) * 17
	var pts := _contorno(rect, 1.0, rng, 6.0)
	if sombra > 0.0:
		var sp := PackedVector2Array()
		for p in pts: sp.append(p + Vector2(sombra, sombra))
		RenderingServer.canvas_item_add_polygon(canvas, sp, PackedColorArray([TINTA_FIXA]))
	RenderingServer.canvas_item_add_polygon(canvas, pts, PackedColorArray([fundo]))
	if borda > 0.0:
		var l := pts.duplicate(); l.append(pts[0])
		RenderingServer.canvas_item_add_polyline(canvas, l, PackedColorArray([tinta]), borda, true)
		# segunda passada, mais fina e com outro tremor: contorno entalhado, não régua
		var p2 := _contorno(rect.grow(-borda * 0.35), 1.6, rng, 7.0)
		p2.append(p2[0])
		RenderingServer.canvas_item_add_polyline(canvas, p2, PackedColorArray([tinta]), maxf(1.2, borda * 0.4), true)
	if filete and borda >= 3.0 and minf(rect.size.x, rect.size.y) > 44.0:
		var ri := rect.grow(-(borda + 5.0))
		var p3 := _contorno(ri, 0.5, rng, 4.0)
		p3.append(p3[0])
		RenderingServer.canvas_item_add_polyline(canvas, p3, PackedColorArray([Color(tinta, 0.85)]), 1.4, true)
		if ornamento:
			for cp in [ri.position, Vector2(ri.end.x, ri.position.y), ri.end, Vector2(ri.position.x, ri.end.y)]:
				var d := 5.5
				RenderingServer.canvas_item_add_polygon(canvas, PackedVector2Array([cp + Vector2(0, -d), cp + Vector2(d, 0), cp + Vector2(0, d), cp + Vector2(-d, 0)]), PackedColorArray([tinta]))

func _get_draw_rect(rect: Rect2) -> Rect2:
	return rect.grow(sombra + 2.0)
