extends StyleBox
class_name StyleEntalhe
# Moldura de interface desenhada à mão, no lugar do retângulo chapado: papel de borda levemente irregular e de cantos
# chanfrados, sombra de TINTA CHAPADA (sem desfoque), contorno de duas passadas de espessura diferente, filete interno
# fino e ornamento nos cantos. A irregularidade é fixa pro mesmo tamanho (não treme), e varia de um painel pra outro.

var fundo := Color("E8D7AE")
var tinta := Color("201A17")         # cor do contorno (muda pra destacar seleção)
var borda := 4.0
var sombra := 5.0
var filete := true
var ornamento := false
var semente := 1
var modo := 0              # 0 = papel (fundo claro) | 1 = tinta (bloco preto com filete branco entalhado) | 2 = cor (tinta colorida hachurada)
const TINTA_FIXA := Color("201A17")

# compatibilidade com o jeito antigo (StyleBoxFlat), pra não mexer em quem já usa
var corner_radius_bottom_left := 0
var bg_color: Color:
	get: return fundo
	set(v): fundo = v
var border_color: Color:
	get: return tinta
	set(v): tinta = v

func _contorno(r: Rect2, jit: float, rng: RandomNumberGenerator, chanfro: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var cantos := [r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)]
	var c := minf(chanfro, minf(r.size.x, r.size.y) * 0.25)
	for i in range(4):
		var a: Vector2 = cantos[i]; var b: Vector2 = cantos[(i + 1) % 4]
		var u := (b - a).normalized()
		var ini := a + u * c; var fim := b - u * c
		var n := maxi(1, int(ini.distance_to(fim) / 28.0))
		for k in range(n + 1):
			var p := ini.lerp(fim, float(k) / n)
			pts.append(p + Vector2(rng.randf_range(-jit, jit), rng.randf_range(-jit, jit)))
	return pts

func _linha_poli(canvas: RID, pts: PackedVector2Array, cor: Color, esp: float) -> void:
	var l := pts.duplicate(); l.append(pts[0])
	RenderingServer.canvas_item_add_polyline(canvas, l, PackedColorArray([cor]), esp, true)

func _draw(canvas: RID, rect: Rect2) -> void:
	if rect.size.x < 4.0 or rect.size.y < 4.0: return
	var rng := RandomNumberGenerator.new()
	rng.seed = semente * 7919 + int(rect.size.x) * 31 + int(rect.size.y) * 17
	var pts := _contorno(rect, 1.0, rng, 6.0)
	if sombra > 0.0 and modo != 1:
		var sp := PackedVector2Array()
		for p in pts: sp.append(p + Vector2(sombra, sombra))
		RenderingServer.canvas_item_add_polygon(canvas, sp, PackedColorArray([TINTA_FIXA]))
	var papel := Color("E8D7AE")
	if modo == 1:
		# BLOCO DE TINTA: massa preta com um filete branco entalhado por dentro (a goiva deixa o papel aparecer)
		RenderingServer.canvas_item_add_polygon(canvas, pts, PackedColorArray([TINTA_FIXA]))
		if minf(rect.size.x, rect.size.y) > 14.0:
			var ri := rect.grow(-(maxf(borda, 3.0) + 2.0))
			var p2 := _contorno(ri, 1.2, rng, 5.0)
			_linha_poli(canvas, p2, papel, 1.8)
			var ri2 := rect.grow(-(maxf(borda, 3.0) + 7.0))
			if minf(ri2.size.x, ri2.size.y) > 10.0 and filete:
				_linha_poli(canvas, _contorno(ri2, 0.6, rng, 3.0), Color(papel, 0.55), 1.0)
			# marcas de goiva nos cantos (cortes curtos em ângulo)
			for cp in [ri.position, Vector2(ri.end.x, ri.position.y), ri.end, Vector2(ri.position.x, ri.end.y)]:
				var dx := 1.0 if cp.x < rect.get_center().x else -1.0
				var dy := 1.0 if cp.y < rect.get_center().y else -1.0
				for k in range(3):
					RenderingServer.canvas_item_add_line(canvas, cp + Vector2(dx * (5 + k * 4), dy * 2), cp + Vector2(dx * (2 + k * 4), dy * 9), papel, 1.6)
		return
	RenderingServer.canvas_item_add_polygon(canvas, pts, PackedColorArray([fundo]))
	if modo == 2:
		# cor impressa: hachura de goiva em diagonal por cima da tinta
		var x := rect.position.x - rect.size.y
		while x < rect.end.x:
			var a := Vector2(x, rect.end.y); var b := Vector2(x + rect.size.y, rect.position.y)
			var d := (b - a)
			var t0 := 0.0; var t1 := 1.0
			# recorta o segmento ao retângulo
			if a.x < rect.position.x: t0 = maxf(t0, (rect.position.x - a.x) / d.x)
			if b.x > rect.end.x: t1 = minf(t1, (rect.end.x - a.x) / d.x)
			if t1 > t0: RenderingServer.canvas_item_add_line(canvas, a + d * t0, a + d * t1, Color(TINTA_FIXA, 0.30), 1.6)
			x += 7.0
	else:
		# papel: veio de madeira (traços horizontais curtos e irregulares, quase invisíveis)
		for k in range(int(rect.size.x * rect.size.y / 2600.0)):
			var gx := rect.position.x + rng.randf() * rect.size.x; var gy := rect.position.y + rng.randf() * rect.size.y
			RenderingServer.canvas_item_add_line(canvas, Vector2(gx, gy), Vector2(minf(gx + 8.0 + rng.randf() * 26.0, rect.end.x - 2.0), gy + rng.randf() * 1.5), Color(TINTA_FIXA, 0.10), 1.0)
	if borda > 0.0:
		_linha_poli(canvas, pts, tinta, borda)
		_linha_poli(canvas, _contorno(rect.grow(-borda * 0.35), 1.6, rng, 7.0), tinta, maxf(1.2, borda * 0.4))
	if filete and borda >= 3.0 and minf(rect.size.x, rect.size.y) > 44.0:
		var ri3 := rect.grow(-(borda + 5.0))
		_linha_poli(canvas, _contorno(ri3, 0.5, rng, 4.0), Color(tinta, 0.85), 1.4)
		if ornamento:
			for cp in [ri3.position, Vector2(ri3.end.x, ri3.position.y), ri3.end, Vector2(ri3.position.x, ri3.end.y)]:
				var d := 5.5
				RenderingServer.canvas_item_add_polygon(canvas, PackedVector2Array([cp + Vector2(0, -d), cp + Vector2(d, 0), cp + Vector2(0, d), cp + Vector2(-d, 0)]), PackedColorArray([tinta]))

func _get_draw_rect(rect: Rect2) -> Rect2:
	return rect.grow(sombra + 2.0)
