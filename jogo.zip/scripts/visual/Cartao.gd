extends MeshInstance3D
class_name Cartao
# Uma figura de papel gravada, em pé. Pega a folha de gravuras do Gravador (quando pronta) e se mexe como boneco
# de teatro de mamulengo: balança, quica, estica quando ataca, vira de lado quando gira, pisca quando apanha.

var tipo := ""
var destaque = null
var info := {}
var _lado := 1.0
var _quadro := -1
var _mancha: MeshInstance3D

static func novo(tipo_: String, destaque_ = null, com_mancha: bool = false) -> Cartao:
	var c := Cartao.new()
	c.tipo = tipo_; c.destaque = destaque_
	c.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if com_mancha: c._criar_mancha()
	var inf := Gravador.pedir(c, tipo_, destaque_)
	if not inf.is_empty(): c.pronto(inf)
	return c

func _criar_mancha() -> void:
	_mancha = MeshInstance3D.new()
	var q := QuadMesh.new(); q.size = Vector2(1, 1); q.orientation = PlaneMesh.FACE_Y
	_mancha.mesh = q; _mancha.material_override = Gravador.material_mancha()
	_mancha.position = Vector3(0, 0.08, 0); _mancha.scale = Vector3(1.2, 1.0, 0.8)
	_mancha.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_mancha)

# a folha ficou pronta: mostra a figura
func pronto(inf: Dictionary) -> void:
	info = inf
	var q := QuadMesh.new(); q.size = Vector2(1, 1)
	q.center_offset = Vector3(0, 0.5 - float(inf["desce"]) / float(inf["alt"]), 0)     # o pé da figura fica na origem do nó
	mesh = q
	material_override = inf["mat"]
	if _mancha: _mancha.scale = Vector3(1.2, 1.0, 0.8) * maxf(0.9, float(inf["larg"]) * 0.42)

func _quadro_para(q: int) -> void:
	if q == _quadro or info.is_empty(): return
	_quadro = q
	set_instance_shader_parameter("quadro", float(q))

# chamado pelo Boneco todo quadro
func animar(b: Boneco, delta: float, andando: bool, ritmo: float) -> void:
	b.t += delta * (10.0 * ritmo if andando else 2.2)
	b.atk_t = maxf(0.0, b.atk_t - delta)
	b.giro_t = maxf(0.0, b.giro_t - delta)
	b.bate_t = maxf(0.0, b.bate_t - delta)
	if info.is_empty(): return
	# animação EM ETAPAS (como boneco recortado que se move aos pulinhos): o tempo anda em degraus, e cada degrau
	# tem uma pequena variação própria (nenhum passo é igual ao outro)
	var degrau := floorf(b.t / 0.8)
	var tq := degrau * 0.8
	var passo := sin(tq)
	var jit := fposmod(sin(degrau * 12.9898 + float(get_instance_id() % 97)) * 43758.5453, 1.0) - 0.5
	var q := 0
	if b.atk_t > 0.0: q = 3
	elif andando: q = 1 if passo > 0.0 else 2
	_quadro_para(q)
	# quica e balança, como boneco de mamulengo
	var quique := (absf(passo) * (0.34 if b.saltita else 0.1) + jit * 0.03) if andando else passo * 0.02
	var incl := (passo * 0.09 + jit * 0.05) if andando else passo * 0.015
	if b.tonto: incl = 0.3 + sin(Time.get_ticks_msec() * 0.02) * 0.06
	b.corpo.position.y = quique
	var e := 1.0 + 0.22 * (b.bate_t / 0.12)
	var a := b.atk_t / 0.28
	b.corpo.scale = Vector3(e * (1.0 + 0.16 * sin(a * PI)), (2.0 - e) * (1.0 + 0.06 * sin(a * PI)), e)
	# pra que lado olha: usa a direção do boneco em relação à câmera; girando, a figura vira de lado
	var lado := _lado
	if b.giro_t > 0.0:
		lado = cos((1.0 - b.giro_t / 0.32) * TAU)
	else:
		var cam := get_viewport().get_camera_3d()
		if cam:
			var f := Vector3(sin(b.rotation.y), 0.0, cos(b.rotation.y))
			var d := f.dot(cam.global_transform.basis.x)
			if absf(d) > 0.15: _lado = 1.0 if d > 0.0 else -1.0
		lado = _lado
	set_instance_shader_parameter("lado", lado)
	set_instance_shader_parameter("inclina", incl)
	set_instance_shader_parameter("flash", b.bate_t / 0.12)
