extends Control
class_name PalcoGravura
# Palco de uma gravura grande: raios de sol, disco de pigmento, o personagem em papel recortado e chão hachurado,
# dentro de moldura dupla. Usado na escolha de herói e nas melhorias.

var cor := Color("D69A32")
var tipo := ""
var trancado := false
var _fig: TextureRect
var vivo := false
var _boneco: Boneco
var _prox := 1.6
var _t := 0.0

static func novo(tipo_: String, tam: Vector2, cor_: Color, trancado_: bool = false, vivo_: bool = false) -> PalcoGravura:
	var p := PalcoGravura.new()
	p.vivo = vivo_
	p.tipo = tipo_; p.cor = cor_; p.trancado = trancado_
	p.custom_minimum_size = tam; p.size = tam; p.mouse_filter = Control.MOUSE_FILTER_IGNORE; p.clip_contents = true
	return p

func _ready() -> void:
	resized.connect(queue_redraw)
	if vivo and Gravador.disponivel():
		# o herói de verdade, nítido e animado: um mini-teatro de papel (SubViewport) com respiração e golpes de vez em quando
		var ct := SubViewportContainer.new(); ct.stretch = true; ct.set_anchors_preset(Control.PRESET_FULL_RECT); ct.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var sv := SubViewport.new(); sv.own_world_3d = true; sv.transparent_bg = true; sv.size = Vector2i(custom_minimum_size)
		sv.msaa_3d = Viewport.MSAA_4X; sv.render_target_update_mode = SubViewport.UPDATE_ALWAYS; ct.add_child(sv); add_child(ct)
		var cam := Camera3D.new(); cam.projection = Camera3D.PROJECTION_ORTHOGONAL; cam.size = 3.2
		cam.position = Vector3(0, 1.2, 10.0); sv.add_child(cam); cam.look_at(Vector3(0, 1.2, 0), Vector3.UP)
		var env := Environment.new(); env.background_mode = Environment.BG_CLEAR_COLOR; cam.environment = env
		_boneco = Boneco.criar(tipo); _boneco.position = Vector3(0, -0.05, 0); _boneco.scale = Vector3.ONE * 1.05
		_boneco.rotation.y = 0.5; sv.add_child(_boneco)
		return
	_fig = TextureRect.new()
	_fig.texture = Gravador.retrato(tipo) if Gravador.disponivel() else null
	_fig.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; _fig.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_fig.set_anchors_preset(Control.PRESET_FULL_RECT); _fig.offset_top = 8; _fig.offset_bottom = -20; _fig.offset_left = 6; _fig.offset_right = -6
	_fig.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if trancado: _fig.modulate = Color(0.03, 0.03, 0.03)
	add_child(_fig)

func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	draw_rect(r, Color("F6EBCB"))
	var c := Vector2(size.x * 0.5, size.y * 0.5)
	var n := 26
	for k in range(n):
		var ang := TAU * k / n + 0.05
		draw_line(c + Vector2(cos(ang), sin(ang)) * minf(size.x, size.y) * 0.44, c + Vector2(cos(ang), sin(ang)) * 700.0, Color("201A17", 0.34), 2.2)
	var rad := minf(size.x, size.y) * 0.40
	var cd := c + Vector2(0, size.y * 0.02)
	draw_circle(cd, rad, Color("F0E9D7"))
	for k in range(-int(rad / 6.0), int(rad / 6.0) + 1):          # hachura de goiva na metade de baixo do disco
		var yy := cd.y + k * 6.0
		if yy < cd.y: continue
		var half := sqrt(maxf(0.0, rad * rad - (yy - cd.y) * (yy - cd.y)))
		draw_line(Vector2(cd.x - half, yy), Vector2(cd.x + half, yy), Color("201A17", 0.55), 1.8)
	draw_arc(cd, rad, 0, TAU, 48, Color("201A17"), 5.0, true)
	var y := size.y - 18.0
	draw_line(Vector2(8, y), Vector2(size.x - 8, y), Color("201A17"), 4.0)
	for k in range(0, int(size.x / 9.0)):
		var x := 8.0 + k * 9.0
		draw_line(Vector2(x, y + 3), Vector2(x - 6, y + 14), Color("201A17"), 1.8)
	draw_rect(r.grow(-2.0), Color("201A17"), false, 4.0)

func _process(delta: float) -> void:
	if _boneco == null: return
	_t += delta
	_boneco.animar(delta, false, 1.0)
	_prox -= delta
	if _prox <= 0.0:
		_prox = randf_range(1.6, 2.8)
		if randf() < 0.3: _boneco.girar()
		else: _boneco.atacar()
