extends TextureRect
class_name IconeGravura
# Ícone de carta / habilidade / melhoria desenhado em XILOGRAVURA (vetorial, sem imagem pronta): placa de papel recortado,
# raios de sol e disco na cor do pigmento, um pictograma de tinta com cortes de papel e uma linha de chão com hachura.
# Os ícones de habilidade dos heróis (hab_q_* / hab_r_*) usam a própria figura de papel do herói em pose de ataque.

const PIC := {
	"armada": "giro", "au": "giro", "rasteira": "giro", "guarda": "giro", "roda": "giro", "tipo_ring": "giro",
	"meialua": "corte", "queda": "corte", "tipo_arco": "corte",
	"berimbau": "onda", "reza": "onda", "tipo_onda": "onda",
	"kimura": "investida", "tipo_investida": "investida",
	"bacamarte": "projetil", "papoamarelo": "projetil", "tipo_proj_reto": "projetil",
	"fogofatuo": "espiral", "tipo_proj_teleguiado": "espiral",
	"garrafada": "estouro", "tipo_proj_estoura": "estouro", "mataleao": "estouro",
	"peixeira": "faca", "amolada": "faca",
	"t_forca": "punho", "t_folego": "coracao", "t_pernas": "bota", "chinelo": "bota", "t_raio": "raio",
	"t_mira": "mira", "mira": "mira", "t_couro": "escudo", "t_estudo": "livro", "t_mesada": "moeda",
	"i_cha": "xicara", "estrela": "lanterna", "atabaque": "tambor", "arretado": "minhoca", "feijoada": "tigela",
	"banho": "gotas", "faixapreta": "faixa", "rei": "coroa", "vela": "vela", "sol": "sol",
}
const ACENTO := {
	"giro": Color("D69A32"), "corte": Color("CC5640"), "onda": Color("5E8597"), "investida": Color("B26C47"),
	"projetil": Color("E9C463"), "espiral": Color("5E8597"), "estouro": Color("D69A32"), "faca": Color("B8A47A"),
	"punho": Color("B26C47"), "coracao": Color("CC5640"), "bota": Color("E9C463"), "raio": Color("D69A32"),
	"mira": Color("CC5640"), "escudo": Color("5E8597"), "livro": Color("E9C463"), "moeda": Color("D69A32"),
	"xicara": Color("B26C47"), "lanterna": Color("D69A32"), "tambor": Color("B26C47"), "minhoca": Color("6F8B57"),
	"tigela": Color("B26C47"), "gotas": Color("5E8597"), "faixa": Color("CC5640"), "coroa": Color("D69A32"),
	"vela": Color("E9C463"), "sol": Color("D69A32"),
}
const ACENTO_TIPO := {"ring": Color("D69A32"), "arco": Color("CC5640"), "onda": Color("5E8597"), "investida": Color("B26C47"), "proj_reto": Color("E9C463"), "proj_teleguiado": Color("5E8597"), "proj_estoura": Color("CC5640")}
const TI := Color("201A17")      # tinta das placas
const T := Color("F0E9D7")       # pictogramas: PAPEL entalhado sobre o disco preto
const P := Color("201A17")       # detalhes dos pictogramas (cortes de tinta)

var nome := ""
var pic := "estouro"
var acento := Color("D69A32")
var heroi := ""
var golpe_id := ""
var golpe_tipo := "ring"
var ultimate := false
var _estilo: StyleEntalhe

static func novo(nome_: String, tam: Vector2) -> IconeGravura:
	var i := IconeGravura.new()
	i.nome = nome_
	i.custom_minimum_size = tam; i.size = tam
	i.mouse_filter = Control.MOUSE_FILTER_IGNORE; i.clip_contents = true
	i.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	if nome_.begins_with("g_"):
		var gid := nome_.substr(2)
		i.pic = "golpe"; i.golpe_id = gid
		var tp := String(Dados.GOLPES[gid]["tipo"]) if Dados.GOLPES.has(gid) else "ring"
		i.golpe_tipo = tp
		i.acento = ACENTO_TIPO.get(tp, Color("D69A32"))
	elif nome_.begins_with("hab_q_") or nome_.begins_with("hab_r_"):
		i.heroi = nome_.substr(6); i.ultimate = nome_.begins_with("hab_r_"); i.pic = "heroi"
		i.acento = Color("A83226") if i.ultimate else Color("D69A32")
		if Gravador.disponivel():
			var f := TextureRect.new(); f.texture = Gravador.retrato(i.heroi, null, 3)
			f.set_anchors_preset(Control.PRESET_FULL_RECT); f.offset_left = 3; f.offset_right = -3; f.offset_top = 3; f.offset_bottom = -3
			f.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; f.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			f.mouse_filter = Control.MOUSE_FILTER_IGNORE
			i.add_child(f)
	else:
		i.pic = PIC.get(nome_, "estouro")
		i.acento = ACENTO.get(i.pic, Color("D69A32"))
	i.resized.connect(i.queue_redraw)
	return i

func _v(c: Vector2, u: float, pts: Array) -> PackedVector2Array:
	var v := PackedVector2Array()
	for p in pts: v.append(c + Vector2(p[0], p[1]) * u)
	return v

func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	if r.size.x < 8.0 or r.size.y < 8.0: return
	var u := minf(r.size.x * 0.70, r.size.y) / 100.0
	var c := r.size * 0.5
	if _estilo == null:
		_estilo = Tela.caixa(Color("F6EBCB"), 3, TI, 0); _estilo.filete = false; _estilo.semente = (nome.hash() % 9) + 1
	_estilo.borda = clampf(r.size.y / 18.0, 2.0, 4.0)
	draw_style_box(_estilo, r.grow(-1.0))
	# raios de sol gravados atrás: linhas de tinta saindo do centro
	var n := 22
	for k in range(n):
		var ang := TAU * k / n + 0.07
		draw_line(c + Vector2(cos(ang), sin(ang)) * 40.0 * u, c + Vector2(cos(ang), sin(ang)) * 260.0, Color(TI, 0.30), 1.8)
	if pic == "heroi":
		var rr := r.size.y * 0.40
		draw_circle(c + Vector2(0, r.size.y * 0.04), rr, Color("F0E9D7"))
		draw_arc(c + Vector2(0, r.size.y * 0.04), rr, 0, TAU, 40, TI, maxf(2.0, r.size.y * 0.05), true)
		if ultimate:                                                      # R: explosão de pontas ao redor
			var pts := PackedVector2Array()
			for k in range(24): pts.append(c + Vector2(0, r.size.y * 0.04) + Vector2(cos(TAU * k / 24.0), sin(TAU * k / 24.0)) * (rr * (1.28 if k % 2 == 0 else 1.08)))
			draw_polyline(pts + PackedVector2Array([pts[0]]), Color("A83226"), maxf(2.0, r.size.y * 0.04), true)
		return
	draw_circle(c, 34.0 * u, TI)                                         # disco de tinta preta
	draw_arc(c, 31.0 * u, 0, TAU, 44, Color("E8D7AE"), 1.6 * u, true)    # filete branco entalhado
	if pic == "golpe":
		ObjetosGravura.efeito(self, golpe_tipo, c, u * 0.78)
		ObjetosGravura.obj(self, ObjetosGravura.OBJ.get(golpe_id, "estrela"), c, u * 0.7)
	else:
		_pictograma(c, u)
	# chão de tinta com hachura
	var y := c.y + 38.0 * u
	draw_line(Vector2(c.x - 36.0 * u, y), Vector2(c.x + 36.0 * u, y), TI, 3.0 * u)
	for k in range(-6, 7):
		var x := c.x + k * 5.5 * u
		draw_line(Vector2(x, y + 2.0 * u), Vector2(x - 4.0 * u, y + 9.0 * u), TI, 1.6 * u)

func _arc_pts(c: Vector2, rad: float, a0: float, a1: float, n: int = 20) -> PackedVector2Array:
	var v := PackedVector2Array()
	for i in range(n + 1):
		var a := lerpf(a0, a1, float(i) / n); v.append(c + Vector2(cos(a), sin(a)) * rad)
	return v

func _estrela(c: Vector2, ro: float, ri: float, pontas: int, col: Color) -> void:
	var v := PackedVector2Array()
	for k in range(pontas * 2):
		var a := PI * k / pontas - PI / 2.0
		v.append(c + Vector2(cos(a), sin(a)) * (ro if k % 2 == 0 else ri))
	draw_colored_polygon(v, col)

func _pictograma(c: Vector2, u: float) -> void:
	match pic:
		"giro":
			draw_arc(c, 22.0 * u, 0, TAU, 36, T, 5.0 * u, true)
			for k in range(4):
				var a := k * PI / 2.0 + 0.35; var d := Vector2(cos(a), sin(a)); var t := Vector2(-d.y, d.x)
				draw_colored_polygon(PackedVector2Array([c + d * 20.0 * u, c + d * 41.0 * u + t * 10.0 * u, c + d * 25.0 * u + t * 15.0 * u]), T)
			draw_circle(c, 8.0 * u, T); draw_circle(c, 3.6 * u, P)
		"corte":
			var cc := c + Vector2(0, 20.0 * u)
			var ext := _arc_pts(cc, 40.0 * u, -2.5, -0.65)
			var inte := _arc_pts(cc, 27.0 * u, -0.65, -2.5)
			var lua := PackedVector2Array(); lua.append_array(ext); lua.append_array(inte)
			draw_colored_polygon(lua, T)
			for k in range(3): draw_line(c + Vector2(-34.0 * u + k * 5.0 * u, 26.0 * u - k * 6.0 * u), c + Vector2(-10.0 * u + k * 5.0 * u, 16.0 * u - k * 6.0 * u), T, 3.0 * u)
			_estrela(c + Vector2(30.0 * u, -16.0 * u), 12.0 * u, 5.0 * u, 6, T)
		"onda":
			var o := c + Vector2(-26.0 * u, 0)
			draw_circle(o, 7.0 * u, T)
			for rad in [16.0, 28.0, 40.0]:
				draw_arc(o, rad * u, -0.95, 0.95, 18, T, 5.5 * u, true)
		"investida":
			draw_colored_polygon(_v(c, u, [[-30, -9], [8, -9], [8, -24], [38, 0], [8, 24], [8, 9], [-30, 9]]), T)
			draw_colored_polygon(_v(c, u, [[-24, -3], [6, -3], [6, 3], [-24, 3]]), P)
			for k in range(3): draw_line(c + Vector2(-44.0 * u, (-16.0 + k * 16.0) * u), c + Vector2(-32.0 * u, (-16.0 + k * 16.0) * u), T, 3.2 * u)
		"projetil":
			var d := Vector2(60, -26).normalized(); var nn := Vector2(-d.y, d.x)
			var tip := c + Vector2(40.0 * u, -17.0 * u)
			draw_line(c + Vector2(-36.0 * u, 14.0 * u), tip - d * 14.0 * u, T, 7.0 * u)
			draw_colored_polygon(PackedVector2Array([tip, tip - d * 22.0 * u + nn * 11.0 * u, tip - d * 22.0 * u - nn * 11.0 * u]), T)
			for s in [-1.0, 1.0]: draw_colored_polygon(PackedVector2Array([c + Vector2(-36.0 * u, 14.0 * u), c + Vector2(-46.0 * u, 14.0 * u) + nn * 9.0 * u * s, c + Vector2(-26.0 * u, 10.0 * u)]), T)
			for k in range(3): draw_line(c + Vector2((-22.0 + k * 14.0) * u, (24.0 - k * 6.0) * u), c + Vector2((-14.0 + k * 14.0) * u, (22.0 - k * 6.0) * u), T, 2.5 * u)
		"espiral":
			var pts := PackedVector2Array()
			for i in range(61):
				var t := i / 60.0; var a := t * TAU * 2.3; var rad := (4.0 + t * 32.0) * u
				pts.append(c + Vector2(cos(a), sin(a)) * rad)
			draw_polyline(pts, T, 4.2 * u, true)
			_estrela(pts[60], 11.0 * u, 4.5 * u, 6, T)
		"estouro":
			_estrela(c, 40.0 * u, 20.0 * u, 12, T)
			draw_circle(c, 13.0 * u, acento); draw_arc(c, 13.0 * u, 0, TAU, 24, T, 3.0 * u, true)
		"faca":
			draw_colored_polygon(_v(c, u, [[-34, 24], [10, -32], [20, -24], [-22, 32]]), P)
			draw_polyline(_v(c, u, [[-34, 24], [10, -32], [20, -24], [-22, 32], [-34, 24]]), T, 3.6 * u, true)
			draw_line(c + Vector2(-26.0 * u, 22.0 * u), c + Vector2(10.0 * u, -22.0 * u), T, 2.0 * u)
			draw_colored_polygon(_v(c, u, [[10, -32], [24, -44], [34, -34], [20, -24]]), T)
		"punho":
			draw_colored_polygon(_v(c, u, [[-16, -4], [16, -4], [18, 22], [-16, 22]]), T)
			for k in range(4): draw_circle(c + Vector2((-12.0 + k * 8.0) * u, -9.0 * u), 7.2 * u, T)
			draw_circle(c + Vector2(-19.0 * u, 8.0 * u), 7.0 * u, T)
			draw_rect(Rect2(c + Vector2(-15.0 * u, 22.0 * u), Vector2(32.0 * u, 10.0 * u)), P); draw_rect(Rect2(c + Vector2(-15.0 * u, 22.0 * u), Vector2(32.0 * u, 10.0 * u)), T, false, 3.0 * u)
			for k in range(3): draw_line(c + Vector2((-8.0 + k * 8.0) * u, -4.0 * u), c + Vector2((-8.0 + k * 8.0) * u, 4.0 * u), P, 1.8 * u)
		"coracao":
			draw_circle(c + Vector2(-12.0 * u, -8.0 * u), 15.0 * u, T); draw_circle(c + Vector2(12.0 * u, -8.0 * u), 15.0 * u, T)
			draw_colored_polygon(_v(c, u, [[-26, -2], [26, -2], [0, 32]]), T)
			draw_arc(c + Vector2(-12.0 * u, -8.0 * u), 8.0 * u, 3.4, 4.6, 8, P, 2.6 * u, true)
		"bota":
			draw_colored_polygon(_v(c, u, [[-18, -30], [2, -30], [2, 4], [28, 10], [28, 26], [-18, 26]]), T)
			draw_line(c + Vector2(-18.0 * u, 18.0 * u), c + Vector2(28.0 * u, 18.0 * u), P, 3.0 * u)
			for k in range(3): draw_line(c + Vector2(-44.0 * u, (-6.0 + k * 10.0) * u), c + Vector2(-26.0 * u, (-6.0 + k * 10.0) * u), T, 3.0 * u)
		"raio":
			draw_colored_polygon(_v(c, u, [[8, -38], [-20, 4], [-2, 4], [-12, 38], [22, -8], [4, -8]]), T)
		"mira":
			draw_arc(c, 27.0 * u, 0, TAU, 36, T, 5.0 * u, true); draw_arc(c, 12.0 * u, 0, TAU, 24, T, 4.0 * u, true)
			draw_line(c + Vector2(-42.0 * u, 0), c + Vector2(-14.0 * u, 0), T, 4.0 * u); draw_line(c + Vector2(14.0 * u, 0), c + Vector2(42.0 * u, 0), T, 4.0 * u)
			draw_line(c + Vector2(0, -42.0 * u), c + Vector2(0, -14.0 * u), T, 4.0 * u); draw_line(c + Vector2(0, 14.0 * u), c + Vector2(0, 42.0 * u), T, 4.0 * u)
			draw_circle(c, 4.0 * u, T)
		"escudo":
			draw_colored_polygon(_v(c, u, [[-26, -30], [26, -30], [26, 4], [0, 36], [-26, 4]]), T)
			draw_line(c + Vector2(0, -24.0 * u), c + Vector2(0, 26.0 * u), P, 3.2 * u); draw_line(c + Vector2(-18.0 * u, -8.0 * u), c + Vector2(18.0 * u, -8.0 * u), P, 3.2 * u)
		"livro":
			draw_colored_polygon(_v(c, u, [[-36, -20], [-2, -12], [-2, 26], [-36, 18]]), P); draw_colored_polygon(_v(c, u, [[36, -20], [2, -12], [2, 26], [36, 18]]), P)
			draw_polyline(_v(c, u, [[-36, -20], [-2, -12], [-2, 26], [-36, 18], [-36, -20]]), T, 3.6 * u, true); draw_polyline(_v(c, u, [[36, -20], [2, -12], [2, 26], [36, 18], [36, -20]]), T, 3.6 * u, true)
			for k in range(3):
				draw_line(c + Vector2(-30.0 * u, (-9.0 + k * 8.0) * u), c + Vector2(-8.0 * u, (-5.0 + k * 8.0) * u), T, 2.0 * u); draw_line(c + Vector2(30.0 * u, (-9.0 + k * 8.0) * u), c + Vector2(8.0 * u, (-5.0 + k * 8.0) * u), T, 2.0 * u)
		"moeda":
			draw_circle(c + Vector2(8.0 * u, 8.0 * u), 26.0 * u, T)
			draw_circle(c, 26.0 * u, P); draw_arc(c, 26.0 * u, 0, TAU, 32, T, 4.0 * u, true); draw_arc(c, 18.0 * u, 0, TAU, 28, T, 2.4 * u, true)
			draw_line(c + Vector2(0, -10.0 * u), c + Vector2(0, 10.0 * u), T, 4.0 * u); draw_line(c + Vector2(-7.0 * u, -4.0 * u), c + Vector2(7.0 * u, -4.0 * u), T, 3.0 * u); draw_line(c + Vector2(-7.0 * u, 4.0 * u), c + Vector2(7.0 * u, 4.0 * u), T, 3.0 * u)
		"xicara":
			draw_colored_polygon(_v(c, u, [[-22, -6], [22, -6], [16, 26], [-16, 26]]), T)
			draw_arc(c + Vector2(24.0 * u, 8.0 * u), 10.0 * u, -1.5, 1.5, 12, T, 4.5 * u, true)
			for k in range(3): draw_polyline(_arc_pts(c + Vector2((-10.0 + k * 10.0) * u, -22.0 * u), 6.0 * u, -0.4, 2.9, 8), T, 3.0 * u, true)
		"lanterna":
			_estrela(c, 38.0 * u, 12.0 * u, 8, T); draw_circle(c, 11.0 * u, P); draw_arc(c, 11.0 * u, 0, TAU, 20, T, 3.0 * u, true)
		"tambor":
			draw_colored_polygon(_v(c, u, [[-28, -12], [28, -12], [22, 28], [-22, 28]]), T)
			draw_colored_polygon(_v(c, u, [[-28, -12], [-22, -22], [22, -22], [28, -12]]), P); draw_polyline(_v(c, u, [[-28, -12], [-22, -22], [22, -22], [28, -12], [-28, -12]]), T, 3.0 * u, true)
			draw_polyline(_v(c, u, [[-24, -10], [-12, 24], [0, -10], [12, 24], [24, -10]]), P, 2.4 * u, true)
		"minhoca":
			var cs := [[-30, 14, 9.0], [-18, 4, 9.5], [-6, 10, 10.0], [6, 0, 10.5], [18, -10, 10.0], [28, -22, 9.5]]
			for q in cs: draw_circle(c + Vector2(q[0], q[1]) * u, float(q[2]) * u, T)
			draw_circle(c + Vector2(30.0 * u, -24.0 * u), 3.0 * u, P)
		"tigela":
			var cb := c + Vector2(0, -4.0 * u)
			var pts := PackedVector2Array(); pts.append_array(_arc_pts(cb, 32.0 * u, 0.0, PI, 24))
			draw_colored_polygon(pts, T)
			for k in range(5): draw_circle(c + Vector2((-20.0 + k * 10.0) * u, (-6.0 + (k % 2) * 5.0) * u), 4.2 * u, P)
			draw_line(c + Vector2(-36.0 * u, -4.0 * u), c + Vector2(36.0 * u, -4.0 * u), T, 4.0 * u)
		"gotas":
			for q in [[-16, -2, 12.0], [14, -12, 10.0], [8, 18, 9.0]]:
				var o := c + Vector2(q[0], q[1]) * u; var rr := float(q[2]) * u
				draw_circle(o + Vector2(0, rr * 0.4), rr, T); draw_colored_polygon(PackedVector2Array([o + Vector2(0, -rr * 1.9), o + Vector2(-rr * 0.9, rr * 0.2), o + Vector2(rr * 0.9, rr * 0.2)]), T)
		"faixa":
			draw_rect(Rect2(c + Vector2(-38.0 * u, -9.0 * u), Vector2(76.0 * u, 18.0 * u)), T)
			draw_circle(c, 13.0 * u, T); draw_circle(c, 7.0 * u, P)
			draw_colored_polygon(_v(c, u, [[8, 8], [24, 30], [14, 32], [2, 12]]), T); draw_colored_polygon(_v(c, u, [[-8, 8], [-24, 30], [-14, 32], [-2, 12]]), T)
		"coroa":
			draw_colored_polygon(_v(c, u, [[-28, 20], [-28, -14], [-14, 2], [0, -24], [14, 2], [28, -14], [28, 20]]), T)
			for q in [[-28, -14], [0, -24], [28, -14]]: draw_circle(c + Vector2(q[0], q[1]) * u, 4.5 * u, P)
			draw_line(c + Vector2(-26.0 * u, 12.0 * u), c + Vector2(26.0 * u, 12.0 * u), P, 2.6 * u)
		"vela":
			draw_rect(Rect2(c + Vector2(-9.0 * u, -4.0 * u), Vector2(18.0 * u, 36.0 * u)), P); draw_rect(Rect2(c + Vector2(-9.0 * u, -4.0 * u), Vector2(18.0 * u, 36.0 * u)), T, false, 3.4 * u)
			draw_colored_polygon(_v(c, u, [[0, -34], [-9, -14], [0, -6], [9, -14]]), T)
			draw_line(c + Vector2(0, -6.0 * u), c + Vector2(0, -2.0 * u), T, 3.0 * u)
		"sol":
			draw_circle(c, 17.0 * u, T); draw_circle(c, 9.0 * u, P)
			for k in range(16):
				var a := TAU * k / 16.0; draw_line(c + Vector2(cos(a), sin(a)) * 22.0 * u, c + Vector2(cos(a), sin(a)) * (32.0 if k % 2 == 0 else 28.0) * u, T, 3.0 * u)
		_:
			_estrela(c, 38.0 * u, 18.0 * u, 10, T)
