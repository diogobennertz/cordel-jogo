extends Control
class_name TituloGravado
# Título de folheto: letras de slab pesada em bloco, com a sombra em ESTEIRA (várias cópias deslocadas, como entalhe
# em relevo) em vermelho queimado e um contorno de tinta por baixo, com ornamentos de losango e um filete ondulado.
# Substitui as imagens de título (agora é texto de verdade, então traduz).

var texto := ""
var tam := 48
var cor_face := Color("201A17")
var cor_relevo := Color("A83226")
var ornamentos := true

static func novo(txt: String, altura: float, face: Color = Color("201A17"), relevo: Color = Color("A83226"), orn: bool = true) -> TituloGravado:
	var t := TituloGravado.new()
	t.texto = txt; t.tam = int(altura); t.cor_face = face; t.cor_relevo = relevo; t.ornamentos = orn
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	t.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var f := Tela.fonte(true)
	var s := f.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, t.tam)
	t.custom_minimum_size = Vector2(s.x + (120.0 if orn else 24.0), s.y + 10.0)
	return t

func _draw() -> void:
	var f := Tela.fonte(true)
	var s := f.get_string_size(texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam)
	var x := (size.x - s.x) * 0.5
	var y := (size.y - s.y) * 0.5 + f.get_ascent(tam) - 2.0
	var prof := maxi(3, int(tam / 9.0))
	for i in range(prof, 0, -1):                      # esteira de relevo
		draw_string(f, Vector2(x + i, y + i), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, cor_relevo)
	draw_string_outline(f, Vector2(x, y), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, maxi(4, int(tam / 8.0)), Color("201A17"))
	draw_string(f, Vector2(x, y), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, cor_face)
	if ornamentos:
		var cy := size.y * 0.5
		for lado: float in [-1.0, 1.0]:
			var bx: float = size.x * 0.5 + lado * (s.x * 0.5 + 38.0)
			var d := 9.0
			draw_colored_polygon(PackedVector2Array([Vector2(bx, cy - d), Vector2(bx + d, cy), Vector2(bx, cy + d), Vector2(bx - d, cy)]), Color("201A17"))
			draw_colored_polygon(PackedVector2Array([Vector2(bx + lado * 18.0, cy - 4), Vector2(bx + lado * 26.0, cy), Vector2(bx + lado * 18.0, cy + 4), Vector2(bx + lado * 10.0, cy)]), cor_relevo)
