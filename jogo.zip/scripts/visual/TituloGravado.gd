extends Control
class_name TituloGravado
# Título de folheto: letras de slab pesada em bloco, com a sombra em ESTEIRA (várias cópias deslocadas, como entalhe
# em relevo) em vermelho queimado e um contorno de tinta por baixo, com ornamentos de losango e um filete ondulado.
# Substitui as imagens de título (agora é texto de verdade, então traduz).

var texto := ""
var tam := 48
var cor_face := Color("201A17")
var cor_relevo := Color("A83226")
var ornamentos := true
var bloco := false

static func novo(txt: String, altura: float, face: Color = Color("201A17"), relevo: Color = Color("A83226"), orn: bool = true, bloco_: bool = false) -> TituloGravado:
	var t := TituloGravado.new()
	t.texto = txt; t.tam = int(altura); t.cor_face = face; t.cor_relevo = relevo; t.ornamentos = orn; t.bloco = bloco_
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	t.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var f := Tela.fonte(true)
	var s := f.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, t.tam)
	t.custom_minimum_size = Vector2(s.x + (150.0 if orn else 24.0) + (40.0 if bloco_ else 0.0), s.y + 10.0 + (22.0 if bloco_ else 0.0))
	return t

func _draw() -> void:
	var f := Tela.fonte(true)
	var s := f.get_string_size(texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam)
	var x := (size.x - s.x) * 0.5
	var y := (size.y - s.y) * 0.5 + f.get_ascent(tam) - 2.0
	if bloco:
		# bloco de madeira entintado: massa preta com filete branco entalhado e cantos cortados
		var pad := Rect2(Vector2(x - 26.0, 2.0), Vector2(s.x + 52.0, size.y - 4.0))
		var c := 10.0
		var pl := PackedVector2Array([pad.position + Vector2(c, 0), Vector2(pad.end.x - c, pad.position.y), Vector2(pad.end.x, pad.position.y + c), Vector2(pad.end.x, pad.end.y - c), Vector2(pad.end.x - c, pad.end.y), Vector2(pad.position.x + c, pad.end.y), Vector2(pad.position.x, pad.end.y - c), Vector2(pad.position.x, pad.position.y + c)])
		draw_colored_polygon(pl, Color("201A17"))
		var ri := pad.grow(-6.0)
		var li := PackedVector2Array([ri.position + Vector2(6, 0), Vector2(ri.end.x - 6, ri.position.y), Vector2(ri.end.x, ri.position.y + 6), Vector2(ri.end.x, ri.end.y - 6), Vector2(ri.end.x - 6, ri.end.y), Vector2(ri.position.x + 6, ri.end.y), Vector2(ri.position.x, ri.end.y - 6), Vector2(ri.position.x, ri.position.y + 6), Vector2(ri.position.x + 6, ri.position.y)])
		draw_polyline(li, Color("E8D7AE"), 1.8, true)
		draw_string(f, Vector2(x + 2, y + 2), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, cor_relevo)
		draw_string(f, Vector2(x, y), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, cor_face)
		if ornamentos:
			for lado: float in [-1.0, 1.0]:
				var bx: float = size.x * 0.5 + lado * (s.x * 0.5 + 56.0); var cy := size.y * 0.5; var d := 8.0
				draw_colored_polygon(PackedVector2Array([Vector2(bx, cy - d), Vector2(bx + d, cy), Vector2(bx, cy + d), Vector2(bx - d, cy)]), cor_relevo)
				draw_line(Vector2(bx + lado * 14.0, cy), Vector2(bx + lado * 30.0, cy), Color("201A17"), 3.0)
		return
	var prof := maxi(3, int(tam / 9.0))
	for i in range(prof, 0, -1):                      # esteira de relevo
		draw_string(f, Vector2(x + i, y + i), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, cor_relevo)
	draw_string_outline(f, Vector2(x, y), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, maxi(4, int(tam / 8.0)), Color("201A17"))
	draw_string(f, Vector2(x, y), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, tam, cor_face)
	if ornamentos:
		var cy := size.y * 0.5
		for lado: float in [-1.0, 1.0]:
			var bx: float = size.x * 0.5 + lado * (s.x * 0.5 + 38.0)
			var d := 9.0
			draw_colored_polygon(PackedVector2Array([Vector2(bx, cy - d), Vector2(bx + d, cy), Vector2(bx, cy + d), Vector2(bx - d, cy)]), Color("201A17"))
			draw_colored_polygon(PackedVector2Array([Vector2(bx + lado * 18.0, cy - 4), Vector2(bx + lado * 26.0, cy), Vector2(bx + lado * 18.0, cy + 4), Vector2(bx + lado * 10.0, cy)]), cor_relevo)
