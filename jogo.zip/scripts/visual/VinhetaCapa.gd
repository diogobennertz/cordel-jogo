extends SubViewportContainer
class_name VinhetaCapa
# A ilustração da capa: um teatro de papel VIVO (mesmas figuras gravadas do jogo, sobre papel entalhado, sol de raios
# gravados atrás). Heróis à esquerda, bichos à direita, respirando e de vez em quando um golpe.

var _bonecos: Array = []
var _t := 0.0
var _prox_golpe := 1.5

func _ready() -> void:
	stretch = true
	var sv := SubViewport.new(); sv.own_world_3d = true; sv.size = Vector2i(custom_minimum_size)
	sv.msaa_3d = Viewport.MSAA_4X; sv.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(sv)
	# céu de papel com o sol gravado
	var env := Environment.new(); env.background_mode = Environment.BG_SKY
	var ceu := Materiais.ceu()
	ceu.set_shader_parameter("topo", Paleta.AZUL); ceu.set_shader_parameter("horizonte", Paleta.PAPEL)
	ceu.set_shader_parameter("chao", Paleta.TERRA); ceu.set_shader_parameter("cor_sol", Paleta.AMARELO)
	ceu.set_shader_parameter("dir_sol", Vector3(0.22, 0.2, -0.95))
	var sky := Sky.new(); sky.sky_material = ceu; env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.ambient_light_color = Color(0.8, 0.74, 0.66); env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	var cam := Camera3D.new(); cam.environment = env; cam.fov = 38.0
	cam.position = Vector3(0, 1.7, 10.0); sv.add_child(cam); cam.look_at(Vector3(0, 2.3, 0), Vector3.UP)
	var luz := DirectionalLight3D.new(); luz.rotation_degrees = Vector3(-38, 22, 0); sv.add_child(luz)
	# chão de papel entalhado
	var chao := MeshInstance3D.new(); var pm := PlaneMesh.new(); pm.size = Vector2(60, 40); chao.mesh = pm
	var m := ShaderMaterial.new(); m.shader = load("res://shaders/xilogravura.gdshader")
	m.set_shader_parameter("cor", Paleta.PALHA); m.set_shader_parameter("relevo", 1.0); m.set_shader_parameter("hachura", 0.0)
	m.set_shader_parameter("sol_dir", Vector3(0.4, 0.8, 0.5))
	chao.material_override = m; chao.position = Vector3(0, 0, -6); sv.add_child(chao)
	# cenário: serras ao fundo, cactos e nuvens
	for dado in [["@cenario:serra:1", -12.0, -26.0, 1.5], ["@cenario:serra:2", 11.0, -28.0, 1.7], ["@cenario:serra:0", 0.0, -34.0, 2.0]]:
		var c := Cartao.novo(dado[0]); c.position = Vector3(dado[1], 0.0, dado[2]); c.scale = Vector3.ONE * dado[3]; sv.add_child(c)
	for dado in [["@planta:7:0", -5.0, -1.5, 1.2], ["@planta:8:0", -4.6, 1.2, 0.9], ["@planta:7:1", 5.1, -1.8, 1.15], ["@planta:9:0", 4.6, -3.5, 0.9]]:
		var c2 := Cartao.novo(dado[0]); c2.position = Vector3(dado[1], 0.0, dado[2]); c2.scale = Vector3.ONE * dado[3]; sv.add_child(c2)
	for dado in [[-3.0, 9.0, -8.0], [4.0, 10.0, -10.0]]:
		var n := Cartao.novo("@cenario:nuvem:%d" % int(absf(dado[0])) if false else "@cenario:nuvem:0"); n.position = Vector3(dado[0], dado[1], dado[2]); n.scale = Vector3.ONE * 2.2; sv.add_child(n)
	# bandeirolas de São João atravessando o alto da gravura, e pássaros no céu
	for i in range(13):
		var t := i / 12.0
		var fl := Cartao.novo("@cenario:bandeira:%d" % (i % 6)); fl.position = Vector3(-4.6 + t * 9.2, 4.25 - 0.8 * sin(t * PI), -1.5); fl.scale = Vector3.ONE * 0.95; sv.add_child(fl)
	for dado in [[-3.2, 3.5, -9.0], [3.4, 3.9, -10.0], [0.6, 4.3, -11.0], [5.0, 3.1, -9.0]]:
		var pa := Cartao.novo("@cenario:passaro:0"); pa.position = Vector3(dado[0], dado[1], dado[2]); pa.scale = Vector3.ONE * 1.5; sv.add_child(pa)
	# elenco: heróis à esquerda, bichos à direita
	var elenco := [["cangaceiro", -3.6, 0.3, 1.1], ["capoeirista", -2.2, 1.0, 1.15], ["benzedeira", -0.75, 0.2, 1.1],
		["saci", 0.75, 0.9, 1.0], ["caipora", 2.2, 0.2, 1.05], ["lobisomem", 3.7, 1.0, 1.15]]
	for e in elenco:
		var b := Boneco.criar(e[0]); b.position = Vector3(e[1], 0.0, e[2]); b.scale = Vector3.ONE * e[3]; b.rotation.y = 0.5 if e[1] < 0.5 else -0.5
		sv.add_child(b); _bonecos.append(b)

func _process(delta: float) -> void:
	_t += delta
	for i in range(_bonecos.size()):
		var b: Boneco = _bonecos[i]
		b.animar(delta, false, 1.0)
	_prox_golpe -= delta
	if _prox_golpe <= 0.0 and not _bonecos.is_empty():
		_prox_golpe = randf_range(1.2, 2.6)
		(_bonecos[randi() % _bonecos.size()] as Boneco).atacar()
