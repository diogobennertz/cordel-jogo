extends Control
class_name Medidor
# Barra de atributo entalhada (vida, velocidade...) e fileira de níveis em quadradinhos de tinta.

var rotulo := ""
var valor := 0.5        # barra: 0..1
var texto_val := ""
var cor := Color("A83226")
var niveis := -1        # >= 0: modo "fileira de níveis"
var maximo := 0

static func barra(rot: String, v: float, txt: String, cor_: Color, larg: float = 330.0) -> Medidor:
	var m := Medidor.new(); m.rotulo = rot; m.valor = clampf(v, 0.05, 1.0); m.texto_val = txt; m.cor = cor_
	m.custom_minimum_size = Vector2(larg, 24); m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return m

static func pips(n: int, maxi: int, cor_: Color = Color("A83226")) -> Medidor:
	var m := Medidor.new(); m.niveis = n; m.maximo = maxi; m.cor = cor_
	m.custom_minimum_size = Vector2(maxi * 15.0 + 2.0, 18); m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return m

func _draw() -> void:
	var T := Color("201A17")
	if niveis >= 0:
		for i in range(maximo):
			var r := Rect2(1 + i * 15, 2, 12, 12)
			draw_rect(Rect2(r.position + Vector2(2, 2), r.size), T)
			draw_rect(r, cor if i < niveis else Color("F6EBCB"))
			draw_rect(r, T, false, 2.4)
		return
	var f := Tela.fonte(true)
	draw_string(f, Vector2(0, 17), rotulo, HORIZONTAL_ALIGNMENT_LEFT, 96, 14, T)
	var bx := 98.0; var bw := size.x - bx - 52.0
	var r := Rect2(bx, 3, bw, 18)
	draw_rect(Rect2(r.position + Vector2(2, 2), r.size), T)
	draw_rect(r, Color("F6EBCB"))
	var fr := Rect2(r.position + Vector2(2, 2), Vector2((bw - 4.0) * valor, r.size.y - 4.0))
	draw_rect(fr, cor)
	var x := fr.position.x
	while x < fr.end.x:                       # hachura de goiva na parte cheia
		draw_line(Vector2(x, fr.end.y), Vector2(minf(x + 8.0, fr.end.x), fr.position.y), Color(T, 0.45), 1.6)
		x += 5.0
	draw_rect(r, T, false, 2.6)
	draw_string(f, Vector2(bx + bw + 6, 17), texto_val, HORIZONTAL_ALIGNMENT_LEFT, 48, 14, T)
