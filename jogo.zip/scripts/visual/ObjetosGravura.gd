extends RefCounted
class_name ObjetosGravura
# Biblioteca de pictogramas de xilogravura: um OBJETO por golpe (berimbau, pandeiro, bússola, pena...) e o EFEITO do
# tipo de ataque (giro, corte, onda, investida, projétil...). Tudo desenhado em código, em tinta com cortes de papel.
# Cada golpe = objeto próprio + efeito do seu tipo (par único; ver mapa em OBJ).

# INVERTIDO de propósito: o objeto é PAPEL entalhado sobre o disco preto (T = papel, P = tinta pros detalhes)
const T := Color("F0E9D7")
const P := Color("201A17")
const VERM := Color("CC5640")

const OBJ := {
	"armada": "pe", "meialua": "pe", "rasteira": "bota", "berimbau": "berimbau", "kimura": "mao", "queda": "faixa", "raspagem": "corrente",
	"fogofatuo": "fogo", "garrafada": "garrafa", "reza": "rosario", "peixeira": "faca", "bacamarte": "bacamarte", "rifle": "rifle",
	"tesoura": "tesoura", "parafuso": "sombrinha", "ferrugem": "serpentina", "repente": "folheto", "glosa": "pena", "desafio": "viola",
	"batucada": "pandeiro", "sapateado": "chinelo", "pandeirada": "cuica", "alfaia": "alfaia", "calunga": "boneca", "cortejo": "coroa",
	"dedilhado": "viola", "caterete": "chapeu_palha", "toada": "notas", "carimbo": "curimbo", "banda_couro": "saxofone", "pisada_forte": "pegada",
	"pandeirao": "zabumba", "coco_embolada": "triangulo", "baiao_rapido": "sanfona", "cocorinha": "berimbau", "cabecada": "cranio", "negativa": "escudo",
	"rede_pesca": "rede", "mare_cheia": "ancora", "canto_mar": "concha", "ponto_jongo": "fogueira", "adjunto": "estrela", "caxambu": "tambor",
	"flautim": "flauta", "chorinho": "cavaquinho", "regional": "pandeiro", "boneco_barro": "boneco_barro", "figurinha_barro": "jarro", "panela_barro": "panela",
	"grito_elis": "microfone", "cancao_forte": "notas", "nota_presa": "clave", "pincelada": "pincel", "tela_viva": "paleta", "retrato_certeiro": "moldura",
	"batuta": "batuta", "bachianas": "partitura", "choros_n1": "violino", "acorde_bruto": "violao", "afro_samba": "atabaque", "valsa_sem_nome": "clave",
	"ponteio": "viola", "cintura_desprezada": "cinto", "chapeu_couro": "chapeu_couro", "cinzelada": "cinzel", "profeta_pedra": "pedra", "pedra_sabao": "pedra",
	"voo_rasante": "aviao", "bis14": "helice", "balao_dirigivel": "balao", "ironia_fina": "oculos", "dom_casmurro": "livro", "memorias_postumas": "caveira",
	"bussola_certeira": "bussola", "linha_telegrafica": "poste", "sinal_fumaca": "fumaca", "tiro_duplo": "pistolas", "cerco": "chapeu_couro", "mira_cangaceiro": "mira",
	"faca_cintura": "faca", "danca_cerco": "flor", "grito_guerra": "megafone", "traco_vivo": "rolo", "painel_vivo": "moldura", "mural_certeiro": "paleta",
	"argumento_certeiro": "megafone", "discurso_haia": "pergaminho", "voto_vencido": "urna", "golpe_quilombo": "lanca", "lanca_certeira": "lanca", "grito_palmares": "punho",
	"bandeira_liberdade": "bandeira", "espada_certeira": "espada", "grito_ouropreto": "sino", "bencao_forte": "rosario", "manto_protetor": "vela", "oracao_certeira": "pomba",
}

static var cor_atual := T
const SENT := Color(0, 0, 0, 0)

static func _cor(col: Color) -> Color:
	return cor_atual if col.a == 0.0 else col

static func _p(c: Vector2, u: float, pts: Array) -> PackedVector2Array:
	var v := PackedVector2Array()
	for q in pts: v.append(c + Vector2(q[0], q[1]) * u)
	return v

static func _poli(ci: CanvasItem, c: Vector2, u: float, pts: Array, col: Color = SENT) -> void:
	ci.draw_colored_polygon(_p(c, u, pts), _cor(col))

static func _contorno(ci: CanvasItem, c: Vector2, u: float, pts: Array, esp: float = 3.0) -> void:
	var v := _p(c, u, pts); v.append(v[0]); ci.draw_polyline(v, _cor(SENT), esp * u, true)

static func _circ(ci: CanvasItem, c: Vector2, u: float, x: float, y: float, r: float, col: Color = SENT) -> void:
	ci.draw_circle(c + Vector2(x, y) * u, r * u, _cor(col))

static func _lin(ci: CanvasItem, c: Vector2, u: float, a: Array, b: Array, esp: float = 3.0, col: Color = SENT) -> void:
	ci.draw_line(c + Vector2(a[0], a[1]) * u, c + Vector2(b[0], b[1]) * u, _cor(col), esp * u, true)

static func _arco(ci: CanvasItem, c: Vector2, u: float, x: float, y: float, r: float, a0: float, a1: float, esp: float = 3.0, col: Color = SENT) -> void:
	ci.draw_arc(c + Vector2(x, y) * u, r * u, a0, a1, 18, _cor(col), esp * u, true)

static func _estrela(ci: CanvasItem, c: Vector2, ro: float, ri: float, pontas: int, col: Color) -> void:
	var v := PackedVector2Array()
	for k in range(pontas * 2):
		var a := PI * k / pontas - PI / 2.0
		v.append(c + Vector2(cos(a), sin(a)) * (ro if k % 2 == 0 else ri))
	ci.draw_colored_polygon(v, col)

# ---------- efeito do tipo de ataque (atrás do objeto) ----------
static func efeito(ci: CanvasItem, tipo: String, c: Vector2, u: float) -> void:
	cor_atual = VERM
	u *= 0.8
	match tipo:
		"ring":
			for k in range(3):
				var a := k * TAU / 3.0 + 0.4
				ci.draw_arc(c, 33.0 * u, a, a + 1.55, 14, cor_atual, 4.2 * u, true)
				var tip := c + Vector2(cos(a + 1.55), sin(a + 1.55)) * 33.0 * u; var d := Vector2(-sin(a + 1.55), cos(a + 1.55))
				ci.draw_colored_polygon(PackedVector2Array([tip + d * 9.0 * u, tip + (Vector2(cos(a + 1.55), sin(a + 1.55))) * 7.0 * u, tip - Vector2(cos(a + 1.55), sin(a + 1.55)) * 7.0 * u]), cor_atual)
		"arco":
			var cc := c + Vector2(-4.0, 26.0) * u
			var ext := PackedVector2Array(); var inte := PackedVector2Array()
			for i in range(21):
				var a := lerpf(-2.7, -0.45, i / 20.0)
				ext.append(cc + Vector2(cos(a), sin(a)) * 48.0 * u); inte.append(cc + Vector2(cos(a), sin(a)) * 34.0 * u)
			inte.reverse(); ext.append_array(inte); ci.draw_colored_polygon(ext, cor_atual)
		"onda":
			var o := c + Vector2(-34.0, 6.0) * u
			for r in [22.0, 34.0, 46.0]:
				ci.draw_arc(o, r * u, -0.85, 0.85, 16, cor_atual, 4.6 * u, true)
		"investida":
			for k in range(3): ci.draw_line(c + Vector2(-46.0, (-18.0 + k * 18.0)) * u, c + Vector2(-24.0 + k * 3.0, (-18.0 + k * 18.0)) * u, cor_atual, 4.0 * u)
			_poli(ci, c, u, [[24, -30], [46, 0], [24, 30], [30, 0]])
		"proj_reto":
			for k in range(3): ci.draw_line(c + Vector2(-48.0, (-14.0 + k * 14.0)) * u, c + Vector2(-26.0, (-14.0 + k * 14.0)) * u, cor_atual, 3.6 * u)
			_poli(ci, c, u, [[30, -8], [48, 0], [30, 8]])
		"proj_teleguiado":
			var pts := PackedVector2Array()
			for i in range(48):
				var t := i / 47.0; var a := t * TAU * 1.8; var r := (4.0 + t * 34.0) * u
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			ci.draw_polyline(pts, cor_atual, 3.4 * u, true)
		"proj_estoura":
			_estrela(ci, c, 46.0 * u, 26.0 * u, 12, cor_atual)

# ---------- objetos ----------
static func _cordas(ci: CanvasItem, c: Vector2, u: float, corpo: float, braco: float, cintura: float) -> void:
	var rot := -0.65
	var ox := c
	for k in range(2):
		var cor := T if k == 0 else P
		var f := 1.0 if k == 0 else 0.72
		_circ(ci, ox, u, 0, 10, corpo * f, cor); _circ(ci, ox, u, 0, -2, (corpo * (0.78 + cintura)) * f, cor)
	var d := Vector2(cos(rot - PI / 2.0), sin(rot - PI / 2.0))
	_lin(ci, c, u, [0, 10], [braco * 0.55, 10 - braco], 5.0)
	_circ(ci, c, u, braco * 0.55, 10 - braco - 3, 5.0)
	_circ(ci, c, u, 0, 10, corpo * 0.28, T)

static func _tambor(ci: CanvasItem, c: Vector2, u: float, alt: float, lt: float, lb: float, cordas: bool = true) -> void:
	_poli(ci, c, u, [[-lt, -alt * 0.5], [lt, -alt * 0.5], [lb, alt * 0.5], [-lb, alt * 0.5]])
	_poli(ci, c, u, [[-lt, -alt * 0.5], [-lt + 4, -alt * 0.5 - 7], [lt - 4, -alt * 0.5 - 7], [lt, -alt * 0.5]], P)
	_contorno(ci, c, u, [[-lt, -alt * 0.5], [-lt + 4, -alt * 0.5 - 7], [lt - 4, -alt * 0.5 - 7], [lt, -alt * 0.5]], 2.4)
	if cordas: ci.draw_polyline(_p(c, u, [[-lt + 2, -alt * 0.5 + 2], [-lb * 0.5, alt * 0.5 - 2], [0, -alt * 0.5 + 2], [lb * 0.5, alt * 0.5 - 2], [lt - 2, -alt * 0.5 + 2]]), P, 2.2 * u, true)

static func _chapeu(ci: CanvasItem, c: Vector2, u: float, estrela: bool, palha: bool) -> void:
	var aba := PackedVector2Array(); _poli(ci, c, u, [[-34, 8], [-20, 2], [20, 2], [34, 8], [22, 18], [-22, 18]])
	_poli(ci, c, u, [[-16, 2], [-12, -22], [12, -22], [16, 2]])
	if palha:
		for k in range(4): _lin(ci, c, u, [-14 + k * 9, 4], [-12 + k * 8, -20], 1.6, P)
	if estrela: _estrela(ci, c + Vector2(0, -8) * u, 8.0 * u, 3.4 * u, 5, P)
	_lin(ci, c, u, [-16, 0], [16, 0], 3.0, P)

static func obj(ci: CanvasItem, nome: String, c: Vector2, u: float) -> void:
	cor_atual = T
	match nome:
		"pe":
			_poli(ci, c, u, [[-10, -34], [8, -34], [10, -4], [34, 8], [34, 24], [-14, 24], [-14, -4]])
			_lin(ci, c, u, [-14, 16], [34, 16], 3.0, P)
			for k in range(3): _lin(ci, c, u, [-6, -26 + k * 8], [4, -26 + k * 8], 1.8, P)
		"bota":
			_poli(ci, c, u, [[-18, -32], [4, -32], [4, 2], [30, 8], [30, 26], [-18, 26]])
			_poli(ci, c, u, [[-18, 20], [30, 20], [30, 26], [-18, 26]], P); _lin(ci, c, u, [-18, 8], [4, 8], 2.4, P)
		"berimbau":
			_arco(ci, c, u, -14, 0, 38, -1.15, 1.15, 4.0)
			_lin(ci, c, u, [14, -32], [14, 32], 1.8, T)
			_circ(ci, c, u, -22, 28, 11.0); _circ(ci, c, u, -22, 28, 5.0, P)
			_lin(ci, c, u, [-6, 0], [-30, -6], 4.0)
		"mao":
			_poli(ci, c, u, [[-18, 6], [-18, -20], [-12, -20], [-12, -4], [-8, -32], [-2, -32], [-2, -6], [4, -34], [10, -34], [8, -4], [16, -26], [22, -24], [14, 6], [20, 8], [18, 28], [-12, 30]])
			_lin(ci, c, u, [-16, 18], [16, 18], 2.4, P)
		"faixa":
			_poli(ci, c, u, [[-36, -9], [36, -9], [36, 9], [-36, 9]])
			_circ(ci, c, u, 0, 0, 14.0); _circ(ci, c, u, 0, 0, 7.0, P)
			_poli(ci, c, u, [[6, 8], [24, 32], [14, 34], [0, 10]]); _poli(ci, c, u, [[-6, 8], [-24, 32], [-14, 34], [0, 10]])
			_lin(ci, c, u, [-32, 0], [-18, 0], 2.0, P)
		"corrente":
			for k in range(4):
				var x := -27.0 + k * 18.0
				ci.draw_arc(c + Vector2(x, (k % 2) * 8.0 - 4.0) * u, 11.0 * u, 0, TAU, 14, T, 5.0 * u, true)
		"fogo":
			_poli(ci, c, u, [[0, -38], [14, -12], [24, -2], [20, 22], [0, 34], [-20, 22], [-24, -2], [-12, -14], [-10, -26]])
			_poli(ci, c, u, [[0, -10], [10, 6], [6, 24], [-6, 24], [-10, 6]], P); _poli(ci, c, u, [[0, 6], [5, 18], [-5, 18]])
		"garrafa":
			_poli(ci, c, u, [[-6, -36], [6, -36], [6, -18], [18, -2], [18, 32], [-18, 32], [-18, -2], [-6, -18]])
			_poli(ci, c, u, [[-12, 4], [12, 4], [12, 22], [-12, 22]], P); _lin(ci, c, u, [-6, 13], [6, 13], 2.0)
			_poli(ci, c, u, [[-7, -42], [7, -42], [6, -36], [-6, -36]], P)
		"rosario":
			for k in range(9):
				var a := PI * 0.1 + k * (PI * 0.8 / 8.0)
				_circ(ci, c, u, cos(a) * 30.0, -16.0 + sin(a) * 34.0, 5.0)
			_lin(ci, c, u, [0, 18], [0, 36], 4.0); _lin(ci, c, u, [-8, 25], [8, 25], 4.0)
		"faca":
			_poli(ci, c, u, [[-34, 26], [14, -32], [24, -24], [-20, 34]], P); _contorno(ci, c, u, [[-34, 26], [14, -32], [24, -24], [-20, 34]], 3.4)
			_lin(ci, c, u, [-26, 24], [12, -22], 1.8)
			_poli(ci, c, u, [[14, -32], [28, -44], [38, -34], [24, -24]])
		"bacamarte":
			_poli(ci, c, u, [[-34, -8], [18, -8], [18, -3], [34, -12], [34, 12], [18, 3], [18, 8], [-8, 8], [-24, 18], [-34, 12]])
			_circ(ci, c, u, 4, 0, 4.0, P)
		"rifle":
			_poli(ci, c, u, [[-36, -6], [34, -8], [34, -2], [6, 0], [-4, 6], [-12, 18], [-24, 18], [-22, 4], [-36, 4]])
			_lin(ci, c, u, [-4, -8], [8, -8], 2.0, P)
		"tesoura":
			_lin(ci, c, u, [-28, 28], [26, -30], 4.5); _lin(ci, c, u, [28, 28], [-26, -30], 4.5)
			ci.draw_arc(c + Vector2(-18, 26) * u, 11.0 * u, 0, TAU, 16, T, 4.5 * u, true); ci.draw_arc(c + Vector2(18, 26) * u, 11.0 * u, 0, TAU, 16, T, 4.5 * u, true)
		"sombrinha":
			_poli(ci, c, u, [[-36, 0], [-24, -22], [0, -32], [24, -22], [36, 0], [24, -6], [12, 0], [0, -6], [-12, 0], [-24, -6]])
			for k in range(4): _lin(ci, c, u, [-24 + k * 16, -4], [-18 + k * 12, -24], 2.0, P)
			_lin(ci, c, u, [0, -6], [0, 30], 4.0); _arco(ci, c, u, -6, 30, 6, 0, PI, 4.0)
		"serpentina":
			var pts := PackedVector2Array()
			for i in range(30): pts.append(c + Vector2(-34.0 + i * 2.3, sin(i * 0.7) * 14.0) * u)
			ci.draw_polyline(pts, T, 6.0 * u, true)
			ci.draw_polyline(pts, P, 1.6 * u, true)
		"folheto":
			_poli(ci, c, u, [[-24, -34], [24, -34], [24, 34], [-24, 34]], P); _contorno(ci, c, u, [[-24, -34], [24, -34], [24, 34], [-24, 34]], 3.4)
			_poli(ci, c, u, [[-16, -26], [16, -26], [16, -4], [-16, -4]])
			for k in range(4): _lin(ci, c, u, [-16, 6 + k * 7], [16 - (k % 2) * 6, 6 + k * 7], 2.2)
		"pena":
			_poli(ci, c, u, [[-30, 32], [-4, 4], [26, -34], [32, -20], [10, 8], [-14, 24]])
			_lin(ci, c, u, [-20, 20], [24, -26], 1.6, P); _poli(ci, c, u, [[-34, 36], [-26, 24], [-22, 32]])
		"viola", "violao", "cavaquinho", "violino":
			var tam := 1.0 if nome != "cavaquinho" else 0.8
			_cordas(ci, c + Vector2(-4, 4) * u, u * tam, 20.0, 46.0, 0.08)
		"pandeiro":
			ci.draw_circle(c, 30.0 * u, T); ci.draw_circle(c, 23.0 * u, P); ci.draw_arc(c, 23.0 * u, 0, TAU, 28, T, 2.6 * u, true)
			for k in range(6):
				var a := k * TAU / 6.0; _circ(ci, c, u, cos(a) * 27.0, sin(a) * 27.0, 4.6, P)
			_lin(ci, c, u, [-10, 0], [10, 0], 3.0); _lin(ci, c, u, [0, -10], [0, 10], 3.0)
		"chinelo":
			_poli(ci, c, u, [[-8, -34], [10, -34], [14, -8], [12, 20], [-12, 32], [-16, 6]])
			_lin(ci, c, u, [-12, -2], [12, 4], 5.0, P); _lin(ci, c, u, [0, -2], [0, 8], 4.0, P)
		"cuica":
			_tambor(ci, c, u, 56.0, 20.0, 20.0, false)
			_lin(ci, c, u, [0, -26], [0, 38], 3.0, P); _circ(ci, c, u, 0, 40, 4.0)
		"alfaia", "curimbo", "zabumba", "tambor", "atabaque":
			match nome:
				"alfaia": _tambor(ci, c, u, 48.0, 30.0, 30.0)
				"curimbo": _tambor(ci, c, u, 62.0, 16.0, 22.0)
				"zabumba": _tambor(ci, c, u, 46.0, 32.0, 32.0, false); _lin(ci, c, u, [-32, 0], [32, 0], 3.0, P)
				"tambor": _tambor(ci, c, u, 52.0, 22.0, 28.0)
				_: _tambor(ci, c, u, 66.0, 14.0, 24.0)
		"boneca":
			_circ(ci, c, u, 0, -22, 11.0); _poli(ci, c, u, [[-10, -12], [10, -12], [20, 34], [-20, 34]])
			_lin(ci, c, u, [-24, -4], [24, -4], 5.0); _circ(ci, c, u, -4, -22, 2.0, P); _circ(ci, c, u, 4, -22, 2.0, P)
		"coroa":
			_poli(ci, c, u, [[-30, 22], [-30, -14], [-14, 2], [0, -26], [14, 2], [30, -14], [30, 22]])
			for q in [[-30, -14], [0, -26], [30, -14]]: _circ(ci, c, u, q[0], q[1], 5.0, P)
			_lin(ci, c, u, [-27, 14], [27, 14], 3.0, P)
		"chapeu_palha": _chapeu(ci, c, u, false, true)
		"chapeu_couro": _chapeu(ci, c, u, true, false)
		"notas":
			_circ(ci, c, u, -14, 24, 9.0); _circ(ci, c, u, 16, 14, 9.0)
			_lin(ci, c, u, [-6, 24], [-6, -26], 4.0); _lin(ci, c, u, [24, 14], [24, -34], 4.0); _poli(ci, c, u, [[-6, -26], [24, -34], [24, -24], [-6, -16]])
		"saxofone":
			_poli(ci, c, u, [[10, -34], [20, -34], [20, 14], [6, 34], [-14, 34], [-26, 20], [-14, 20], [-8, 24], [0, 24], [10, 10]])
			_poli(ci, c, u, [[-30, 14], [-10, 14], [-6, 26], [-34, 26]], P)
			for k in range(3): _circ(ci, c, u, 15, -24 + k * 12, 3.2, P)
		"pegada":
			_poli(ci, c, u, [[-18, -6], [18, -6], [22, 20], [-22, 20]])
			for k in range(4): _circ(ci, c, u, -18 + k * 12, -16 - (1 if k == 1 or k == 2 else 0) * 4, 6.0)
		"triangulo":
			_lin(ci, c, u, [-28, 26], [0, -30], 5.0); _lin(ci, c, u, [0, -30], [28, 26], 5.0); _lin(ci, c, u, [-28, 26], [18, 26], 5.0)
			_lin(ci, c, u, [26, -2], [40, -24], 3.6)
		"sanfona":
			for k in range(7): _poli(ci, c, u, [[-30 + k * 9, -22 + (k % 2) * 4], [-24 + k * 9, -22 + (k % 2) * 4], [-24 + k * 9, 22 - (k % 2) * 4], [-30 + k * 9, 22 - (k % 2) * 4]], T if k % 2 == 0 else P)
			_poli(ci, c, u, [[-40, -26], [-30, -26], [-30, 26], [-40, 26]]); _poli(ci, c, u, [[30, -26], [40, -26], [40, 26], [30, 26]])
			_contorno(ci, c, u, [[-30, -22], [32, -22], [32, 22], [-30, 22]], 2.4)
		"cranio":
			ci.draw_circle(c + Vector2(0, -6) * u, 26.0 * u, T)
			_poli(ci, c, u, [[-14, 8], [14, 8], [12, 30], [-12, 30]]); _circ(ci, c, u, -10, -8, 7.0, P); _circ(ci, c, u, 10, -8, 7.0, P)
			_poli(ci, c, u, [[0, 4], [-4, 12], [4, 12]], P); for k in range(4): _lin(ci, c, u, [-9 + k * 6, 20], [-9 + k * 6, 30], 1.8, P)
		"escudo":
			_poli(ci, c, u, [[-26, -30], [26, -30], [26, 4], [0, 36], [-26, 4]])
			_lin(ci, c, u, [0, -24], [0, 26], 3.0, P); _lin(ci, c, u, [-18, -8], [18, -8], 3.0, P)
		"rede":
			_poli(ci, c, u, [[-34, -26], [34, -26], [24, 30], [-24, 30]], P); _contorno(ci, c, u, [[-34, -26], [34, -26], [24, 30], [-24, 30]], 3.4)
			for k in range(1, 5): _lin(ci, c, u, [-34 + k * 13.6, -26], [-24 + k * 9.6, 30], 1.8)
			for k in range(1, 4): _lin(ci, c, u, [-32 + k * 2.4, -26 + k * 13.6], [32 - k * 2.4, -26 + k * 13.6], 1.8)
		"ancora":
			ci.draw_arc(c + Vector2(0, 14) * u, 28.0 * u, 0.15, PI - 0.15, 18, T, 5.5 * u, true)
			_lin(ci, c, u, [0, -26], [0, 38], 5.5); _lin(ci, c, u, [-12, -14], [12, -14], 5.0); ci.draw_arc(c + Vector2(0, -32) * u, 6.0 * u, 0, TAU, 12, T, 4.0 * u, true)
		"concha":
			_poli(ci, c, u, [[0, 34], [-34, 4], [-26, -18], [-10, -28], [0, -30], [10, -28], [26, -18], [34, 4]])
			for k in range(-2, 3): _lin(ci, c, u, [0, 30], [k * 13, -22], 2.0, P)
		"fogueira":
			for k in range(3): _lin(ci, c, u, [-30 + k * 6, 30 - k * 2], [24 - k * 4, 14 + k * 4], 6.0)
			_poli(ci, c, u, [[0, -34], [12, -10], [18, 10], [0, 20], [-18, 10], [-10, -12]]); _poli(ci, c, u, [[0, -4], [7, 8], [-7, 8]], P)
		"estrela": _estrela(ci, c, 38.0 * u, 16.0 * u, 8, T); ci.draw_circle(c, 9.0 * u, P)
		"flauta":
			_poli(ci, c, u, [[-38, 10], [34, -22], [38, -14], [-34, 20]])
			for k in range(5): _circ(ci, c, u, -22 + k * 11, 5 - k * 4.4, 2.8, P)
		"boneco_barro":
			_circ(ci, c, u, 0, -22, 12.0); _poli(ci, c, u, [[-16, -10], [16, -10], [20, 30], [-20, 30]])
			_circ(ci, c, u, -4, -24, 2.2, P); _circ(ci, c, u, 4, -24, 2.2, P); _lin(ci, c, u, [-18, 0], [-30, 12], 4.5); _lin(ci, c, u, [18, 0], [30, 12], 4.5)
		"jarro":
			_poli(ci, c, u, [[-10, -34], [10, -34], [10, -22], [26, -6], [24, 26], [14, 34], [-14, 34], [-24, 26], [-26, -6], [-10, -22]])
			_poli(ci, c, u, [[-20, 2], [20, 2], [20, 10], [-20, 10]], P); ci.draw_arc(c + Vector2(28, -8) * u, 12.0 * u, -1.5, 1.5, 12, T, 4.5 * u, true)
		"panela":
			_poli(ci, c, u, [[-28, -10], [28, -10], [24, 28], [-24, 28]]); _poli(ci, c, u, [[-32, -16], [32, -16], [28, -10], [-28, -10]], P)
			_lin(ci, c, u, [-32, -4], [-42, -4], 4.0); _lin(ci, c, u, [32, -4], [42, -4], 4.0); _contorno(ci, c, u, [[-32, -16], [32, -16], [28, -10], [-28, -10]], 2.4)
		"microfone":
			ci.draw_circle(c + Vector2(0, -16) * u, 16.0 * u, T)
			for k in range(3): _lin(ci, c, u, [-12, -22 + k * 7], [12, -22 + k * 7], 1.8, P)
			_poli(ci, c, u, [[-6, -2], [6, -2], [4, 34], [-4, 34]])
		"clave":
			ci.draw_arc(c + Vector2(-2, 14) * u, 14.0 * u, 0, TAU * 0.85, 18, T, 5.5 * u, true)
			_lin(ci, c, u, [8, -34], [8, 26], 5.0); ci.draw_arc(c + Vector2(0, -22) * u, 11.0 * u, -PI * 0.5, PI * 0.5, 12, T, 5.0 * u, true); _circ(ci, c, u, -4, 30, 5.0)
		"pincel":
			_lin(ci, c, u, [-30, 32], [12, -14], 5.5)
			_poli(ci, c, u, [[6, -10], [18, -22], [34, -34], [30, -14], [18, -2]]); _lin(ci, c, u, [12, -14], [20, -8], 2.4, P)
		"paleta":
			_poli(ci, c, u, [[-34, -2], [-24, -22], [0, -32], [26, -24], [34, -4], [22, 16], [6, 12], [2, 30], [-16, 30], [-32, 16]])
			_circ(ci, c, u, -16, -8, 6.0, P); _circ(ci, c, u, 4, -16, 6.0, P); _circ(ci, c, u, 20, -4, 6.0, P); _circ(ci, c, u, -14, 12, 6.0, P)
		"moldura":
			_poli(ci, c, u, [[-32, -28], [32, -28], [32, 28], [-32, 28]]); _poli(ci, c, u, [[-23, -19], [23, -19], [23, 19], [-23, 19]], P)
			_circ(ci, c, u, 0, -4, 7.0); _poli(ci, c, u, [[-12, 19], [-8, 6], [8, 6], [12, 19]])
		"batuta":
			_lin(ci, c, u, [-30, 30], [28, -28], 4.5); _circ(ci, c, u, -30, 30, 7.0); _estrela(ci, c + Vector2(30, -30) * u, 9.0 * u, 3.6 * u, 5, T)
		"partitura":
			_poli(ci, c, u, [[-28, -30], [28, -30], [28, 30], [-28, 30]], P); _contorno(ci, c, u, [[-28, -30], [28, -30], [28, 30], [-28, 30]], 3.4)
			for k in range(5): _lin(ci, c, u, [-22, -14 + k * 6], [22, -14 + k * 6], 1.4)
			_circ(ci, c, u, -6, 12, 5.0); _lin(ci, c, u, [-1, 12], [-1, -12], 3.0)
		"cinto":
			_poli(ci, c, u, [[-38, -10], [38, -10], [38, 10], [-38, 10]]); _poli(ci, c, u, [[-12, -16], [12, -16], [12, 16], [-12, 16]], P)
			_contorno(ci, c, u, [[-12, -16], [12, -16], [12, 16], [-12, 16]], 3.0); _circ(ci, c, u, 0, 0, 4.0)
		"cinzel":
			_poli(ci, c, u, [[-34, 34], [-26, 26], [10, -10], [20, -2], [-20, 36]], P); _contorno(ci, c, u, [[-34, 34], [-26, 26], [10, -10], [20, -2], [-20, 36]], 3.4)
			_poli(ci, c, u, [[10, -10], [24, -24], [34, -14], [20, -2]]); _estrela(ci, c + Vector2(30, -30) * u, 7.0 * u, 3.0 * u, 5, T)
		"pedra":
			_poli(ci, c, u, [[-34, 20], [-28, -8], [-10, -28], [16, -26], [34, -2], [30, 24], [0, 30]])
			_lin(ci, c, u, [-10, -24], [-4, 6], 2.2, P); _lin(ci, c, u, [14, -22], [8, 12], 2.2, P)
		"aviao":
			_poli(ci, c, u, [[-38, 0], [-14, -6], [10, -34], [20, -34], [10, -4], [34, -6], [40, 0], [34, 6], [10, 4], [20, 34], [10, 34], [-14, 6]])
		"helice":
			_poli(ci, c, u, [[0, -2], [-8, -34], [8, -34]]); _poli(ci, c, u, [[2, 0], [34, -8], [34, 8]]); _poli(ci, c, u, [[0, 2], [8, 34], [-8, 34]]); _poli(ci, c, u, [[-2, 0], [-34, 8], [-34, -8]])
			ci.draw_circle(c, 8.0 * u, P); ci.draw_arc(c, 8.0 * u, 0, TAU, 14, T, 3.0 * u, true)
		"balao":
			ci.draw_circle(c + Vector2(0, -8) * u, 28.0 * u, T)
			for k in range(-1, 2): ci.draw_arc(c + Vector2(k * 12, -8) * u, 20.0 * u, -PI * 0.5 + 0.9, PI * 0.5 - 0.9, 12, P, 2.0 * u, true)
			_lin(ci, c, u, [-12, 18], [-8, 30], 2.4); _lin(ci, c, u, [12, 18], [8, 30], 2.4); _poli(ci, c, u, [[-9, 30], [9, 30], [7, 40], [-7, 40]])
		"oculos":
			ci.draw_arc(c + Vector2(-16, 0) * u, 14.0 * u, 0, TAU, 18, T, 5.0 * u, true); ci.draw_arc(c + Vector2(16, 0) * u, 14.0 * u, 0, TAU, 18, T, 5.0 * u, true)
			_lin(ci, c, u, [-2, -2], [2, -2], 5.0); _lin(ci, c, u, [-30, -4], [-40, -10], 4.0); _lin(ci, c, u, [30, -4], [40, -10], 4.0)
		"livro":
			_poli(ci, c, u, [[-36, -22], [-2, -14], [-2, 28], [-36, 20]], P); _poli(ci, c, u, [[36, -22], [2, -14], [2, 28], [36, 20]], P)
			_contorno(ci, c, u, [[-36, -22], [-2, -14], [-2, 28], [-36, 20]], 3.4); _contorno(ci, c, u, [[36, -22], [2, -14], [2, 28], [36, 20]], 3.4)
			for k in range(3):
				_lin(ci, c, u, [-30, -10 + k * 8], [-8, -6 + k * 8], 1.8); _lin(ci, c, u, [30, -10 + k * 8], [8, -6 + k * 8], 1.8)
		"caveira":
			ci.draw_circle(c + Vector2(0, -4) * u, 24.0 * u, T); _poli(ci, c, u, [[-14, 10], [14, 10], [10, 30], [-10, 30]])
			_circ(ci, c, u, -9, -6, 6.0, P); _circ(ci, c, u, 9, -6, 6.0, P); for k in range(4): _lin(ci, c, u, [-8 + k * 5.5, 18], [-8 + k * 5.5, 28], 1.8, P)
			_lin(ci, c, u, [-34, 22], [34, 30], 4.0); _lin(ci, c, u, [34, 22], [-34, 30], 4.0)
		"bussola":
			ci.draw_circle(c, 30.0 * u, T); ci.draw_circle(c, 23.0 * u, P)
			_poli(ci, c, u, [[0, -20], [6, 0], [-6, 0]]); _poli(ci, c, u, [[0, 20], [6, 0], [-6, 0]], T); _lin(ci, c, u, [0, 0], [0, 0], 1.0)
			for k in range(8): _lin(ci, c, u, [cos(k * PI / 4.0) * 24, sin(k * PI / 4.0) * 24], [cos(k * PI / 4.0) * 29, sin(k * PI / 4.0) * 29], 3.0, T)
		"poste":
			_lin(ci, c, u, [0, -36], [0, 38], 5.0); _lin(ci, c, u, [-22, -26], [22, -26], 4.5); _lin(ci, c, u, [-16, -14], [16, -14], 4.0)
			for k in range(4): _circ(ci, c, u, [-22, -8, 8, 22][k], -28, 3.4, P)
			ci.draw_polyline(_p(c, u, [[-22, -26], [-40, -8], [-34, 10]]), T, 2.0 * u, true); ci.draw_polyline(_p(c, u, [[22, -26], [40, -8], [34, 10]]), T, 2.0 * u, true)
		"fumaca":
			for k in range(4):
				_circ(ci, c, u, -6 + (k % 2) * 12, 22 - k * 15, 10.0 + k * 3.0)
			_poli(ci, c, u, [[-20, 32], [20, 32], [14, 20], [-14, 20]], P)
		"pistolas":
			for s in [-1.0, 1.0]:
				_poli(ci, c, u, [[s * 4 - 22, -14], [s * 4 + 14, -14], [s * 4 + 14, -2], [s * 4 + 2, -2], [s * 4 + 6, 22], [s * 4 - 8, 22], [s * 4 - 8, -2], [s * 4 - 22, -2]] if s < 0 else [[-14, 4], [24, 4], [24, 16], [8, 16], [12, 38], [-2, 38], [-2, 16], [-14, 16]])
		"mira":
			ci.draw_arc(c, 26.0 * u, 0, TAU, 28, T, 5.0 * u, true)
			for a in [0.0, PI * 0.5, PI, PI * 1.5]: _lin(ci, c, u, [cos(a) * 14, sin(a) * 14], [cos(a) * 40, sin(a) * 40], 4.0)
			ci.draw_circle(c, 5.0 * u, T)
		"flor":
			for k in range(6):
				var a := k * TAU / 6.0; _circ(ci, c, u, cos(a) * 16.0, sin(a) * 16.0, 11.0)
			ci.draw_circle(c, 9.0 * u, P); ci.draw_arc(c, 9.0 * u, 0, TAU, 14, T, 3.0 * u, true)
		"megafone":
			_poli(ci, c, u, [[-30, -8], [-14, -8], [30, -30], [30, 30], [-14, 8], [-30, 8]]); _poli(ci, c, u, [[20, -22], [26, -22], [26, 22], [20, 22]], P)
			_poli(ci, c, u, [[-24, 8], [-14, 8], [-10, 30], [-20, 30]])
		"rolo":
			_poli(ci, c, u, [[-30, -28], [18, -28], [18, -8], [-30, -8]]); _lin(ci, c, u, [-22, -22], [10, -22], 2.2, P)
			ci.draw_polyline(_p(c, u, [[18, -18], [30, -18], [30, 8], [0, 8], [0, 34]]), T, 4.5 * u, true); _poli(ci, c, u, [[-8, 34], [8, 34], [8, 18], [-8, 18]])
		"pergaminho":
			_poli(ci, c, u, [[-24, -26], [24, -26], [24, 26], [-24, 26]], P); _contorno(ci, c, u, [[-24, -26], [24, -26], [24, 26], [-24, 26]], 3.0)
			ci.draw_circle(c + Vector2(-24, -26) * u, 7.0 * u, T); ci.draw_circle(c + Vector2(24, 26) * u, 7.0 * u, T)
			for k in range(4): _lin(ci, c, u, [-14, -14 + k * 9], [14, -14 + k * 9], 2.0)
		"urna":
			_poli(ci, c, u, [[-30, -6], [30, -6], [26, 30], [-26, 30]]); _poli(ci, c, u, [[-10, -6], [10, -6], [10, -2], [-10, -2]], P)
			_poli(ci, c, u, [[-12, -34], [12, -34], [12, -12], [-12, -12]], P); _contorno(ci, c, u, [[-12, -34], [12, -34], [12, -12], [-12, -12]], 3.0)
		"lanca":
			_lin(ci, c, u, [-32, 34], [22, -22], 4.5); _poli(ci, c, u, [[16, -16], [24, -40], [38, -26]]); _lin(ci, c, u, [-14, 16], [-4, 26], 3.0, P)
		"punho":
			_poli(ci, c, u, [[-16, -4], [16, -4], [18, 22], [-16, 22]])
			for k in range(4): _circ(ci, c, u, -12 + k * 8, -9, 7.2)
			_circ(ci, c, u, -19, 8, 7.0); _poli(ci, c, u, [[-16, 22], [18, 22], [18, 34], [-16, 34]], P); _contorno(ci, c, u, [[-16, 22], [18, 22], [18, 34], [-16, 34]], 3.0)
		"bandeira":
			_lin(ci, c, u, [-24, -36], [-24, 38], 4.5)
			_poli(ci, c, u, [[-22, -34], [30, -28], [22, -14], [30, 0], [-22, -4]]); _estrela(ci, c + Vector2(0, -18) * u, 8.0 * u, 3.4 * u, 5, P)
		"espada":
			_poli(ci, c, u, [[-6, -38], [6, -38], [6, 14], [-6, 14]], P); _contorno(ci, c, u, [[-6, -38], [6, -38], [6, 14], [-6, 14]], 3.2)
			_lin(ci, c, u, [0, -34], [0, 10], 1.6); _lin(ci, c, u, [-18, 18], [18, 18], 5.0); _lin(ci, c, u, [0, 18], [0, 34], 5.0); _circ(ci, c, u, 0, 36, 4.5)
		"sino":
			_poli(ci, c, u, [[-8, -34], [8, -34], [10, -22], [26, 14], [32, 26], [-32, 26], [-26, 14], [-10, -22]]); _circ(ci, c, u, 0, 32, 5.0)
			_lin(ci, c, u, [-16, 14], [-10, -14], 2.0, P)
		"vela":
			_poli(ci, c, u, [[-9, -4], [9, -4], [9, 34], [-9, 34]], P); _contorno(ci, c, u, [[-9, -4], [9, -4], [9, 34], [-9, 34]], 3.4)
			_poli(ci, c, u, [[0, -36], [-9, -16], [0, -8], [9, -16]]); _poli(ci, c, u, [[-18, 34], [18, 34], [14, 40], [-14, 40]])
		"pomba":
			_poli(ci, c, u, [[-34, 4], [-14, -12], [4, -14], [12, -24], [18, -14], [32, -10], [18, -4], [10, 12], [-8, 22], [-24, 24]])
			_poli(ci, c, u, [[-6, -10], [-20, -34], [4, -22]], P); _contorno(ci, c, u, [[-6, -10], [-20, -34], [4, -22]], 2.4); _circ(ci, c, u, 14, -17, 2.2, P)
		_:
			_estrela(ci, c, 36.0 * u, 16.0 * u, 8, T)
