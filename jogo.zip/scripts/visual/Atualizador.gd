extends Node
class_name Atualizador
# Atualização automática do Cordel.exe instalado. O .exe leva o jogo dentro, mas, quando há versão nova no repositório
# público (cordel-jogo), baixa um pacote pequeno (jogo.pck, uns 10 MB) pra pasta de dados do usuário e, na próxima abertura
# (ou no botão "Reiniciar agora"), roda o jogo a partir desse pacote. O .exe em si não precisa ser trocado.
#   versao.txt  (no repositório)  -> "2026.11.22.2140": o que existe de mais novo
#   jogo.pck    (no repositório)  -> o jogo inteiro dessa versão
# Segurança contra pacote ruim: antes de abrir o pacote novo grava "tentativa"; se o jogo novo não chegar a abrir, na
# abertura seguinte o pacote é descartado e o jogo volta pra versão de dentro do .exe.

const BASE := "https://raw.githubusercontent.com/diogobennertz/cordel-jogo/main"
const PCK := "user://jogo.pck"
const PCK_NOVO := "user://jogo_novo.pck"
const VERSAO_PCK := "user://jogo.versao"
const TENTATIVA := "user://tentativa"

signal mudou()
var estado := "nada"            # nada | procurando | baixando | pronto | erro
var versao_nova := ""
var _http: HTTPRequest

static func versao_atual() -> String:
	if FileAccess.file_exists("res://versao.txt"): return FileAccess.get_file_as_string("res://versao.txt").strip_edges()
	return "0"

static func versao_do_pacote() -> String:
	if FileAccess.file_exists(VERSAO_PCK) and FileAccess.file_exists(PCK): return FileAccess.get_file_as_string(VERSAO_PCK).strip_edges()
	return ""

static func ativo() -> bool:
	if DisplayServer.get_name() == "headless": return false
	var a := OS.get_cmdline_user_args()
	if a.size() > 0 and not ("--simular-instalado" in a): return false        # modos de teste do jogo
	return not OS.has_feature("editor") or ("--simular-instalado" in a)

static func rodando_de_pacote() -> bool:
	return "--main-pack" in OS.get_cmdline_args()

# chamado no começo do jogo: se há pacote novo e ainda não estamos rodando dele, abre ele e fecha este
static func relancar_se_preciso(arvore: SceneTree) -> bool:
	if not ativo(): return false
	if rodando_de_pacote():
		if FileAccess.file_exists(TENTATIVA): DirAccess.remove_absolute(ProjectSettings.globalize_path(TENTATIVA))     # o pacote novo abriu: deu certo
		return false
	if FileAccess.file_exists(TENTATIVA):                  # a tentativa anterior não completou: pacote ruim, descarta
		DirAccess.remove_absolute(ProjectSettings.globalize_path(TENTATIVA))
		if FileAccess.file_exists(PCK): DirAccess.remove_absolute(ProjectSettings.globalize_path(PCK))
		return false
	var vp := versao_do_pacote()
	if vp == "" or vp <= versao_atual(): return false
	var f := FileAccess.open(TENTATIVA, FileAccess.WRITE); if f: f.store_string(vp); f.close()
	var args := PackedStringArray(["--main-pack", ProjectSettings.globalize_path(PCK)])
	if "--simular-instalado" in OS.get_cmdline_user_args(): args.append_array(["--", "--simular-instalado"])
	var pid := OS.create_process(OS.get_executable_path(), args)
	if pid <= 0:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(TENTATIVA)); return false
	arvore.quit()
	return true

# reabre o jogo já na versão baixada (botão "Reiniciar agora")
func reiniciar() -> void:
	var f := FileAccess.open(TENTATIVA, FileAccess.WRITE); if f: f.store_string(versao_nova); f.close()
	var args := PackedStringArray(["--main-pack", ProjectSettings.globalize_path(PCK)])
	if "--simular-instalado" in OS.get_cmdline_user_args(): args.append_array(["--", "--simular-instalado"])
	if OS.create_process(OS.get_executable_path(), args) > 0: get_tree().quit()
	else: DirAccess.remove_absolute(ProjectSettings.globalize_path(TENTATIVA))

func procurar() -> void:
	print("ATUALIZADOR procurando; versão aqui=%s pacote=%s" % [versao_atual(), versao_do_pacote()])
	if not ativo(): return
	estado = "procurando"; mudou.emit()
	_http = HTTPRequest.new(); _http.timeout = 10.0; add_child(_http)
	_configurar_rede(_http)
	_http.request_completed.connect(_versao_chegou)
	if _http.request(BASE + "/versao.txt") != OK: estado = "nada"; mudou.emit()

# Em computador de casa não faz nada. Em rede com proxy (empresa, ambientes de teste) usa HTTPS_PROXY e o certificado indicado.
func _configurar_rede(h: HTTPRequest) -> void:
	var px := OS.get_environment("HTTPS_PROXY")
	if px.begins_with("http://") and px.find("@") < 0:
		var hp := px.substr(7).trim_suffix("/").split(":")
		if hp.size() == 2 and hp[1].is_valid_int(): h.set_https_proxy(hp[0], int(hp[1]))
	var ca := OS.get_environment("SSL_CERT_FILE")
	if ca != "" and FileAccess.file_exists(ca):
		var cert := X509Certificate.new()
		if cert.load(ca) == OK: h.set_tls_options(TLSOptions.client(cert))

func _versao_chegou(res: int, code: int, _h: PackedStringArray, corpo: PackedByteArray) -> void:
	_http.request_completed.disconnect(_versao_chegou)
	print("ATUALIZADOR resposta versao: res=%d code=%d" % [res, code])
	if res != HTTPRequest.RESULT_SUCCESS or code != 200: estado = "nada"; mudou.emit(); return
	var remota := corpo.get_string_from_utf8().strip_edges()
	if remota == "" or remota.length() > 30: estado = "nada"; mudou.emit(); return
	var local := versao_atual()
	var vp := versao_do_pacote()
	if remota <= local or remota <= vp:
		estado = "pronto" if (vp != "" and vp > local and not rodando_de_pacote()) else "nada"
		versao_nova = vp; mudou.emit(); return
	versao_nova = remota; estado = "baixando"; mudou.emit()
	_http.timeout = 900.0                       # o pacote tem ~10 MB: o limite de 10 s era só pra consultar a versão
	_http.download_file = ProjectSettings.globalize_path(PCK_NOVO)
	_http.request_completed.connect(_pacote_chegou)
	if _http.request(BASE + "/jogo.pck") != OK: estado = "erro"; mudou.emit()

func _pacote_chegou(res: int, code: int, _h: PackedStringArray, _c: PackedByteArray) -> void:
	_http.request_completed.disconnect(_pacote_chegou)
	print("ATUALIZADOR pacote: res=%d code=%d" % [res, code])
	var caminho := ProjectSettings.globalize_path(PCK_NOVO)
	var ok := res == HTTPRequest.RESULT_SUCCESS and code == 200 and FileAccess.file_exists(PCK_NOVO)
	if ok:
		var f := FileAccess.open(PCK_NOVO, FileAccess.READ); ok = f != null and f.get_length() > 1000000; if f: f.close()
	if not ok:
		if FileAccess.file_exists(PCK_NOVO): DirAccess.remove_absolute(caminho)
		estado = "erro"; mudou.emit(); return
	if FileAccess.file_exists(PCK): DirAccess.remove_absolute(ProjectSettings.globalize_path(PCK))
	DirAccess.rename_absolute(caminho, ProjectSettings.globalize_path(PCK))
	var fv := FileAccess.open(VERSAO_PCK, FileAccess.WRITE); fv.store_string(versao_nova); fv.close()
	estado = "pronto"; mudou.emit()

func progresso() -> float:
	if _http == null or estado != "baixando": return 0.0
	var tot := _http.get_body_size()
	return float(_http.get_downloaded_bytes()) / float(tot) if tot > 0 else 0.0
