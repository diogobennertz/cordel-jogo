extends RefCounted
class_name Paleta
# A paleta do Cordel (tinta de gráfica popular). Tudo que é cor chapada no mundo 3D passa por aqui:
# `snap()` puxa qualquer cor que o código antigo pediu para a mais próxima da paleta — assim os 41 bonecos,
# as árvores e o cenário ficam na mesma família sem precisar mexer em cada linha.

const TINTA := Color("201A17")
const PAPEL := Color("E8D7AE")
const VERMELHO := Color("A83226")
const AMARELO := Color("D69A32")
const VERDE := Color("456747")
const AZUL := Color("31566B")
const TERRA := Color("874C35")
const PALHA := Color("B8A47A")
const CREME := Color("F0E9D7")
const VINHO := Color("6F2924")

# variações de cada cor-base (claro/escuro), pra manter leitura de volume
const VERDE_ESC := Color("2E4833")
const VERDE_CL := Color("6F8B57")
const AZUL_CL := Color("5E8597")
const TERRA_CL := Color("B26C47")
const TERRA_ESC := Color("5C3526")
const AMARELO_CL := Color("E9C463")
const VERMELHO_CL := Color("CC5640")
const ROSA := Color("CF7387")        # festa junina / fita
const ROXO := Color("68496F")        # quaresmeira
const PELE_CL := Color("D9A57A")
const PELE_MD := Color("A8714A")
const PELE_ESC := Color("6B4630")
const PEDRA := Color("857A6C")

const TODAS := [TINTA, PAPEL, VERMELHO, AMARELO, VERDE, AZUL, TERRA, PALHA, CREME, VINHO,
	VERDE_ESC, VERDE_CL, AZUL_CL, TERRA_CL, TERRA_ESC, AMARELO_CL, VERMELHO_CL, ROSA, ROXO,
	PELE_CL, PELE_MD, PELE_ESC, PEDRA]

static var _cache := {}

# cor mais próxima da paleta (distância em RGB com peso de luminosidade; a tinta só ganha de cores bem escuras)
static func snap(c: Color) -> Color:
	var k := c.to_rgba32()
	if _cache.has(k): return _cache[k]
	var melhor: Color = TODAS[0]
	var dmin := 1e9
	for p in TODAS:
		var dr: float = c.r - p.r; var dg: float = c.g - p.g; var db: float = c.b - p.b
		var d: float = dr * dr * 0.9 + dg * dg * 1.2 + db * db * 0.9
		# penaliza trocar de matiz de forma muito diferente da luminosidade
		d += absf(c.get_luminance() - p.get_luminance()) * 0.35
		if d < dmin: dmin = d; melhor = p
	_cache[k] = melhor
	return melhor
