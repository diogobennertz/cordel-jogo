extends Control
class_name MiniMapa
# Minimapa redondo: a clareira inteira, girando junto com a câmera (para cima = para onde você olha).
# Só ícone, sem nome escrito: com nome escrito polui e não dá pra ler de relance.

var w
var _n := 0

func _process(_d: float) -> void:
	_n += 1
	if _n % 3 == 0 and is_visible_in_tree(): queue_redraw()

func _p(x: float, z: float, r: float) -> Vector2:
	var v: Vector2 = Vector2(x, z).rotated(w.cam_yaw) / (float(w.ARENA) + 2.0) * r
	return size * 0.5 + v

# borda de carimbo de xilogravura (não um círculo geométrico perfeito — entalhe irregular na faca)
func _pontos_irregular(c: Vector2, raio: float, segmentos: int = 40) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in range(segmentos):
		var a := i * TAU / segmentos
		var borda := raio * (1.0 + 0.045 * sin(a * 5.0 + 1.0) + 0.025 * sin(a * 11.0))
		pts.append(c + Vector2(cos(a), sin(a)) * borda)
	return pts

func _draw() -> void:
	if w == null or w.player == null: return
	var c := size * 0.5; var r := size.x * 0.5 - 3.0
	draw_colored_polygon(_pontos_irregular(c + Vector2(4, 4), r + 3.0), Tela.TINTA)   # sombra de tinta chapada
	draw_colored_polygon(_pontos_irregular(c, r + 3.0), Tela.PAPEL)
	var pts_chapa := _pontos_irregular(c, r)
	draw_colored_polygon(pts_chapa, Color(0.22, 0.17, 0.13))                     # chapa escura do mapa
	var fechado := pts_chapa.duplicate(); fechado.append(pts_chapa[0])
	draw_polyline(fechado, Tela.TINTA, 4.0, true)                                # filete de gravura na borda irregular
	draw_arc(c, r - 5.0, 0, TAU, 48, Color(Tela.PAPEL, 0.55), 1.4, true)
	for k in range(4):                                                           # marcas dos pontos cardeais
		var a := k * PI / 2.0
		draw_line(c + Vector2(cos(a), sin(a)) * (r - 11.0), c + Vector2(cos(a), sin(a)) * (r - 2.0), Tela.PAPEL, 2.5)
	var n := 0
	for e in w.enemies:
		if not is_instance_valid(e): continue
		n += 1
		if n > 140 and not e.is_boss: continue
		if e.is_boss: draw_circle(_p(e.position.x, e.position.z, r), 7.0, Color(1.0, 0.2, 0.6))
		elif e.elite: draw_circle(_p(e.position.x, e.position.z, r), 4.2, Color(1.0, 0.85, 0.2))
		else: draw_circle(_p(e.position.x, e.position.z, r), 2.2, Color(0.95, 0.3, 0.2))
	var esc := size.x / 194.0   # ícones crescem junto quando o mapa aumenta
	for o in w.objetos:
		var p: Vector2 = _p(o["no"].position.x, o["no"].position.z, r)
		var k := 6.0 * esc
		match o["tipo"]:
			"bau": _icone(p, k, Color(1.0, 0.85, 0.3), 0)                              # quadrado dourado
			"oratorio":
				if not o["usado"]: _icone(p, k, Color(0.55, 0.85, 1.0), 1)             # losango azul
			"loja": _icone(p, k * 1.2, Color(1.0, 0.55, 0.15), 2)                       # triângulo laranja
			"portal": draw_circle(p, k * 0.85, Color(0.75, 0.4, 1.0))                   # bolinha roxa
			_:
				if Dados.NPCS.has(o["tipo"]): _icone(p, k, Color.WHITE, 1)             # losango branco (gente)
	var pp: Vector3 = w.player.position
	var pj := _p(pp.x, pp.z, r)
	draw_circle(pj, 5.5 * esc, Tela.TINTA); draw_circle(pj, 3.8 * esc, Color.WHITE)
	var seta: Vector2 = Vector2(0, -1)
	draw_line(pj, pj + seta * (9.0 * esc), Color.WHITE, 2.5 * esc)

# ícone com contorno escuro, pra não sumir em cima do verde: 0 quadrado, 1 losango, 2 triângulo
func _icone(p: Vector2, k: float, cor: Color, forma: int) -> void:
	var pts: PackedVector2Array
	match forma:
		1: pts = PackedVector2Array([p + Vector2(0, -k), p + Vector2(k, 0), p + Vector2(0, k), p + Vector2(-k, 0)])
		2: pts = PackedVector2Array([p + Vector2(0, -k), p + Vector2(k * 0.9, k * 0.8), p + Vector2(-k * 0.9, k * 0.8)])
		_: pts = PackedVector2Array([p + Vector2(-k, -k), p + Vector2(k, -k), p + Vector2(k, k), p + Vector2(-k, k)])
	draw_colored_polygon(pts, cor)
	var fechado: PackedVector2Array = pts.duplicate(); fechado.append(pts[0])
	draw_polyline(fechado, Tela.TINTA, 1.4, true)
