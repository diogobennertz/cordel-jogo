extends Node3D
# Mundo 3D low-poly em terceira pessoa (câmera atrás do herói), com as 4 classes e seus golpes.

const ARENA := Lib.RAIO
const SPAWN_RAIO := 22.0

var estado := "menu"         # menu | jogo | fim
var levelup_aberto := false     # há uma tela de escolha (carta, loja, pausa) aberta PARA MIM
var pausa_equipe := false       # co-op: o anfitrião parou o jogo pra todo mundo (rodada de cartas)
var equipe_nivel := 1           # co-op: nível, XP e meta são da EQUIPE (o anfitrião manda; todo mundo vê o mesmo)
var equipe_xp := 0.0
var equipe_xp_next := 8.0
var _rodadas: Array = []        # (anfitrião) fila de rodadas de carta: [{"tipos": {peer_id: tipo}}]
var _rodada_pend: Dictionary = {}   # (anfitrião) quem ainda não escolheu na rodada atual
var _rodada_ativa := false
var _fora: Dictionary = {}      # (anfitrião) quem já caiu: não é mais chamado pra escolher carta
var _coop_teste := false        # os testes automáticos escolhem a carta sozinhos
var _sync_t := 0.0

var player: Jogador
var camera: Camera3D
var cam_dist := 12.0
var cam_yaw := 0.0
var cam_pitch := 0.56
var cam_fixa := false
var oclusores: Array = []    # [nó, x, z, raio] — árvores que somem quando tapam a câmera
var troncos: Array = []      # Vector3(x, z, raio) — o herói não atravessa
var enemies: Array = []
var fireflies: Array = []
var _xp_combo := 0              # coletas seguidas sem pausa: sobe o tom (escala pentatônica) a cada uma
var _xp_combo_t := 0.0
const XP_ESCALA := [1.0, 1.125, 1.25, 1.5, 1.6875, 1.875, 2.0, 2.25]   # pentatônica subindo (berimbau/viola)
var projectiles: Array = []  # [{node, vel:Vector3, raio, dmg, pierce, vida, homing, boom, cor, hits:{}}]

var time := 0.0
var _marco_visto := 0   # avisos de ritmo no meio da partida ("a mata esquenta", etc.) — só pra dar a sensação de que o tempo passa
var spawn_t := 0.0
var elite_t := 10.0
# evento de tensão macro (cerco da mata): a cada 3-5min, aviso + horda fechando em anel + recompensa garantida
# ao sobreviver — pico de adrenalina de vez em quando, não só a trilha normal de bichos (pedido de game design)
var _evento_t := 0.0
var _evento_fase := 0           # 0 parado, 1 aviso, 2 cerco ativo, 3 recompensa já dada
var _evento_tempo := 0.0
var _evento_inimigos: Array = []
var kills := 0
# fase: 10 minutos, chefe, 3 minutos para vencer, depois infinito
var fase := 0
var chefe_t := Dados.CHEFE_T
var chefe: Inimigo = null
var chefe_veio := false
var chefe_morto := false
var furia := false
var furia_t := Dados.FURIA_T
var extra_t := 0.0             # tempo sobrevivido depois do chefe
var moedas := 0.0
var dano_total := 0.0
var maior_dano := 0.0
var _dps_janela := []       # [[tempo, dano], ...] do último segundo, pra mostrar dano por segundo
var lbl_dps: Label
var menus: Menus
var moldura: Panel            # borda vermelha: pisca ao levar dano e pulsa com a vida baixa
var _moldura_a := 0.0
var tremor := 0.0              # tremor da câmera (pancada forte, pisão do chefe)
var combo := 0                 # sequência de abates
var combo_t := 0.0
var objetos: Array = []        # potes, baús e oratórios espalhados pela fase
var bau_custo := 15
var _pote_t := 20.0
var loja_precos := {}
var pacto_feito := false
var npc_feito := {}            # ofertas de uma vez só já aceitas (Seu Zé, Pomba Gira)
var praga := 1.0               # Abre-Caminho: a bicharada fica mais forte
var _pombas: Array = []
var _pomba_a := 0.0
var _pomba_t := 0.0
var tut := -1                  # passo do tutorial (-1 = partida normal)
var tut_t := 0.0
var _tut_a := 0.0
var _tut_pos := Vector3.ZERO
var painel_tut: PanelContainer
var lbl_tut: Label
var poder := ""                # poder temporário ativo (ver Dados.PODERES)
var poder_t := 0.0
var _poder_tick := 0.0
var _boneco_seu: Boneco        # o boneco do herói, guardado enquanto ele está "virado" em outra coisa
var _fogos: Array = []         # rastro de fogo da Mula sem Cabeça
var _fila: Array = []          # escolhas de carta esperando a vez (nível, baú, oratório)
var _vida_lag := 1.0
var lbl_nv: Label
var lbl_dir: Label
var lbl_combo: Label
var lbl_nome: Label
var barra_lag: ColorRect
var retrato: Panel
var caixa_slots: HBoxContainer
var _slots: Array = []
var caixa_inv: HFlowContainer   # mini inventário: as cartas de atributo pegas
var _inv_n := -1
var minimapa: MiniMapa
var jogadores_rede := {}       # peer_id -> Jogador (só usado no co-op)
var enemies_por_net_id := {}   # net_id -> Inimigo (bicho replicado pela rede)
var _proximo_net_id := 0
var objetos_por_net_id := {}   # net_id -> objeto do mapa (pote/baú/oratório/loja/portal/gente), replicado no co-op
var _proximo_net_id_objeto := 0
var painel_info: PanelContainer
var caixa_placar: HBoxContainer
var papel_cl: CanvasLayer
var _start_ant := false
var tiros: Array = []          # bolas de fogo dos chefes
var sel_heroi := "capoeirista"
var sel_fase := 0
var _nomes_galeria := ["frevista", "cordelista", "capoeirista", "jiujitsu", "benzedeira", "cangaceiro", "sambista", "maracatuzeiro", "violeiro", "carimbozeiro"]
var _bot_lim := 300.0
var _env: Environment
var _psm: ShaderMaterial
var _sol: DirectionalLight3D
var lbl_sub: Label
var lbl_hab: Label
var barra_chefe_bg: ColorRect
var barra_chefe: ColorRect
const FOGO_ULT := {"tipo": "proj_teleguiado", "raio": 0.5, "vida": 3.0, "boom": 1.8, "cor": Color(0.31, 0.72, 0.95)}
const BALA_ULT := {"tipo": "proj_reto", "raio": 0.35, "vida": 0.9, "pierce": 1, "cor": Color(0.94, 0.71, 0.1)}
const TIRO_Q := {"tipo": "proj_reto", "raio": 0.5, "vida": 1.1, "pierce": 99, "crit": 1.0, "cor": Color(1.0, 0.85, 0.2)}

# UI
var hud: CanvasLayer
var lbl_topo: Label
var lbl_vida: Label
var lbl_centro: Label
var barra_vida: ColorRect
var barra_xp: ColorRect
var fogo: Node3D
var _nums := 0

var atualizador: Atualizador
var _faixa_up: PanelContainer

func _ready() -> void:
	if Atualizador.relancar_se_preciso(get_tree()):      # há versão nova já baixada: abre ela e fecha esta
		set_process(false); set_process_input(false); set_process_unhandled_input(false); return
	get_tree().root.close_requested.connect(func(): Input.mouse_mode = Input.MOUSE_MODE_VISIBLE)
	randomize()
	var a0 := OS.get_cmdline_user_args()
	Salvo.desligado = a0.size() > 0          # qualquer modo de teste: não mexe no save do jogador
	Salvo.carregar()
	Gravador.ligado = not ("--sem-papel" in a0)      # só pra depuração: sem isso o jogo mostra os 3D de reserva
	get_tree().root.theme = Tela.tema()
	Tela.aplicar_opcoes()
	cam_dist = Tela.opc("camera")
	menus = Menus.new(); menus.w = self; add_child(menus)
	Som.ligar(self)
	papel_cl = Materiais.camada_papel(self)
	if "--melhorias" in a0:
		for hid in Dados.CLASSES:
			Salvo.d["melhorias"][hid] = {}
			for mid in Dados.MELHORIAS: Salvo.d["melhorias"][hid][mid] = mini(int(a0[a0.find("--melhorias") + 1]), int(Dados.MELHORIAS[mid]["max"]))
	if "--chefe-em" in a0: chefe_t = float(a0[a0.find("--chefe-em") + 1])
	if "--tempo" in a0: _bot_lim = float(a0[a0.find("--tempo") + 1])
	if "--fase" in a0: sel_fase = int(a0[a0.find("--fase") + 1]) - 1
	Gravador.construtores["planta"] = _gravar_planta
	Gravador.construtores["muralha"] = _gravar_muralha
	Gravador.construtores["cenario"] = _gravar_cenario
	_montar_ceu()
	_montar_chao()
	_montar_mata()
	_montar_vilarejo()
	_montar_serras()
	_montar_muralha()
	_montar_capim()
	_montar_agua()
	_montar_nuvens()
	_montar_arraial()
	_montar_camera()
	_montar_hud()
	Rede.partida_comecou.connect(iniciar_coop)
	if Atualizador.ativo():
		atualizador = Atualizador.new(); add_child(atualizador); atualizador.mudou.connect(_faixa_atualizacao)
		atualizador.procurar.call_deferred()
	_seguir_camera(1.0)
	var args := OS.get_cmdline_user_args()
	if "--shot" in args:
		_shot_debug(args[args.find("--shot") + 1] if args.find("--shot") + 1 < args.size() else "cangaceiro")
	elif "--shot-arena" in args:        # visão geral da arena no início, sem horda — auditoria de arte
		_shot_arena(args[args.find("--shot-arena") + 1] if args.find("--shot-arena") + 1 < args.size() else "capoeirista")
	elif "--shot-cerco" in args:        # depuração: dispara o evento de cerco na hora, sem esperar 3min de verdade
		_shot_cerco(args[args.find("--shot-cerco") + 1] if args.find("--shot-cerco") + 1 < args.size() else "capoeirista")
	elif "--bot" in args:
		_bot(args[args.find("--bot") + 1] if args.find("--bot") + 1 < args.size() else "capoeirista")
	elif "--teste-dash" in args:
		_teste_dash()
	elif "--teste-mundo" in args:
		_teste_mundo()
	elif "--teste-lock" in args:
		_teste_lock()
	elif "--coop-host" in args:
		_teste_coop_host()
	elif "--coop-join" in args:
		_teste_coop_join(args[args.find("--coop-join") + 1])
	elif "--aura" in args:
		sem_mouse = true; iniciar_jogo("cangaceiro", int(args[args.find("--aura") + 1]) - 1 if args.find("--aura") + 1 < args.size() else 0)
		player.max_hp = 1e6; player.hp = 1e6
		var f: Dictionary = Dados.FASES[fase]
		var ch := _nascer(f["chefe"], 1.0, {"mapinguari": 2.6, "mula": 2.1, "boitata": 2.0, "cuca": 1.8, "minhocao": 3.4}.get(f["chefe"], 2.1), null, true)
		ch.position = player.global_position + Vector3(0, 0, 14.0); ch.hp = 1e5; ch.max_hp_cache = 1e5
		for i in range(7):
			_nascer("saci" if i % 2 == 0 else "caipora", 1.0, 1.0, null, false); enemies[-1].position = player.global_position + Vector3(cos(i * 0.9) * 4.0, 0, sin(i * 0.9) * 4.0); enemies[-1].hp = 9999
		await get_tree().process_frame
		while not Gravador.ocioso(): await get_tree().process_frame
		await get_tree().create_timer(1.2).timeout
		riscos_movimento(player.global_position + Vector3(0, 0, 1.5), Vector3(0, 0, -1))
		impacto_gravado(player.global_position + Vector3(2.2, 0.5, 4), 0); impacto_gravado(player.global_position + Vector3(-2.2, 0.5, 5), 1); impacto_gravado(player.global_position + Vector3(0.4, 0.5, 7), 1)
		await get_tree().create_timer(0.14).timeout
		get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://shot_aura.png")); get_tree().quit()
	elif "--teste-f11" in args:
		for i in range(3):
			await get_tree().create_timer(0.6).timeout
			var ev := InputEventKey.new(); ev.physical_keycode = KEY_F11; ev.pressed = true
			Input.parse_input_event(ev)
			await get_tree().create_timer(0.4).timeout
			print("F11 #%d: opcao cheia=%s modo_janela=%d (0=janela, 3/4=tela cheia)" % [i + 1, str(Tela.opc("cheia")), DisplayServer.window_get_mode()])
		get_tree().quit()
	elif "--folha" in args:
		_folha()
	elif "--borda" in args:
		_borda()
	elif "--menu" in args:
		sem_mouse = true; _montar_menu(); _salvar("shot_menu")
	elif "--tela" in args:
		if "--idioma" in args: TranslationServer.set_locale(args[args.find("--idioma") + 1])
		_shot_tela(args[args.find("--tela") + 1])
	elif "--chefe" in args:
		_shot_chefe()
	elif "--galeria" in args:
		_galeria()
	elif "--galeria2" in args:
		_nomes_galeria = ["forrozeiro", "angoleiro", "marujo", "jongueira", "chorao", "ceramista", "cantora", "pintor", "maestro"]
		_galeria()
	elif "--galeria3" in args:
		_nomes_galeria = ["violonista", "bimba", "escultor", "aviador", "escritor", "sertanista", "cangaceiro_chefe", "cangaceira", "muralista", "orador"]
		_galeria()
	elif "--galeria4" in args:
		_nomes_galeria = ["quilombola", "martir", "santa"]
		_galeria()
	elif "--teste" in args:
		_teste(args[args.find("--teste") + 1] if args.find("--teste") + 1 < args.size() else "capoeirista")
	elif "--teste-ritmo" in args:
		_teste_ritmo()
	else:
		_montar_menu()

# auto-teste sem clique: escolhe a classe, equipa todos os golpes da build e exercita por 6s.
var _teste_fim := 0.0
func _teste(cls: String) -> void:
	iniciar_jogo(cls, sel_fase)
	player.max_hp = 1e9; player.hp = 1e9   # herói de teste não morre
	player.ult = 1.0; usar_especial(player); usar_ultimate(player)
	for id in Dados.CLASSES[cls]["desbloqueia"]:
		player.aplicar_carta({"tipo": "golpe_novo", "id": id})
	for i in range(24):
		var a := i * TAU / 24.0
		_nascer("caipora" if i % 2 == 0 else "saci", 2.0, 1.0, null, false)
		enemies[-1].position = player.global_position + Vector3(cos(a) * (2.0 + i % 4), 0, sin(a) * (2.0 + i % 4))
	_teste_fim = 1.0

# robô que joga uma partida inteira (vida normal, pega cartas sozinho) e conta até onde foi
var _dano_tomado := 0.0
var _ze_n := 0
var _poder_teste := ""
var _poder_n := 0
var _dano_pombas := 0.0
func _bot(cls: String) -> void:
	var a := OS.get_cmdline_user_args()
	iniciar_jogo(cls, sel_fase, "--tut" in a)
	player.bot = true
	_teste_fim = 2.0
	if "--extras" in a:          # liga o que o robô não compra sozinho, para conferir que funciona
		player.pombas = 3; player.segunda_chance = true; player.pulos_extra += 1
	if "--poder" in a: _poder_teste = a[a.find("--poder") + 1]

func bot_dir() -> Vector3:
	var pp: Vector3 = player.global_position
	var quer: float = {"capoeirista": 2.2, "cangaceiro": 2.0 if player.golpes.size() < 2 else 5.0, "jiujitsu": 5.0, "benzedeira": 10.0, "frevista": 2.4, "cordelista": 9.0,
		"sambista": 2.3, "maracatuzeiro": 5.0, "violeiro": 9.5, "carimbozeiro": 2.3,
		"forrozeiro": 2.3, "angoleiro": 5.0, "marujo": 9.5,
		"jongueira": 2.3, "chorao": 9.5, "ceramista": 9.5, "cantora": 2.3,
		"pintor": 9.5, "maestro": 2.3, "violonista": 9.5, "bimba": 5.0,
		"escultor": 2.3, "aviador": 2.3, "escritor": 9.5, "sertanista": 2.3,
		"cangaceiro_chefe": 9.5, "cangaceira": 2.3, "muralista": 9.5, "orador": 9.5,
		"quilombola": 5.0, "martir": 2.3, "santa": 10.0}[player.classe]
	if player.hp < player.max_hp * 0.35: quer += 5.0
	var dir := Vector3.ZERO
	var alvo = _nearest(pp, 80.0)
	if alvo:
		var dd: Vector3 = alvo.global_position - pp; dd.y = 0
		var l := dd.length()
		if l > quer + 0.6: dir = dd / maxf(l, 0.01)
		elif l > quer - 0.6: dir = (dd / maxf(l, 0.01)).cross(Vector3.UP)
		else: dir = -dd / maxf(l, 0.01) + (dd / maxf(l, 0.01)).cross(Vector3.UP) * 0.6
	# XP perto vale um desvio
	for fr in fireflies:
		var t: Vector3 = fr["node"].global_position - pp; t.y = 0
		if t.length() < 6.0 and t.length() > 0.1: dir += t.normalized() * 0.8; break
	var centro := Vector3(-pp.x, 0, -pp.z)
	if centro.length() > ARENA * 0.75: dir += centro.normalized() * 1.5
	return dir.normalized() if dir.length() > 0.1 else Vector3.ZERO

func _bot_fim(motivo: String) -> void:
	var gs := ""
	for g in player.golpes: gs += "%s%d " % [g["id"], g["nivel"]]
	var ch := "chefe não veio"
	if chefe_morto: ch = "CHEFE MORTO, extra %s" % _mmss(extra_t)
	elif chefe_veio: ch = "chefe vivo com %d%% (%s)" % [int(100.0 * chefe.hp / chefe.max_hp_cache) if is_instance_valid(chefe) else 0, "em fúria" if furia else "sem fúria"]
	print("BOT %s fase %d %s em %s — nivel:%d abates:%d vida:%d/%d moedas:%d %s golpes: %s crit:%d%% x%.1f maior:%s total:%s" % [player.classe, fase + 1, motivo, _mmss(time), player.level, kills, player.hp, player.max_hp, int(moedas), ch, gs, int(player.crit * 100), player.crit_dano, Tela.num(maior_dano), Tela.num(dano_total)] + (" | seu-zé segurou:%d pombas:%d dano-das-pombas:%s objetos:%d poderes:%d vel:%.2f atq:%.2f xpm:%.2f" % [_ze_n, _pombas.size(), Tela.num(_dano_pombas), objetos.size(), _poder_n, player.speed, player.atk_speed, player.xp_mult]))
	get_tree().quit()

func _teste_tick() -> void:
	if _poder_teste != "" and poder == "" and time > 5.0:      # robô: fica ganhando poderes para conferir que entram e saem direito
		_poder_n += 1
		dar_poder(Dados.PODERES.keys()[_poder_n % Dados.PODERES.size()] if _poder_teste == "todos" else _poder_teste)
	if _teste_fim == 2.0:
		if time > _bot_lim: _bot_fim("VIVO")
		return
	if _teste_fim > 0.0 and time > 6.0:
		print("TESTE %s OK — golpes:%d abates:%d projeteis:%d nivel:%d vida:%d/%d" % [player.classe, player.golpes.size(), kills, projectiles.size(), player.level, player.hp, player.max_hp])
		get_tree().quit()

# ---------------- cenário ----------------
func _montar_ceu() -> void:
	var env := Environment.new(); _env = env
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new(); _psm = Materiais.ceu()
	sky.sky_material = _psm; env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.74, 0.66, 0.58); env.ambient_light_energy = 0.30   # sol duro do sertão: menos luz de enchimento geral, mais contraste de sombra
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	env.fog_enabled = true; env.fog_light_color = Paleta.PAPEL; env.fog_light_energy = 1.0; env.fog_density = 0.0028; env.fog_sky_affect = 0.0
	env.glow_enabled = false; env.ssao_enabled = false
	var we := WorldEnvironment.new(); we.environment = env; add_child(we)
	var sol := DirectionalLight3D.new(); _sol = sol
	sol.rotation_degrees = Vector3(-48, -35, 0)
	sol.light_color = Color(1.0, 0.94, 0.8); sol.light_energy = 1.15
	sol.shadow_enabled = true; sol.directional_shadow_max_distance = 70.0; sol.shadow_blur = 0.35   # sombra mais nítida (gravura, não degradê)
	add_child(sol)
	_ceu(Color(0.19, 0.34, 0.42), Paleta.PAPEL, Color(0.53, 0.30, 0.21), Paleta.AMARELO, true)
	_atualizar_sol()

# céu de papel: faixas chapadas do topo ao horizonte, e o sol gravado
func _ceu(topo: Color, horizonte: Color, chao: Color, cor_sol: Color, sol_visivel: bool) -> void:
	_psm.set_shader_parameter("topo", topo); _psm.set_shader_parameter("horizonte", horizonte)
	_psm.set_shader_parameter("chao", chao); _psm.set_shader_parameter("cor_sol", cor_sol)
	_psm.set_shader_parameter("sol_visivel", 1.0 if sol_visivel else 0.0)

# o sol do shader (hachura, céu) acompanha a luz direcional
func _atualizar_sol() -> void:
	var para_o_sol := _sol.global_transform.basis.z
	Materiais.definir_sol(para_o_sol)
	_psm.set_shader_parameter("dir_sol", para_o_sol)

func _cor_chao(p: Vector3, rng: RandomNumberGenerator) -> Color:
	# papel do sertão: o chão é papel claro; só manchas de terracota e riscos de tinta (vêm do shader) — como gravura impressa
	var campo := sin(p.x * 0.21 + 1.0) * cos(p.z * 0.17) + 0.6 * sin((p.x + p.z) * 0.07) + (rng.randf() - 0.5) * 0.55
	var c: Color = Paleta.CREME
	if campo > 0.55: c = Paleta.PAPEL
	elif campo < -0.5: c = Paleta.TERRA_CL
	if sin(p.x * 0.13 + 2.0) * sin(p.z * 0.11) > 0.86: c = Paleta.TERRA_CL      # clareira de terra
	if p.y > 4.0: c = Paleta.TERRA
	if p.y < -1.1: c = Paleta.PAPEL                                              # areia na beira da água
	return c

func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, rng: RandomNumberGenerator) -> void:
	var n := (b - a).cross(c - a).normalized()
	if n.y < 0.0: n = -n
	var cor := _cor_chao((a + b + c) / 3.0, rng)
	for v in [a, b, c]:
		st.set_normal(n); st.set_color(cor); st.add_vertex(v)

func _montar_chao() -> void:
	var st := SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng := RandomNumberGenerator.new(); rng.seed = 7
	var L := ARENA + 34.0; var c := 2.5; var n := int(L * 2.0 / c)
	for i in range(n):
		for j in range(n):
			var x0 := -L + i * c; var z0 := -L + j * c
			var a := Vector3(x0, Lib.h(x0, z0), z0)
			var b := Vector3(x0 + c, Lib.h(x0 + c, z0), z0)
			var d := Vector3(x0 + c, Lib.h(x0 + c, z0 + c), z0 + c)
			var e := Vector3(x0, Lib.h(x0, z0 + c), z0 + c)
			_tri(st, a, b, d, rng); _tri(st, a, d, e, rng)
	var mesh := MeshInstance3D.new(); mesh.mesh = st.commit()
	mesh.material_override = Materiais.chao()
	add_child(mesh)

# Mata: árvores, ipês, palmeiras, moitas e pedras espalhadas (sempre iguais: semente fixa).
func _montar_mata() -> void:
	var rng := RandomNumberGenerator.new(); rng.seed = 2026
	var L := ARENA
	for i in range(190):
		var x := rng.randf_range(-L, L); var z := rng.randf_range(-L, L)
		if Vector2(x, z).length() < 11.0 or Vector2(x, z).length() > ARENA - 2.0 or Lib.h(x, z) < -1.2: continue
		var r := rng.randf()
		var tipo := 0
		if r < 0.24: tipo = 0
		elif r < 0.29: tipo = 1
		elif r < 0.33: tipo = 2
		elif r < 0.40: tipo = 3
		elif r < 0.50: tipo = 4
		elif r < 0.57: tipo = 5
		elif r < 0.62: tipo = 6
		elif r < 0.78: tipo = 7      # mandacaru
		elif r < 0.89: tipo = 8      # xique-xique
		else: tipo = 9               # juazeiro retorcido
		_planta(Vector3(x, Lib.h(x, z) - 0.05, z), tipo, rng)

# raios de colisão (tronco) e de oclusão (some se tapar a câmera) de cada tipo de planta, em escala 1
const PLANTA_COL := {0: [0.35, 1.9], 1: [0.35, 1.9], 2: [0.35, 1.9], 3: [0.22, 1.6], 5: [0.7, 0.0], 6: [0.25, 1.5], 7: [0.3, 0.0], 9: [0.3, 1.8]}

func _planta(pos: Vector3, tipo: int, rng: RandomNumberGenerator) -> void:
	var rot := rng.randf() * TAU
	var s := 0.85 + rng.randf() * 0.75
	var n: Node3D
	Lib.contorno_mundo = 0.05          # todo elemento de cenário ganha contorno de tinta
	if Gravador.disponivel():
		# figura de papel: o 3D só serve de matriz pro Gravador. Monta e descarta aqui só pra manter o sorteio idêntico.
		var tmp := Node3D.new(); _planta_montar(tmp, tipo, rng); tmp.free()
		n = Cartao.novo("@planta:%d:%d" % [tipo, rng.randi() % 3])
	else:
		n = Node3D.new(); n.rotation.y = rot
		_planta_montar(n, tipo, rng); rng.randi()
	Lib.contorno_mundo = 0.0
	n.position = pos; n.scale = Vector3(s, s, s); add_child(n)
	if PLANTA_COL.has(tipo):
		var col: Array = PLANTA_COL[tipo]
		troncos.append(Vector3(pos.x, pos.z, float(col[0]) * s))
		if float(col[1]) > 0.0: oclusores.append([n, pos.x, pos.z, float(col[1]) * s])

# o Gravador pede: monta a planta `args[0]` (variante `args[1]`) pra tirar a gravura
func _gravar_planta(args: Array) -> Node3D:
	var n := Node3D.new()
	var r := RandomNumberGenerator.new(); r.seed = int(args[0]) * 100 + int(args[1])
	Lib.contorno_mundo = 0.05
	_planta_montar(n, int(args[0]), r)
	Lib.contorno_mundo = 0.0
	return n

# árvore da mata de fundo (a muralha escura em volta da clareira), variante args[0]
func _gravar_muralha(args: Array) -> Node3D:
	var t := Node3D.new()
	var r := RandomNumberGenerator.new(); r.seed = 700 + int(args[0])
	var verdes := [Paleta.VERDE_ESC, Paleta.TINTA, Paleta.VERDE_ESC, Paleta.VERDE]
	var alt := 8.0 + r.randf() * 2.5
	Lib.contorno_mundo = 0.07
	Lib.cil(t, 0.35, 0.62, alt, Vector3(0, alt * 0.5, 0), Paleta.TERRA_ESC, 6)
	Lib.esf(t, 3.3, Vector3(0, alt + 0.6, 0), verdes[r.randi() % 4], Vector3(1, 0.62, 1), 6)
	Lib.esf(t, 2.4, Vector3(1.7, alt - 0.9, 0.6), verdes[r.randi() % 4], Vector3(1, 0.62, 1), 6)
	Lib.esf(t, 2.2, Vector3(-1.6, alt - 1.5, -0.4), verdes[r.randi() % 4], Vector3(1, 0.62, 1), 6)
	Lib.contorno_mundo = 0.0
	return t

# monta o 3D de uma planta em `n` (escala 1, sem registrar colisão)
func _planta_montar(n: Node3D, tipo: int, rng: RandomNumberGenerator) -> void:
	var tronco := Color(0.4, 0.27, 0.16)
	match tipo:
		0, 1, 2:
			var c1 := Color(0.16, 0.45, 0.18); var c2 := Color(0.24, 0.56, 0.2); var c3 := Color(0.33, 0.66, 0.24)
			if tipo == 1: c1 = Color(0.9, 0.68, 0.08); c2 = Color(0.98, 0.8, 0.12); c3 = Color(1.0, 0.88, 0.3)      # ipê-amarelo
			if tipo == 2: c1 = Color(0.55, 0.25, 0.62); c2 = Color(0.68, 0.34, 0.74); c3 = Color(0.8, 0.5, 0.84)   # quaresmeira
			Lib.cil(n, 0.17, 0.3, 2.6, Vector3(0, 1.3, 0), tronco, 6)
			Lib.esf(n, 1.45, Vector3(0, 3.3, 0), c1, Vector3(1, 0.8, 1), 6)
			Lib.esf(n, 1.0, Vector3(0.85, 2.9, 0.3), c2, Vector3(1, 0.85, 1), 6)
			Lib.esf(n, 0.9, Vector3(-0.6, 3.9, -0.35), c3, Vector3(1, 0.85, 1), 6)
		3:
			Lib.cil(n, 0.1, 0.17, 4.0, Vector3(0, 2.0, 0), Color(0.55, 0.43, 0.28), 6)
			for k in range(7):
				var pv := Lib.pivo(n, Vector3(0, 4.0, 0)); pv.rotation.y = k * TAU / 7.0
				Lib.cx(pv, Vector3(0.42, 0.06, 1.9), Vector3(0, -0.3, 0.9), Color(0.2, 0.55, 0.2) if k % 2 == 0 else Color(0.3, 0.65, 0.22), Vector3(0.42, 0, 0))
			Lib.esf(n, 0.16, Vector3(0.14, 3.85, 0.1), Color(0.35, 0.22, 0.1), Vector3.ONE, 5)
			Lib.esf(n, 0.16, Vector3(-0.12, 3.82, -0.1), Color(0.35, 0.22, 0.1), Vector3.ONE, 5)
		4:
			Lib.esf(n, 0.6, Vector3(0, 0.3, 0), Color(0.2, 0.5, 0.2), Vector3(1.2, 0.7, 1), 6)
			Lib.esf(n, 0.4, Vector3(0.5, 0.25, 0.2), Color(0.3, 0.62, 0.24), Vector3(1, 0.8, 1), 5)
			if rng.randf() < 0.4: Lib.esf(n, 0.1, Vector3(0.1, 0.72, 0.2), Color(0.9, 0.2, 0.3), Vector3.ONE, 4)
		6:   # bananeira
			Lib.cil(n, 0.13, 0.2, 2.0, Vector3(0, 1.0, 0), Color(0.45, 0.6, 0.25), 6)
			for k in range(6):
				var pb := Lib.pivo(n, Vector3(0, 2.0, 0)); pb.rotation.y = k * TAU / 6.0 + 0.3
				Lib.cx(pb, Vector3(0.6, 0.05, 1.7), Vector3(0, 0.45, 0.7), Color(0.35, 0.72, 0.2) if k % 2 == 0 else Color(0.45, 0.8, 0.25), Vector3(-0.55, 0, 0))
			Lib.esf(n, 0.2, Vector3(0.2, 1.75, 0.15), Color(0.95, 0.85, 0.2), Vector3(0.7, 1.3, 0.7), 5)
		7:   # mandacaru: tronco com braços em cotovelo, de lados angulosos (como entalhado)
			var vd := Paleta.VERDE; var ve := Paleta.VERDE_ESC
			var alt := 3.2 + rng.randf() * 1.6
			Lib.cil(n, 0.2, 0.26, alt, Vector3(0, alt * 0.5, 0), vd, 5)
			Lib.esf(n, 0.2, Vector3(0, alt, 0), vd, Vector3(1, 0.8, 1), 5)
			for k in range(2 + rng.randi() % 2):
				var ang := k * PI + rng.randf() * 0.8
				var h0 := alt * (0.35 + 0.18 * k)
				var dx := cos(ang); var dz := sin(ang)
				var ab := Lib.pivo(n, Vector3(0, h0, 0)); ab.rotation.y = -ang
				Lib.cil(ab, 0.15, 0.15, 0.9, Vector3(0.45, 0, 0), ve, 5, Vector3(0, 0, PI / 2.0))
				var up := 1.0 + rng.randf() * 1.3
				Lib.cil(ab, 0.15, 0.17, up, Vector3(0.9, up * 0.5, 0), vd, 5)
				Lib.esf(ab, 0.15, Vector3(0.9, up, 0), vd, Vector3(1, 0.8, 1), 5)
			if rng.randf() < 0.5: Lib.esf(n, 0.13, Vector3(0.05, alt + 0.2, 0.05), Paleta.ROSA, Vector3.ONE, 5)
		8:   # xique-xique: roseta de lâminas espetadas
			for k in range(9):
				var pv := Lib.pivo(n, Vector3(0, 0.1, 0)); pv.rotation.y = k * TAU / 9.0 + rng.randf() * 0.3
				var lam := 0.9 + rng.randf() * 0.6
				Lib.cil(pv, 0.0, 0.17, lam, Vector3(0, lam * 0.5 * 0.7, lam * 0.32), Paleta.VERDE_CL if k % 2 == 0 else Paleta.VERDE, 4, Vector3(0.95, 0, 0))
		9:   # juazeiro retorcido: tronco torto, galhos em zigue-zague e copa achatada
			var base := Lib.pivo(n, Vector3.ZERO)
			var yy := 0.0
			var inc := 1.0
			for k in range(3):
				var seg := Lib.cil(base, 0.14, 0.2, 1.3, Vector3(0.18 * inc * k, yy + 0.6, 0), Paleta.TERRA_ESC, 5, Vector3(0, 0, 0.28 * inc))
				yy += 1.15; inc = -inc
			var topo := Vector3(0.1, yy + 0.4, 0)
			for k in range(3):
				var gb := Lib.pivo(n, topo); gb.rotation.y = k * TAU / 3.0 + 0.6
				Lib.cil(gb, 0.07, 0.11, 1.4, Vector3(0.55, 0.25, 0), Paleta.TERRA_ESC, 4, Vector3(0, 0, -1.0))
				Lib.esf(gb, 1.25, Vector3(1.1, 0.75, 0), Paleta.VERDE if k % 2 == 0 else Paleta.VERDE_ESC, Vector3(1, 0.5, 1), 6, 0.0, true)
		_:
			Lib.esf(n, 0.7, Vector3(0, 0.25, 0), Color(0.5, 0.5, 0.48), Vector3(1.2, 0.75, 1), 5)
			Lib.esf(n, 0.4, Vector3(0.6, 0.15, 0.3), Color(0.42, 0.42, 0.4), Vector3(1, 0.8, 1), 5)

func empurrar(p: Node3D) -> void:
	for t in troncos:
		var dx: float = p.position.x - t.x; var dz: float = p.position.z - t.y
		var rr: float = t.z + 0.35
		var d2 := dx * dx + dz * dz
		if d2 < rr * rr and d2 > 0.0001:
			var d := sqrt(d2)
			p.position.x = t.x + dx / d * rr; p.position.z = t.y + dz / d * rr

func _montar_camera() -> void:
	camera = Camera3D.new(); camera.fov = 66.0; camera.current = true; camera.far = 220.0
	add_child(camera)

func _mouse(preso: bool) -> void:
	if DisplayServer.get_name() == "headless" or cam_fixa or sem_mouse: return
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if preso else Input.MOUSE_MODE_VISIBLE
var sem_mouse := false

# ---------------- HUD ----------------
func _montar_hud() -> void:
	hud = CanvasLayer.new(); add_child(hud); hud.visible = false
	moldura = Panel.new(); moldura.set_anchors_preset(Control.PRESET_FULL_RECT); moldura.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sm := StyleBoxFlat.new(); sm.bg_color = Color(0, 0, 0, 0); sm.border_color = Color(0.85, 0.08, 0.05); sm.set_border_width_all(26); sm.border_blend = true
	moldura.add_theme_stylebox_override("panel", sm); moldura.modulate.a = 0.0; hud.add_child(moldura)
	# placa de tinta com o tempo da partida (massa preta com filete de palha, como cartela de folheto)
	var placa := Panel.new(); placa.mouse_filter = Control.MOUSE_FILTER_IGNORE
	placa.anchor_left = 0.5; placa.anchor_right = 0.5; placa.offset_left = -92; placa.offset_right = 92; placa.offset_top = 8; placa.offset_bottom = 58
	var sp := Tela.caixa(Tela.TINTA, 4, Tela.PARDO, 4); sp.ornamento = true; placa.add_theme_stylebox_override("panel", sp); hud.add_child(placa)
	lbl_topo = _label(32, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_topo.anchor_right = 1; lbl_topo.offset_top = 10; hud.add_child(lbl_topo)
	lbl_sub = _label(16, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_sub.anchor_right = 1; lbl_sub.offset_top = 66; hud.add_child(lbl_sub)
	barra_chefe_bg = ColorRect.new(); barra_chefe_bg.color = Tela.TINTA
	barra_chefe_bg.anchor_left = 0.5; barra_chefe_bg.anchor_right = 0.5
	barra_chefe_bg.offset_left = -250; barra_chefe_bg.offset_right = 250; barra_chefe_bg.offset_top = 96; barra_chefe_bg.offset_bottom = 114
	barra_chefe_bg.visible = false; hud.add_child(barra_chefe_bg)
	barra_chefe = ColorRect.new(); barra_chefe.color = Paleta.VERMELHO
	barra_chefe.position = Vector2(3, 3); barra_chefe.size = Vector2(494, 12); barra_chefe.material = Tela.material_hachura(); barra_chefe_bg.add_child(barra_chefe)
	var mold_chefe := Panel.new(); mold_chefe.set_anchors_preset(Control.PRESET_FULL_RECT); mold_chefe.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mold_chefe.add_theme_stylebox_override("panel", Tela.caixa(Color(0, 0, 0, 0), 4, Tela.PAPEL, 0)); barra_chefe_bg.add_child(mold_chefe)
	# minimapa no canto de cima, à direita, com abates e moedas embaixo
	minimapa = MiniMapa.new(); minimapa.w = self; minimapa.mouse_filter = Control.MOUSE_FILTER_IGNORE
	minimapa.anchor_left = 1; minimapa.anchor_right = 1; minimapa.offset_left = -208; minimapa.offset_right = -14; minimapa.offset_top = 12; minimapa.offset_bottom = 206
	hud.add_child(minimapa)
	lbl_dir = _label(17, HORIZONTAL_ALIGNMENT_RIGHT)
	lbl_dir.anchor_left = 1; lbl_dir.anchor_right = 1; lbl_dir.offset_left = -400; lbl_dir.offset_right = -14; lbl_dir.offset_top = 210; hud.add_child(lbl_dir)
	# dano por segundo, no canto de baixo à direita (só informativo, não mexe em nada do jogo)
	lbl_dps = _label(18, HORIZONTAL_ALIGNMENT_RIGHT)
	lbl_dps.anchor_left = 1; lbl_dps.anchor_right = 1; lbl_dps.anchor_top = 1; lbl_dps.anchor_bottom = 1
	lbl_dps.offset_left = -220; lbl_dps.offset_right = -14; lbl_dps.offset_top = -40; lbl_dps.offset_bottom = -10
	lbl_dps.grow_vertical = Control.GROW_DIRECTION_BEGIN; hud.add_child(lbl_dps)
	# mini inventário: cartas de atributo pegas, no canto de cima à esquerda
	caixa_inv = HFlowContainer.new(); caixa_inv.position = Vector2(12, 12); caixa_inv.size = Vector2(300, 80)
	caixa_inv.add_theme_constant_override("h_separation", 4); caixa_inv.add_theme_constant_override("v_separation", 4)
	caixa_inv.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud.add_child(caixa_inv)
	# retrato + vida + XP, embaixo à esquerda
	var canto := Control.new(); canto.anchor_top = 1; canto.anchor_bottom = 1; canto.offset_top = -84; canto.offset_left = 14
	canto.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud.add_child(canto)
	retrato = Panel.new(); retrato.position = Vector2(0, 0); retrato.size = Vector2(68, 68); retrato.clip_contents = true; canto.add_child(retrato)
	lbl_nome = _label(14, HORIZONTAL_ALIGNMENT_LEFT); lbl_nome.position = Vector2(78, -4); canto.add_child(lbl_nome)
	lbl_nv = _label(14, HORIZONTAL_ALIGNMENT_RIGHT); lbl_nv.position = Vector2(78, -4); lbl_nv.size = Vector2(262, 20); canto.add_child(lbl_nv)
	var bg := Panel.new(); bg.add_theme_stylebox_override("panel", Tela.caixa(Tela.TINTA, 2, Tela.PAPEL, 3, 4))
	bg.position = Vector2(76, 18); bg.size = Vector2(266, 30); canto.add_child(bg)
	barra_lag = ColorRect.new(); barra_lag.color = Tela.PAPEL
	barra_lag.position = Vector2(80, 22); barra_lag.size = Vector2(258, 22); canto.add_child(barra_lag)
	barra_vida = ColorRect.new(); barra_vida.color = Tela.URUCUM
	barra_vida.position = Vector2(80, 22); barra_vida.size = Vector2(258, 22); barra_vida.material = Tela.material_hachura(); canto.add_child(barra_vida)
	for q in [0.25, 0.5, 0.75]:                                  # marcas de entalhe a cada quarto de vida
		var marca := ColorRect.new(); marca.color = Tela.TINTA; marca.position = Vector2(80.0 + 258.0 * q - 1.0, 22); marca.size = Vector2(2, 22); canto.add_child(marca)
	lbl_vida = _label(16, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_vida.position = Vector2(80, 20); lbl_vida.size = Vector2(258, 24); canto.add_child(lbl_vida)
	var bgx := Panel.new(); bgx.add_theme_stylebox_override("panel", Tela.caixa(Tela.TINTA, 2, Tela.PAPEL, 0, 3))
	bgx.position = Vector2(76, 52); bgx.size = Vector2(266, 14); canto.add_child(bgx)
	barra_xp = ColorRect.new(); barra_xp.color = Tela.IPE
	barra_xp.position = Vector2(79, 55); barra_xp.size = Vector2(0, 8); barra_xp.material = Tela.material_hachura(); canto.add_child(barra_xp)
	# painel da build (segurar Tab)
	painel_info = Tela.painel(Color(1.0, 0.97, 0.86, 0.96), 3)
	painel_info.anchor_left = 0.5; painel_info.anchor_right = 0.5; painel_info.anchor_top = 0.08; painel_info.anchor_bottom = 0.08
	painel_info.grow_horizontal = Control.GROW_DIRECTION_BOTH; painel_info.grow_vertical = Control.GROW_DIRECTION_END
	caixa_placar = HBoxContainer.new(); caixa_placar.add_theme_constant_override("separation", 10); painel_info.add_child(caixa_placar)
	painel_info.visible = false; painel_info.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud.add_child(painel_info)
	# quadrinhos dos golpes, do especial e do ultimate, embaixo no meio
	caixa_slots = HBoxContainer.new(); caixa_slots.anchor_left = 0.5; caixa_slots.anchor_right = 0.5; caixa_slots.anchor_top = 1; caixa_slots.anchor_bottom = 1
	caixa_slots.offset_top = -80; caixa_slots.offset_bottom = -14; caixa_slots.grow_horizontal = Control.GROW_DIRECTION_BOTH
	caixa_slots.alignment = BoxContainer.ALIGNMENT_CENTER; caixa_slots.add_theme_constant_override("separation", 10); hud.add_child(caixa_slots)
	lbl_combo = _label(28, HORIZONTAL_ALIGNMENT_RIGHT)
	lbl_combo.anchor_left = 1; lbl_combo.anchor_right = 1; lbl_combo.anchor_top = 0.36; lbl_combo.anchor_bottom = 0.36
	lbl_combo.offset_left = -420; lbl_combo.offset_right = -22
	lbl_combo.add_theme_color_override("font_color", Tela.IPE); hud.add_child(lbl_combo)
	lbl_centro = _label(40, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_centro.anchor_right = 1; lbl_centro.anchor_top = 0.3; hud.add_child(lbl_centro)

# quadrinho de habilidade: gravura, sombra de recarga que desce, tecla e nível
func _quadro(arte: String, tecla: String, tam: float, nome: String = "", desc: String = "") -> Dictionary:
	var p := Panel.new(); p.custom_minimum_size = Vector2(tam, tam); p.size_flags_vertical = Control.SIZE_SHRINK_END
	p.add_theme_stylebox_override("panel", Tela.caixa(Tela.PAPEL, 3, Tela.TINTA, 4, 5))
	if nome != "": p.tooltip_text = (tr(nome) + "\n" + tr(desc)) if desc != "" else tr(nome)
	var im := Tela.imagem("a_" + arte, Vector2(tam - 8, tam - 8)); im.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	im.position = Vector2(4, 4); im.size = Vector2(tam - 8, tam - 8); im.clip_contents = true; p.add_child(im)
	var som := ColorRect.new(); som.color = Color(0.1, 0.07, 0.05, 0.74); som.position = Vector2(4, 4); som.size = Vector2(tam - 8, 0); som.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var msom := ShaderMaterial.new(); msom.shader = load("res://shaders/escuro.gdshader"); msom.set_shader_parameter("forca", 0.78); som.material = msom; p.add_child(som)
	var tx := _label(int(tam * 0.36), HORIZONTAL_ALIGNMENT_CENTER); tx.position = Vector2(0, tam * 0.24); tx.size = Vector2(tam, tam * 0.5); p.add_child(tx)
	var nv := _label(15, HORIZONTAL_ALIGNMENT_RIGHT); nv.position = Vector2(0, tam - 24); nv.size = Vector2(tam - 5, 20); p.add_child(nv)
	if tecla != "":
		var et := Panel.new(); et.add_theme_stylebox_override("panel", Tela.caixa(Tela.IPE, 2, Tela.TINTA, 0, 4))
		var lt := 22.0 + maxf(0.0, tecla.length() - 1.0) * 9.0
		et.position = Vector2(-7, -9); et.size = Vector2(lt, 22); p.add_child(et)
		var tk := Tela.rotulo(tecla, 13, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true); tk.size = Vector2(lt, 20); et.add_child(tk)
	caixa_slots.add_child(p)
	return {"no": p, "som": som, "txt": tx, "nv": nv, "tam": tam}

func _refazer_slots() -> void:
	for c in caixa_slots.get_children(): c.queue_free()
	_slots = []
	for g in player.golpes: _slots.append(_quadro(Dados.GOLPES[g["id"]]["arte"], "", 50.0))
	var vao := Control.new(); vao.custom_minimum_size = Vector2(10, 0); caixa_slots.add_child(vao)
	# cada herói tem seu próprio ícone de Q e de R (cor da classe), em vez de reaproveitar o de outro;
	# o nome do golpe fica sempre visível embaixo do ícone (não só em dica ao passar o mouse) — antes
	# era só um "Q"/"R" diminuto, sem dizer o que o golpe fazia.
	var hab: Dictionary = Dados.HABILIDADES[player.classe]
	var qs := _quadro("hab_q_" + player.classe, Ctrl.nome("q").left(3), 60.0, String(hab["q"]["nome"]), String(hab["q"]["txt"]))
	var rs := _quadro("hab_r_" + player.classe, Ctrl.nome("r").left(3), 60.0, String(hab["r"]["nome"]), String(hab["r"]["txt"]))
	for s in [qs, rs]:
		var lbl: Label = s["nv"]
		lbl.add_theme_font_size_override("font_size", 10)
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; lbl.position = Vector2(0, s["tam"] - 16); lbl.size = Vector2(s["tam"], 16)
		lbl.clip_text = true; lbl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	qs["nv"].text = tr(String(hab["q"]["nome"])); rs["nv"].text = tr(String(hab["r"]["nome"]))
	_slots.append(qs); _slots.append(rs)

func _hud_heroi() -> void:
	var c: Dictionary = Dados.CLASSES[player.classe]
	retrato.add_theme_stylebox_override("panel", Tela.caixa(Paleta.snap(c["cor"]).lerp(Tela.PAPEL, 0.35), 4, Tela.TINTA, 4))
	for f in retrato.get_children(): f.queue_free()
	var im := menus._retrato_heroi(player.classe, Vector2(62, 78)); im.position = Vector2(3, 3); im.size = Vector2(62, 78); retrato.add_child(im)
	lbl_nome.text = String(c["apelido"]).to_upper()
	_refazer_slots()

func _label(tam: int, al: int) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", Tela.fonte())
	l.add_theme_font_size_override("font_size", tam)
	l.add_theme_color_override("font_color", Color(0.95, 0.9, 0.78))
	l.add_theme_color_override("font_outline_color", Color(0.1, 0.08, 0.05))
	l.add_theme_constant_override("outline_size", 6)
	l.horizontal_alignment = al
	return l

# ---------------- co-op por LAN: cada pessoa vira um Jogador sincronizado pela rede ----------------
func iniciar_coop(fase_anfitriao: int = 0) -> void:
	menus.fechar()
	sel_fase = fase_anfitriao                      # a fase é a do ANFITRIÃO, igual pra todo mundo
	fase = clampi(sel_fase, 0, Dados.FASES.size() - 1)
	equipe_nivel = 1; equipe_xp = 0.0; equipe_xp_next = 8.0
	pausa_equipe = false; levelup_aberto = false; _rodadas.clear(); _rodada_pend.clear(); _rodada_ativa = false; _fora.clear()
	if not Rede.saiu.is_connected(_jogador_saiu): Rede.saiu.connect(_jogador_saiu)
	_aplicar_luz(int(Dados.FASES[fase]["luz"]))
	hud.visible = true
	estado = "jogo"
	jogadores_rede.clear(); player = null
	lbl_centro.text = tr("MULTIJOGADOR"); _piscar_centro()
	Rede.apresentar_se(sel_heroi, Rede.nome_local())
	if Rede.sou_host(): _montar_objetos()   # só o anfitrião decide o mapa; o convidado recebe tudo por RPC
	_mouse(true)

func _coop_spawns() -> void:
	for id in Rede.ids():
		if not jogadores_rede.has(id) and Rede.heroi_por_id.has(id):
			_spawnar_jogador_rede(id, Rede.heroi_por_id[id])

func _spawnar_jogador_rede(id: int, heroi: String) -> void:
	var j := Jogador.new(); j.name = "Jogador_%d" % id; j.world = self; j.configurar(heroi)
	j.set_multiplayer_authority(id)
	var sinc := MultiplayerSynchronizer.new(); sinc.name = "Sincronia"
	var cfg := SceneReplicationConfig.new()
	for campo in ["position", "rotation", "level", "max_hp", "hp", "dano_mult", "crit", "crit_dano", "atk_speed", "area_mult", "armor", "regen", "xp_mult", "golpes"]:
		var np := NodePath(".:%s" % campo)
		cfg.add_property(np); cfg.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ALWAYS)
	sinc.replication_config = cfg
	sinc.set_multiplayer_authority(id)
	sinc.public_visibility = false          # só começa a replicar depois que as outras máquinas também criaram este jogador
	j.add_child(sinc)
	add_child(j)
	get_tree().create_timer(1.2).timeout.connect(func():
		if is_instance_valid(sinc): sinc.public_visibility = true)
	jogadores_rede[id] = j
	_etiqueta_nome(j, id)
	Rede.nome_mudou.connect(func(quem: int):
		if quem == id and is_instance_valid(j): _etiqueta_nome(j, id))
	if id == Rede.meu_id():
		player = j
		_hud_heroi()

# Nome do jogador em cima da cabeça, como placa de folheto: letra de papel com contorno grosso de tinta (legível de longe e
# por cima de bicho). O nome é o que a pessoa digitou (no futuro, o da Steam); o anfitrião ganha uma coroa.
func _etiqueta_nome(j: Node3D, id: int) -> void:
	var antiga := j.get_node_or_null("Nome")
	if antiga: antiga.free()
	var nome := String(Rede.nome_por_id.get(id, "Jogador"))
	var e := Label3D.new(); e.name = "Nome"
	e.text = ("♛ " if id == 1 else "") + nome
	e.font = Tela.fonte(true); e.font_size = 64; e.pixel_size = 0.0105; e.outline_size = 0
	e.modulate = Tela.PAPEL
	e.billboard = BaseMaterial3D.BILLBOARD_ENABLED; e.no_depth_test = true; e.render_priority = 7
	# placa de tinta atrás do nome (bloco preto com filete de papel): lê de longe e por cima de bicho
	var tam: Vector2 = Tela.fonte(true).get_string_size(e.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 64) * 0.0105
	var placa := MeshInstance3D.new(); var q := QuadMesh.new(); q.size = tam + Vector2(0.55, 0.28); placa.mesh = q
	var mp := StandardMaterial3D.new(); mp.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED; mp.albedo_color = Tela.TINTA if id != Rede.meu_id() else Tela.URUCUM
	mp.no_depth_test = true; mp.render_priority = 3; mp.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED; placa.material_override = mp; placa.position = Vector3.ZERO; placa.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var filete := MeshInstance3D.new(); var qf := QuadMesh.new(); qf.size = tam + Vector2(0.45, 0.18); filete.mesh = qf
	var mf := StandardMaterial3D.new(); mf.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED; mf.albedo_color = Tela.PAPEL
	mf.no_depth_test = true; mf.render_priority = 4; mf.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED; filete.material_override = mf; filete.position = Vector3.ZERO; filete.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var miolo := MeshInstance3D.new(); var qm := QuadMesh.new(); qm.size = tam + Vector2(0.40, 0.13); miolo.mesh = qm
	var mm2 := mp.duplicate() as StandardMaterial3D; mm2.render_priority = 5
	miolo.material_override = mm2; miolo.position = Vector3.ZERO; miolo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	e.add_child(placa); e.add_child(filete); e.add_child(miolo)
	e.position = Vector3(0, 2.55, 0); j.add_child(e)

# quem é o jogador vivo mais perto desse ponto (pra mirar e pra bicho perseguir, no co-op) — sozinho, é sempre "player"
func _alvo_mais_perto(pos: Vector3):
	if not Rede.ativo() or jogadores_rede.is_empty(): return player
	var melhor = player
	var bd: float = pos.distance_squared_to(player.global_position) if player != null else INF
	for id in jogadores_rede:
		var j = jogadores_rede[id]
		if j == null or not is_instance_valid(j) or j.hp <= 0.0: continue
		var d2 := pos.distance_squared_to(j.global_position)
		if d2 < bd: bd = d2; melhor = j
	return melhor

# ainda está na sala? (protege contra mandar RPC pra quem já desconectou no meio da luta)
func _peer_aqui(id: int) -> bool:
	return id == Rede.meu_id() or multiplayer.get_peers().has(id)

# dano em cima de um jogador: se for outra pessoa no co-op, manda pra máquina dela de verdade aplicar
func ferir_jogador(alvo, dmg: float) -> void:
	if alvo == null: return
	if Rede.ativo() and alvo != player:
		for id in jogadores_rede:
			if jogadores_rede[id] == alvo and id != Rede.meu_id():
				if _peer_aqui(id): _sofrer_dano.rpc_id(id, dmg)
				return
	alvo.hurt(dmg)

@rpc("authority", "call_remote", "reliable")
func _sofrer_dano(dmg: float) -> void:
	if player: player.hurt(dmg)

# ---------------- bicho pela rede: o anfitrião manda nascer/morrer pra todo mundo ver ----------------
func _replicar_bicho(e: Inimigo) -> void:
	if not (Rede.ativo() and Rede.sou_host()): return
	_proximo_net_id += 1
	e.net_id = _proximo_net_id
	enemies_por_net_id[e.net_id] = e
	_spawnar_inimigo_rede.rpc(e.net_id, e.tipo, e.raio / 0.45, e.hp, e.max_hp_cache, e.dmg, e.speed, e.xp_val, e.moeda_val, e.is_boss, e.chefe_tipo, e.elite)

@rpc("authority", "call_remote", "reliable")
func _spawnar_inimigo_rede(net_id: int, tipo: String, escala: float, hp: float, maxhp: float, dmg: float, speed: float, xp: float, moeda: float, chefe: bool, chefe_tipo: String, elite: bool) -> void:
	if Rede.sou_host(): return
	var e := Inimigo.new(); e.name = "Bicho_%d" % net_id; e.world = self; add_child(e)
	e.net_id = net_id
	e.setup(tipo, escala, null)
	e.position = Vector3.ZERO  # a posição de verdade já chega no próximo quadro, pela sincronia abaixo
	e.hp = hp; e.max_hp_cache = maxhp; e.dmg = dmg; e.speed = speed; e.xp_val = xp; e.moeda_val = moeda
	e.is_boss = chefe; e.chefe_tipo = chefe_tipo; e.elite = elite
	e.set_multiplayer_authority(1)
	var sinc := MultiplayerSynchronizer.new(); sinc.name = "Sincronia"
	var cfg := SceneReplicationConfig.new()
	for campo in ["position", "rotation", "hp"]:
		var np := NodePath(".:%s" % campo)
		cfg.add_property(np); cfg.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ALWAYS)
	sinc.replication_config = cfg; sinc.set_multiplayer_authority(1)
	e.add_child(sinc)
	enemies.append(e); enemies_por_net_id[net_id] = e
	if chefe: chefe_veio = true; self.chefe = e

@rpc("authority", "call_remote", "reliable")
func _remover_inimigo_rede(net_id: int) -> void:
	var e = enemies_por_net_id.get(net_id)
	enemies_por_net_id.erase(net_id)
	if e == null or not is_instance_valid(e): return
	if e.is_boss and not Rede.sou_host(): chefe_morto = true; chefe = null
	enemies.erase(e)
	if not e.dead: e.dead = true; e.queue_free()   # cliente: só some; o anfitrião já tratou on_enemy_killed de verdade

@rpc("authority", "call_remote", "reliable")
func _marcar_furia_rede() -> void:
	furia = true

# quando o dono de verdade do bicho não é esta máquina, o golpe vira um pedido pro anfitrião (ver Inimigo.take_damage)
@rpc("any_peer", "call_remote", "reliable")
func retransmitir_dano(net_id: int, d: float, crit: int) -> void:
	if not Rede.sou_host(): return
	var quem := multiplayer.get_remote_sender_id()
	var e = enemies_por_net_id.get(net_id)
	if e == null or not is_instance_valid(e) or e.dead: return
	e.ultimo_atacante = quem
	e.take_damage(d, crit)

@rpc("authority", "call_remote", "reliable")
func _premiar_abate(xp: float, moeda_ganha: float) -> void:
	if player == null: return
	moedas += moeda_ganha
	if xp > 0.0: player.gain_xp(xp)
	if player.roubo > 0.0 and player.hp > 0.0: player.hp = minf(player.max_hp, player.hp + player.roubo)
	if player.ult_t <= 0.0: player.ult = minf(1.0, player.ult + 1.0 / Dados.ULT_ABATES)

# ---------------- co-op: nível, XP e cartas da EQUIPE ----------------
func equipe_ativa() -> bool:
	return Rede.ativo() and estado == "jogo"

# alguém (eu ou um parceiro) ganhou XP: vai pro cofre da equipe, que mora no anfitrião
func xp_para_equipe(v: float) -> void:
	if Rede.sou_host(): _somar_xp_equipe(v)
	else: _xp_equipe_pedido.rpc_id(1, v)

@rpc("any_peer", "call_remote", "reliable")
func _xp_equipe_pedido(v: float) -> void:
	if Rede.sou_host() and v > 0.0 and v < 5000.0: _somar_xp_equipe(v)

func _somar_xp_equipe(v: float) -> void:
	equipe_xp += v
	var subiu := 0
	while equipe_xp >= equipe_xp_next:
		equipe_xp -= equipe_xp_next
		equipe_nivel += 1
		equipe_xp_next = round(5 + equipe_nivel * 5 + 0.85 * equipe_nivel * equipe_nivel)
		subiu += 1
	_estado_equipe.rpc(equipe_nivel, equipe_xp, equipe_xp_next)
	for i in range(subiu): _enfileirar_rodada(_todos_vivos("nivel"))

@rpc("authority", "call_local", "reliable")
func _estado_equipe(nivel: int, xp: float, prox: float) -> void:
	equipe_nivel = nivel; equipe_xp = xp; equipe_xp_next = prox
	if player: player.level = nivel; player.xp = xp; player.xp_next = prox

func _todos_vivos(tipo: String) -> Dictionary:
	var t := {}
	for id in Rede.ids():
		if not _fora.has(id): t[id] = tipo
	return t

# ---- rodada de cartas: pára o jogo de TODOS até TODOS escolherem ----
func _enfileirar_rodada(tipos: Dictionary) -> void:
	if not Rede.sou_host(): return
	_rodadas.append({"tipos": tipos}); _tentar_rodada()

func _tentar_rodada() -> void:
	if _rodada_ativa or _rodadas.is_empty() or not Rede.sou_host(): return
	var r: Dictionary = _rodadas.pop_front()
	var tipos := {}
	var ids: Array = Rede.ids()
	for id in r["tipos"]:
		if ids.has(id) and not _fora.has(id): tipos[id] = r["tipos"][id]
	if tipos.is_empty(): _tentar_rodada(); return
	_rodada_ativa = true; _rodada_pend = tipos.duplicate()
	_rodada_abrir.rpc(tipos)

@rpc("authority", "call_local", "reliable")
func _rodada_abrir(tipos: Dictionary) -> void:
	if estado != "jogo": return
	if menus.tela != "": menus.fechar()        # pausa ou loja que eu tinha aberta: a rodada tem prioridade
	pausa_equipe = true; levelup_aberto = true
	lbl_centro.text = ""
	if _coop_teste: print("RODADA abriu t=%.2f minha=%s pausa=%s" % [time, str(tipos.get(Rede.meu_id(), "-")), str(pausa_equipe)])
	var meu: String = String(tipos.get(Rede.meu_id(), ""))
	if meu == "":
		_mostrar_espera(tipos.keys()); _mouse(false); return
	# subir de nível NÃO cura (regra de design: senão fica fácil demais)
	Som.tocar({"bau": "bau", "oratorio": "bencao", "contrabando": "loja", "caminho": "bencao"}.get(meu, "nivel"))
	if meu == "bau": Som.voz("v_bau")
	menus.nivel(player, _ofertas(meu), meu)
	_mouse(false)
	if _coop_teste:
		get_tree().create_timer(0.4 + randf() * 2.4).timeout.connect(func():
			if levelup_aberto and menus.tela == "nivel": _escolher_carta(player, _ofertas(meu)[0]))

func _mostrar_espera(pendentes: Array) -> void:
	var nomes := []
	for id in pendentes: nomes.append(String(Rede.nome_por_id.get(id, "Jogador")))
	lbl_centro.text = tr("Esperando escolherem a carta…\n%s") % ", ".join(nomes)

@rpc("any_peer", "call_local", "reliable")
func _rodada_pronto() -> void:
	if not Rede.sou_host(): return
	var quem := multiplayer.get_remote_sender_id()
	if quem == 0: quem = Rede.meu_id()
	_rodada_pend.erase(quem)
	_rodada_andamento()

func _rodada_andamento() -> void:
	if not _rodada_ativa: return
	for id in _rodada_pend.keys():
		if not Rede.ids().has(id) or _fora.has(id): _rodada_pend.erase(id)
	if _rodada_pend.is_empty():
		_rodada_ativa = false; _rodada_fim.rpc()
		_tentar_rodada()
	else: _rodada_status.rpc(_rodada_pend.keys())

@rpc("authority", "call_local", "reliable")
func _rodada_status(pendentes: Array) -> void:
	if pausa_equipe and menus.tela != "nivel": _mostrar_espera(pendentes)

@rpc("authority", "call_local", "reliable")
func _rodada_fim() -> void:
	pausa_equipe = false
	if menus.tela == "nivel": menus.fechar()
	levelup_aberto = false; lbl_centro.text = ""
	if _coop_teste: print("RODADA fechou t=%.2f" % time)
	_mouse(true)

# ESC: pausa (ou volta) o jogo pra equipe inteira, igual uma rodada de carta — quem apertou vê o menu
# de pausa, os outros só veem tudo parado (sem menu nenhum, o jogo deles não trava esperando ninguém
# escolher nada, só não anda).
func _pedir_pausa_equipe(v: bool) -> void:
	if Rede.sou_host(): _pausa_equipe_definir.rpc(v)
	else: _pausa_equipe_pedido.rpc_id(1, v)

@rpc("any_peer", "call_remote", "reliable")
func _pausa_equipe_pedido(v: bool) -> void:
	if Rede.sou_host(): _pausa_equipe_definir.rpc(v)

@rpc("authority", "call_local", "reliable")
func _pausa_equipe_definir(v: bool) -> void:
	pausa_equipe = v
	if not v and menus.tela == "pausa": menus.fechar(); _mouse(true)

# um jogador pediu uma carta sozinho (baú, oratório...): o jogo pára pra todos até ele escolher
@rpc("any_peer", "call_local", "reliable")
func _pedir_rodada(tipo: String) -> void:
	if not Rede.sou_host(): return
	var quem := multiplayer.get_remote_sender_id()
	if quem == 0: quem = Rede.meu_id()
	_enfileirar_rodada({quem: tipo})

# caí: não sou mais chamado pras próximas rodadas (e libero a atual, se eu estava devendo carta)
@rpc("any_peer", "call_local", "reliable")
func _ficou_fora() -> void:
	if not Rede.sou_host(): return
	var quem := multiplayer.get_remote_sender_id()
	if quem == 0: quem = Rede.meu_id()
	_fora[quem] = true; _rodada_pend.erase(quem); _rodada_andamento()

# ---- co-op: cair com gente viva não acaba a corrida pra você — vira espectador até a fase acabar pra todos ----
func tem_outro_vivo(exceto) -> bool:
	if player != exceto and player != null and player.hp > 0.0: return true
	for id in jogadores_rede:
		var j = jogadores_rede[id]
		if j != exceto and j != null and is_instance_valid(j) and j.hp > 0.0: return true
	return false

func jogador_caiu_coop() -> void:
	if player and player.boneco: player.boneco.visible = false
	lbl_centro.text = tr("Você caiu — esperando os outros terminarem a fase")
	if Rede.ativo(): _ficou_fora.rpc_id(1)

# pede o fim da fase/corrida pro grupo inteiro de uma vez (quem morreu por último, ou quem sai depois
# de vencer o chefe): sem isso, cada um decidia por si e quem já tinha virado espectador ficava preso
# olhando pro nada pra sempre, sem reviver na fase seguinte.
func _pedir_fim_grupo(titulo: String, cor: Color) -> void:
	if not Rede.ativo(): _encerrar(titulo, cor); return
	if Rede.sou_host(): _fim_grupo.rpc(titulo, cor)
	else: _fim_grupo_pedido.rpc_id(1, titulo, cor)

@rpc("any_peer", "call_remote", "reliable")
func _fim_grupo_pedido(titulo: String, cor: Color) -> void:
	if Rede.sou_host(): _fim_grupo.rpc(titulo, cor)

@rpc("authority", "call_local", "reliable")
func _fim_grupo(titulo: String, cor: Color) -> void:
	_encerrar(titulo, cor)

func _jogador_saiu(id: int) -> void:
	if Rede.sou_host():
		_fora[id] = true; _rodada_pend.erase(id); _rodada_andamento()

# ---- o que o anfitrião vê e todo mundo precisa ver igual ----
@rpc("authority", "call_remote", "unreliable")
func _sync_mundo(t: float, veio: bool, morto: bool, furia_: bool, extra: float, praga_: float) -> void:
	if Rede.sou_host(): return
	time = t; chefe_veio = veio; chefe_morto = morto; furia = furia_; extra_t = extra; praga = praga_

@rpc("authority", "call_remote", "reliable")
func _poder_rede(tipo: String) -> void:
	if Dados.PODERES.has(tipo): dar_poder(tipo)

# ---------------- arraial (menu) ----------------
# faixa pequena no topo avisando da atualização automática (só no menu)
func _faixa_atualizacao() -> void:
	if _faixa_up and is_instance_valid(_faixa_up): _faixa_up.queue_free()
	if atualizador == null or atualizador.estado in ["nada", "procurando", "erro"]: return
	var cl := CanvasLayer.new(); cl.layer = 60; add_child(cl)
	_faixa_up = PanelContainer.new(); _faixa_up.set_meta("cl", cl); cl.add_child(_faixa_up)
	var sp := Tela.caixa(Tela.TINTA, 3, Tela.PAPEL, 4); sp.set_content_margin_all(6); _faixa_up.add_theme_stylebox_override("panel", sp)
	_faixa_up.set_anchors_preset(Control.PRESET_CENTER_TOP); _faixa_up.offset_top = 4; _faixa_up.grow_horizontal = Control.GROW_DIRECTION_BOTH
	var h := HBoxContainer.new(); h.add_theme_constant_override("separation", 10); _faixa_up.add_child(h)
	if atualizador.estado == "baixando":
		h.add_child(Tela.rotulo(tr("⬇ Baixando a atualização do jogo…"), 14, Tela.PAPEL, HORIZONTAL_ALIGNMENT_CENTER, true))
	else:
		h.add_child(Tela.rotulo(tr("✔ Versão nova pronta (%s)") % atualizador.versao_nova, 14, Tela.PAPEL, HORIZONTAL_ALIGNMENT_CENTER, true))
		h.add_child(Tela.botao(tr("REINICIAR AGORA"), atualizador.reiniciar, 13, Tela.URUCUM, 170.0, 30.0))
		h.add_child(Tela.botao("✕", func(): cl.queue_free(), 12, Tela.PARDO, 34.0, 30.0))
	if estado == "jogo": cl.visible = false

func _montar_menu() -> void:
	if Salvo.d.has("heroi") and Dados.CLASSES.has(Salvo.d["heroi"]): sel_heroi = Salvo.d["heroi"]
	sel_fase = clampi(int(Salvo.d["fase"]), 0, mini(int(Salvo.d["fase_max"]), Dados.FASES.size() - 1))
	estado = "menu"
	menus.titulo()

# Transição de página: a folha do folheto cobre a tela e sobe, revelando a fase
func _transicao_pagina(dur: float = 0.9) -> void:
	if DisplayServer.get_name() == "headless" or Salvo.desligado: return
	var cl := CanvasLayer.new(); cl.layer = 30; add_child(cl)
	var r := ColorRect.new(); r.set_anchors_preset(Control.PRESET_FULL_RECT); r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m := ShaderMaterial.new(); m.shader = load("res://shaders/pagina.gdshader"); m.set_shader_parameter("progresso", 0.0)
	r.material = m; cl.add_child(r)
	var tw := create_tween()
	tw.tween_interval(0.12)
	tw.tween_method(func(v: float): m.set_shader_parameter("progresso", v), 0.0, 1.0, dur).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	tw.tween_callback(cl.queue_free)

func iniciar_jogo(id: String, f: int = 0, tutorial: bool = false) -> void:
	menus.fechar()
	_transicao_pagina()
	fase = clampi(f, 0, Dados.FASES.size() - 1)
	Salvo.d["heroi"] = id; Salvo.d["fase"] = fase; Salvo.salvar()
	_aplicar_luz(int(Dados.FASES[fase]["luz"]))
	player = Jogador.new(); player.world = self; player.configurar(id)
	add_child(player)
	_evento_t = randf_range(150.0, 210.0); _evento_fase = 0; _evento_inimigos = []
	hud.visible = true
	_hud_heroi()
	for it in Dados.LOJA: loja_precos[it["id"]] = int(it["preco"])
	estado = "jogo"
	if tutorial:
		tut = 0; tut_t = 0.0; _tut_pos = player.position; _tut_a = cam_yaw
	else:
		_montar_objetos()
		lbl_centro.text = tr("FASE %d — %s") % [fase + 1, tr(String(Dados.FASES[fase]["nome"])).to_upper()]
		_piscar_centro()
	_mouse(true)

# Luz da fase: 0 dia, 1 noite de lua, 2 queimada (fim de tarde alaranjado)
func _aplicar_luz(modo: int) -> void:
	# tema de cor por fase: queimada = mata virou cinza e terra; noite = verde azulado; dia/Corcovado = natural
	Materiais.definir_tema([Color(0, 0, 0), Color(0.16, 0.30, 0.34), Color(0.30, 0.27, 0.25), Color(0, 0, 0)][clampi(modo, 0, 3)], [0.0, 0.8, 0.95, 0.0][clampi(modo, 0, 3)])
	Materiais.papel_da_fase([Color(0.91, 0.84, 0.68), Color(0.52, 0.60, 0.72), Color(0.86, 0.79, 0.70), Color(0.94, 0.87, 0.62)][clampi(modo, 0, 3)], [0.2, 0.06, 0.4, 0.2][clampi(modo, 0, 3)], [1.0, 0.9, 0.55, 1.0][clampi(modo, 0, 3)])
	if modo == 0:        # dia (também restaura o padrão depois de uma fase de outra luz)
		_ceu(Color(0.19, 0.34, 0.42), Paleta.PAPEL, Color(0.53, 0.30, 0.21), Paleta.AMARELO, true)
		_sol.light_color = Color(1.0, 0.94, 0.8); _sol.light_energy = 1.15; _sol.rotation_degrees = Vector3(-48, -35, 0)
		_env.ambient_light_color = Color(0.74, 0.66, 0.58); _env.ambient_light_energy = 0.30
		_env.fog_light_color = Paleta.PAPEL; _env.fog_density = 0.0028
	elif modo == 1:        # noite de lua cheia
		_ceu(Color(0.07, 0.09, 0.16), Color(0.16, 0.22, 0.32), Color(0.05, 0.07, 0.1), Paleta.CREME, true)
		_sol.light_color = Color(0.62, 0.72, 1.0); _sol.light_energy = 0.6
		_env.ambient_light_color = Color(0.36, 0.42, 0.6); _env.ambient_light_energy = 0.52
		_env.fog_light_color = Color(0.16, 0.2, 0.3); _env.fog_density = 0.009
	elif modo == 3:      # amanhecer no Corcovado
		_ceu(Color(0.2, 0.34, 0.5), Color(0.93, 0.78, 0.58), Color(0.3, 0.3, 0.3), Paleta.AMARELO_CL, true)
		_sol.light_color = Color(1.0, 0.88, 0.7); _sol.light_energy = 1.15; _sol.rotation_degrees = Vector3(-34, 18, 0)
		_env.ambient_light_color = Color(0.74, 0.66, 0.62)
		_env.fog_light_color = Color(0.93, 0.8, 0.66); _env.fog_density = 0.003
	elif modo == 2:      # queimada
		_ceu(Color(0.36, 0.16, 0.12), Color(0.85, 0.42, 0.2), Color(0.2, 0.1, 0.08), Paleta.AMARELO_CL, true)
		_sol.light_color = Color(1.0, 0.76, 0.58); _sol.light_energy = 0.95; _sol.rotation_degrees = Vector3(-22, -35, 0)
		_env.ambient_light_color = Color(0.66, 0.57, 0.5)
		_env.fog_light_color = Color(0.72, 0.56, 0.44); _env.fog_density = 0.01
	_atualizar_sol()

# ---------------- laço ----------------
func _process(delta: float) -> void:
	if fogo: fogo.scale = Vector3.ONE * (1.0 + 0.12 * sin(Time.get_ticks_msec() * 0.011)) + Vector3(0, 0.2 * sin(Time.get_ticks_msec() * 0.017), 0)
	if estado == "menu": cam_yaw += delta * 0.12
	_seguir_camera(delta)
	var st := Ctrl.start()                    # Start do controle = ESC
	if st and not _start_ant:
		if estado == "jogo" and not levelup_aberto: pausar()
		else: menus.esc()
	_start_ant = st
	if Engine.get_process_frames() % 30 == 0: _pixel()
	if estado == "fim":
		if Input.is_physical_key_pressed(KEY_ENTER) or Input.is_physical_key_pressed(KEY_KP_ENTER):
			get_tree().reload_current_scene()
		return
	if mundo_parado(): return
	if Rede.ativo(): _coop_spawns()
	if player == null: return       # co-op: esperando o próprio boneco chegar pela rede (dura um quadro só)
	time += delta
	if Rede.ativo() and Rede.sou_host():
		_sync_t -= delta
		if _sync_t <= 0.0: _sync_t = 1.0; _sync_mundo.rpc(time, chefe_veio, chefe_morto, furia, extra_t, praga)
	_marcos_de_ritmo()
	if tut >= 0: _tutorial(delta)
	elif Rede.ativo() and not Rede.sou_host(): pass   # os bichos são mandados pelo anfitrião, chegam pela rede
	else: _dirigir(delta)
	_update_projectiles(delta)
	_tiros(delta)
	_hab_update(delta)
	_vaga_lumes(delta)
	_objetos(delta)
	_pombas_girando(delta)
	_poderes(delta)
	_hud()
	var cj := Ctrl.cam()                      # analógico direito gira a câmera
	if cj != Vector2.ZERO:
		cam_yaw -= cj.x * 2.6 * delta * Tela.opc("sens")
		cam_pitch = clampf(cam_pitch + cj.y * 1.6 * delta * Tela.opc("sens"), 0.08, 1.25)
	if chefe_morto and Ctrl.ap("sair"): _pedir_fim_grupo("FASE VENCIDA!", Color(1.0, 0.85, 0.3))
	_teste_tick()

# câmera em terceira pessoa: orbita o herói conforme o mouse
func _seguir_camera(delta: float) -> void:
	if cam_fixa: return
	var foco := Vector3(0, Lib.h(0, 0) + 1.4, 0)
	if player: foco = player.global_position + Vector3(0, 1.5, 0)
	if player and player.hp <= 0.0:          # virei espectador: acompanha quem ainda tá vivo, não fico olhando o nada
		var vivo = _alvo_mais_perto(player.global_position)
		if vivo and is_instance_valid(vivo) and vivo.hp > 0.0: foco = vivo.global_position + Vector3(0, 1.5, 0)
	var dir := Vector3(sin(cam_yaw) * cos(cam_pitch), sin(cam_pitch), cos(cam_yaw) * cos(cam_pitch))
	var alvo := foco + dir * cam_dist
	alvo.y = maxf(alvo.y, Lib.h(alvo.x, alvo.z) + 0.6)
	camera.global_position = camera.global_position.lerp(alvo, clampf(delta * 14.0, 0, 1))
	camera.look_at(foco, Vector3.UP)
	if tremor > 0.0:
		camera.global_position += Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * tremor * 0.3
		tremor = maxf(0.0, tremor - delta * 2.6)
	# árvore no caminho entre a câmera e o herói some, para nunca tapar a visão
	var c2 := Vector2(camera.global_position.x, camera.global_position.z); var f2 := Vector2(foco.x, foco.z)
	for o in oclusores:
		var pt := Vector2(o[1], o[2])
		o[0].visible = pt.distance_to(Geometry2D.get_closest_point_to_segment(pt, c2, f2)) > o[3]

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_F11:
		# F11 liga/desliga a tela cheia em qualquer tela do jogo; vale também pra opção "Tela cheia" (fica salva)
		Salvo.d["opcoes"]["cheia"] = 0.0 if Tela.opc("cheia") > 0.5 else 1.0
		Tela.aplicar_opcoes(); Salvo.salvar()
		if menus != null and menus.tela == "opcoes": menus.opcoes(menus._volta)
		get_viewport().set_input_as_handled(); return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var sens := Tela.opc("sens")
		cam_yaw -= event.relative.x * 0.0035 * sens
		cam_pitch = clampf(cam_pitch + event.relative.y * 0.003 * sens, 0.08, 1.25)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		if estado != "jogo" or levelup_aberto: return
		if event.button_index == MOUSE_BUTTON_WHEEL_UP: cam_dist = maxf(6.0, cam_dist - 0.8)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN: cam_dist = minf(22.0, cam_dist + 0.8)
		elif event.button_index == MOUSE_BUTTON_LEFT: _mouse(true)
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_ESCAPE:
		if estado == "jogo" and not levelup_aberto: pausar()
		else: menus.esc()

# ---------------- pausa (ESC) e opções ----------------
# o MUNDO (bichos, tempo, tiros) está parado? Sozinho, qualquer tela aberta pára tudo; no co-op só a pausa da equipe pára
func mundo_parado() -> bool:
	if estado != "jogo": return true
	return pausa_equipe if Rede.ativo() else levelup_aberto

# EU estou parado (sem andar nem atacar)? No co-op, tela minha aberta ou pausa da equipe
func jogador_parado() -> bool:
	return estado != "jogo" or levelup_aberto or pausa_equipe

func pausar() -> void:
	if Rede.ativo():       # ESC agora pára o jogo pra equipe inteira (igual rodada de carta), não só o meu menu
		if estado != "jogo" or levelup_aberto: return
		lbl_centro.text = ""; menus.pausa(); _mouse(false)
		_pedir_pausa_equipe(true)
		return
	if estado != "jogo" or levelup_aberto: return
	estado = "pausa"
	lbl_centro.text = ""
	_mouse(false)
	menus.pausa()

func continuar() -> void:
	if Rede.ativo() and menus.tela == "pausa":
		menus.fechar(); _mouse(true)
		_pedir_pausa_equipe(false)
		return
	if estado != "pausa": return
	menus.fechar()
	estado = "jogo"
	_mouse(true)

func sair_da_fase() -> void:
	if estado != "pausa" and not (Rede.ativo() and menus.tela == "pausa"): return
	if tut >= 0:
		_fim_tutorial(); return
	menus.fechar(); estado = "jogo"
	_pedir_fim_grupo("FASE VENCIDA!" if chefe_morto else "VOCÊ SAIU DA FASE", Color.WHITE)

func aplicar_opcoes() -> void:
	cam_dist = Tela.opc("camera")
	_pixel()

func _pixel() -> void:
	if papel_cl: papel_cl.visible = estado != "menu"

func _notification(what: int) -> void:      # trocou de janela no meio da fase: pausa sozinho
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and menus != null and estado == "jogo" and not levelup_aberto and _teste_fim == 0.0 and not sem_mouse:
		pausar()

# ---------------- diretor da fase ----------------
# Até o chefe: os bichos vão engrossando devagar. Chefe aos 10 minutos, com 3 para vencer; se não vencer,
# ele enfurece e a mata despeja bicho. Chefe vencido: fase infinita, cada vez mais bicho e mais forte.
# avisos no meio da partida (não mexem em nada, só marcam que o tempo tá passando e a coisa tá esquentando)
func _marcos_de_ritmo() -> void:
	if _marco_visto == 0 and time >= 150.0:
		_marco_visto = 1; lbl_centro.text = "A MATA TÁ ESQUENTANDO…"; _piscar_centro()
	elif _marco_visto == 1 and time >= 330.0:
		_marco_visto = 2; lbl_centro.text = "METADE DO CAMINHO!"; _piscar_centro()
	elif _marco_visto == 2 and time >= 510.0:
		_marco_visto = 3; lbl_centro.text = "O CHEFE TÁ CHEGANDO…"; _piscar_centro()

func _dirigir(delta: float) -> void:
	if Rede.ativo() and not Rede.sou_host(): return   # só quem hospeda manda nos bichos
	var fm: float = Dados.FASES[fase]["mult"]
	# cada pessoa a mais no co-op deixa os bichos mais fortes e em mais quantidade, pra não ficar fácil demais
	var qtd_jogadores := (Rede.ids().size() if Rede.ativo() else 1)
	var mult_coop := 1.0 + 0.35 * (qtd_jogadores - 1)
	var forca := (1.0 + time / 75.0) * fm * praga * mult_coop
	# começa mais cheio (não só perto do chefe aos 10min) — sensação de ritmo mais vivo desde o início
	var intervalo := maxf(0.2, 0.7 - time / 900.0) / (1.0 + 0.25 * (qtd_jogadores - 1))
	var teto := int(150 * (1.0 + 0.5 * (qtd_jogadores - 1)))
	var passo := 1.0
	if chefe_morto:
		extra_t += delta
		forca *= pow(1.0 + extra_t / 60.0, 1.6)
		intervalo = maxf(0.05, 0.3 - extra_t / 600.0) / (1.0 + 0.25 * (qtd_jogadores - 1)); teto = int(230 * (1.0 + 0.5 * (qtd_jogadores - 1)))
		passo = minf(1.8, 1.0 + extra_t / 300.0)
	elif furia:
		intervalo *= 0.3; teto = int(230 * (1.0 + 0.5 * (qtd_jogadores - 1))); passo = 1.25
	spawn_t -= delta
	if spawn_t <= 0.0 and enemies.size() < teto:
		spawn_t = intervalo
		var novo := _nascer(Dados.sortear_bicho(time, fase), forca, 1.0, null, false); novo.speed *= passo
		_replicar_bicho(novo)
	# elite: criatura normal, só que com mais vida e mais dano
	elite_t -= delta
	if elite_t <= 0.0:
		elite_t = 8.0 if chefe_morto else 20.0
		var el := _nascer(Dados.sortear_bicho(time, fase), forca, 1.5, Color(0.98, 0.85, 0.2), false, 6.0, 1.6, 8.0)
		el.moeda_val = 4.0; el.elite = true; _replicar_bicho(el)
	if not chefe_veio and time >= chefe_t:
		chefe_veio = true; furia_t = Dados.FURIA_T
		var f: Dictionary = Dados.FASES[fase]
		chefe = _nascer(f["chefe"], forca, {"mapinguari": 2.6, "mula": 2.1, "boitata": 2.0, "cuca": 1.8, "minhocao": 3.4}.get(f["chefe"], 2.1), null, true)
		chefe.chefe_tipo = f.get("ataque", f["chefe"])
		chefe.hp = 700.0 * forca; chefe.max_hp_cache = chefe.hp
		chefe.dmg = 14.0 * sqrt(forca); chefe.speed = 2.7; chefe.xp_val = 60.0; chefe.moeda_val = 150.0
		_replicar_bicho(chefe)
		lbl_centro.text = tr("%s\n%s\nVença em 3 minutos") % [tr(String(f["chefe_nome"])), tr(String(f["chefe_titulo"]))]; _piscar_centro()
		Som.tocar("chefe"); Som.voz("v_chefe"); tremor = 0.6
	if chefe_veio and not chefe_morto and not furia:
		furia_t -= delta
		if furia_t <= 0.0:
			furia = true
			if is_instance_valid(chefe):
				chefe.furia = true; chefe.dmg *= 2.5; chefe.speed *= 1.6
				chefe.hp += chefe.max_hp_cache * 0.5; chefe.max_hp_cache = maxf(chefe.max_hp_cache, chefe.hp)
			lbl_centro.text = "O CHEFE ENFURECEU!"; _piscar_centro(); Som.tocar("chefe"); Som.voz("v_furia")
			if Rede.ativo(): _marcar_furia_rede.rpc()
	_evento_cerco(delta, forca)

# cerco da mata: de vez em quando (3-5min) um susto de verdade no meio da trilha normal de bichos — aviso,
# depois um anel de bichos nasce em volta do jogador, e sobreviver garante um baú (não precisa matar todos,
# só aguentar o tranco). Só antes do chefe chegar, pra não empilhar caos em cima da luta de chefe.
func _evento_cerco(delta: float, forca: float) -> void:
	if chefe_veio: return
	match _evento_fase:
		0:
			_evento_t -= delta
			if _evento_t <= 0.0:
				_evento_fase = 1; _evento_tempo = 1.1
				lbl_centro.text = "A MATA TÁ FECHANDO O CERCO…"; _piscar_centro()
				_efeito_anel(player.global_position, 9.0, Color(1.0, 0.2, 0.1)); Som.tocar("pisao"); tremor = maxf(tremor, 0.3)
		1:
			_evento_tempo -= delta
			if _evento_tempo <= 0.0:
				_evento_fase = 2; _evento_tempo = 14.0; _evento_inimigos = []
				var qtd_jogadores := (Rede.ids().size() if Rede.ativo() else 1)
				var n := 8 + int(2.0 * (qtd_jogadores - 1))
				for i in range(n):
					var a := i * TAU / n
					var pos := player.global_position + Vector3(cos(a), 0, sin(a)) * 15.0
					var e := _nascer(Dados.sortear_bicho(time, fase), forca * 1.1, 1.0, null, false)
					e.position = pos; _evento_inimigos.append(e); _replicar_bicho(e)
				lbl_centro.text = "CERCO FECHADO! Aguenta até acabar"; _piscar_centro(); Som.tocar("chefe"); tremor = maxf(tremor, 0.4)
		2:
			_evento_tempo -= delta
			_evento_inimigos = _evento_inimigos.filter(func(e): return is_instance_valid(e) and not e.dead)
			if _evento_tempo <= 0.0 or _evento_inimigos.is_empty():
				_evento_fase = 3
				_novo_objeto("bau", player.global_position + Vector3(2.0, 0, 0), 0)
				lbl_centro.text = "RESISTIU! Achou um baú"; _piscar_centro(); Som.tocar("venceu"); tremor = maxf(tremor, 0.3)
				_evento_t = randf_range(170.0, 230.0); _evento_fase = 0

func _pos_spawn() -> Vector3:
	var a := randf() * TAU; var d := SPAWN_RAIO + randf() * 8.0
	var p := player.global_position + Vector3(cos(a) * d, 0, sin(a) * d)
	var r2 := Vector2(p.x, p.z)
	if r2.length() > ARENA + 1.5:        # os bichos saem de dentro da mata
		r2 = r2.normalized() * (ARENA + 1.5); p.x = r2.x; p.z = r2.y
	return p

func _nascer(tipo: String, forca: float, escala: float, cor, e_chefe: bool, mulhp := 1.0, muldmg := 1.0, xpv := 1.0) -> Inimigo:
	var e := Inimigo.new(); e.world = self; add_child(e)
	var bi: Dictionary = Dados.BICHOS.get(tipo, Dados.BICHOS["caipora"])
	e.setup(tipo, escala * float(bi["esc"]) if Dados.BICHOS.has(tipo) else escala, cor); e.position = _pos_spawn(); e.position.y = Lib.h(e.position.x, e.position.z)
	e.hp = float(bi["hp"]) * forca * mulhp; e.max_hp_cache = e.hp
	e.speed = float(bi["vel"]); e.dmg = 6.0 * sqrt(forca) * muldmg * float(bi["dano"]); e.xp_val = xpv * float(bi["xp"])
	e.is_boss = e_chefe
	enemies.append(e)
	if not Salvo.desligado and tut < 0 and Dados.LORE.has(tipo) and not Salvo.d["vistos"].has(tipo):      # primeira vez que aparece: ficha com a história
		Salvo.d["vistos"][tipo] = true
		abrir_escolha("lore:" + tipo)
	return e

# ---------------- GOLPES ----------------
func _nearest(pos: Vector3, maxd: float):
	var melhor = null; var bd := maxd * maxd
	for e in enemies:
		if not is_instance_valid(e) or e.dead: continue
		var dd: Vector3 = e.global_position - pos; dd.y = 0
		var d2 := dd.length_squared()
		if d2 < bd: bd = d2; melhor = e
	return melhor

func cast_golpe(p: Jogador, id: String, nivel: int) -> void:
	var def = Dados.GOLPES[id]
	Salvo.contar("uso_" + id)
	var dmg: float = Dados.dano_golpe(id, nivel) * p.dano_mult
	var cb: float = def.get("crit", 0.0)          # chance extra de crítico do próprio golpe
	if p.crit_certo:
		cb += 1.0; p.crit_certo = false
	var raio: float = def.get("raio", 1.0) * p.area_mult
	var cor: Color = Dados.CLASSES[p.classe]["cor"]
	var alcance: float = def.get("alcance", 20.0)
	match def["tipo"]:
		"ring":
			_ring(p.global_position, raio, dmg, def.get("stun", 0.0), def.get("knock", 0.0), cb)
			_efeito_anel(p.global_position, raio, cor)
		"arco":
			_arco(p, def, dmg, raio)
		"onda":
			_ring(p.global_position, raio, dmg, 0.0, def.get("knock", 0.0), cb)
			_efeito_anel(p.global_position, raio, cor)
			_efeito_anel(p.global_position, raio * 0.6, cor)
		"investida":
			var alvo = _nearest(p.global_position, alcance)
			if alvo == null: return
			var pos: Vector3 = alvo.global_position
			p.guarda_t = 1.0          # fecha a guarda já na entrada
			p.comecar_investida(pos, 18.0, func():
				var k := _ring(p.global_position, raio, dmg, def.get("stun", 0.0), 0.0, cb)
				_efeito_anel(p.global_position, raio, cor)
				p.guarda_t = 0.9
				if k > 0: p.curar(minf(p.max_hp * 0.04, k * (1.5 + p.max_hp * 0.007))))
		"proj_reto":
			var alvo2 = _nearest(p.global_position, alcance)
			var ang := atan2(alvo2.global_position.z - p.global_position.z, alvo2.global_position.x - p.global_position.x) if alvo2 else atan2(p.frente.z, p.frente.x)
			var n: int = int(def.get("n", 1))
			for i in range(n):
				var a := ang + (randf() - 0.5) * float(def.get("spread", 0.0))
				_disparar(p.global_position, Vector3(cos(a), 0, sin(a)) * float(def["vel"]), def, dmg)
		"proj_teleguiado":
			var alvo3 = _nearest(p.global_position, alcance)
			if alvo3 == null: return
			var dir: Vector3 = (alvo3.global_position - p.global_position); dir.y = 0
			dir = dir.normalized()
			var qtd := 1 + int((nivel - 1) / 2.0)     # a cada 2 níveis sai mais um fogo
			for i in range(qtd):
				var d2 := dir.rotated(Vector3.UP, (i - (qtd - 1) * 0.5) * 0.5)
				_disparar(p.global_position, d2 * float(def["vel"]), def, dmg, alvo3 if i == 0 else null)
		"proj_estoura":
			var alvo4 = _nearest(p.global_position, alcance)
			var dir2: Vector3 = (alvo4.global_position - p.global_position) if alvo4 else p.frente
			dir2.y = 0
			_disparar(p.global_position, dir2.normalized() * float(def["vel"]), def, dmg)

# devolve quantos bichos caíram com o golpe
# Todo dano do herói passa por aqui: sorteia o crítico. Chance acima de 100% vira crítico duplo, e triplo acima de 200%.
func ferir(e, dmg: float, bonus: float = 0.0) -> void:
	var ch: float = player.crit + bonus
	var n := int(ch)
	if randf() < ch - n: n += 1
	n = mini(n, 3)
	if n > 0: dmg *= pow(player.crit_dano, n)
	dano_total += dmg; maior_dano = maxf(maior_dano, dmg)
	_dps_janela.append([time, dmg])
	Som.tocar("crit" if n > 0 else "hit", -6.0 if n == 0 else -2.0, 0.15, 0.06)
	if n > 0:
		Salvo.contar("criticos")
		if n > 1: tremor = maxf(tremor, 0.12 * n)
	e.take_damage(dmg, n)

func _ring(centro: Vector3, raio: float, dmg: float, stun: float, knock: float, cb: float = 0.0) -> int:
	var caiu := 0
	for e in enemies.duplicate():
		if not is_instance_valid(e) or e.dead: continue
		var dd: Vector3 = e.global_position - centro; dd.y = 0
		if dd.length() <= raio + e.raio * 0.5:
			ferir(e, dmg, cb)
			if e.dead: caiu += 1; continue
			if stun > 0.0: e.stun_t = maxf(e.stun_t, stun if not e.is_boss else stun * 0.2)
			if knock > 0.0 and not e.is_boss: e.position += dd.normalized() * knock
	return caiu

func _arco(p: Jogador, def: Dictionary, dmg: float, raio: float) -> void:
	var alvo = _nearest(p.global_position, raio + 1.5)
	var dir: Vector3 = p.frente
	if alvo: dir = (alvo.global_position - p.global_position); dir.y = 0; dir = dir.normalized()
	var meia: float = def.get("ang", 1.2) * 0.5
	for e in enemies.duplicate():
		if not is_instance_valid(e) or e.dead: continue
		var dd: Vector3 = e.global_position - p.global_position; dd.y = 0
		if dd.length() > raio + e.raio * 0.5: continue
		if dd.length() > 0.5 and dd.normalized().angle_to(dir) > meia: continue
		ferir(e, dmg, def.get("crit", 0.0))
		if e.dead: continue
		if def.has("stun"): e.stun_t = maxf(e.stun_t, def["stun"] if not e.is_boss else def["stun"] * 0.2)
		if def.has("knock") and not e.is_boss: e.position += dd.normalized() * def["knock"]
	_efeito_setor(p.global_position, atan2(dir.z, dir.x), raio, def.get("ang", 1.2), Dados.CLASSES[p.classe]["cor"])

# ---------------- projéteis ----------------
func _disparar(pos: Vector3, vel: Vector3, def: Dictionary, dmg: float, alvo = null) -> void:
	var n: MeshInstance3D
	if DisplayServer.get_name() == "headless":
		n = MeshInstance3D.new()
	else:
		n = _malha_estrela(def["raio"] * 2.6, def.get("cor", Color.WHITE), 8)           # projétil = estrela gravada (tinta + cor)
	n.position = pos + Vector3(0, 0.9, 0)
	add_child(n)
	projectiles.append({
		"node": n, "vel": vel, "raio": def["raio"] + 0.4, "dmg": dmg,
		"pierce": def.get("pierce", 0), "vida": def.get("vida", 2.0),
		"homing": def["tipo"] == "proj_teleguiado", "alvo": alvo,
		"boom": def.get("boom", 0.0), "hits": {}, "cb": def.get("crit", 0.0)
	})

func _update_projectiles(delta: float) -> void:
	for pr in projectiles.duplicate():
		var n: Node3D = pr["node"]
		if not is_instance_valid(n): projectiles.erase(pr); continue
		pr["vida"] -= delta
		if pr["homing"]:
			if not is_instance_valid(pr["alvo"]) or pr["alvo"].dead:
				pr["alvo"] = _nearest(n.global_position, 12.0)
			if pr["alvo"]:
				var want: Vector3 = (pr["alvo"].global_position - n.global_position); want.y = 0
				pr["vel"] = pr["vel"].lerp(want.normalized() * pr["vel"].length(), 0.12)
		n.global_position += pr["vel"] * delta
		n.position.y = Lib.h(n.position.x, n.position.z) + 0.9
		for e in enemies:
			if not is_instance_valid(e) or e.dead or pr["hits"].has(e): continue
			var dd: Vector3 = e.global_position - n.global_position; dd.y = 0
			if dd.length() < pr["raio"] + 0.4:
				ferir(e, pr["dmg"], pr["cb"]); pr["hits"][e] = true
				if pr["boom"] > 0.0:
					_ring(n.global_position, pr["boom"], pr["dmg"] * 0.6, 0.0, 0.5)
					_efeito_anel(n.global_position, pr["boom"], Color(0.49, 0.78, 0.4)); pr["vida"] = 0
				if pr["pierce"] <= 0: pr["vida"] = 0
				else: pr["pierce"] -= 1
		if pr["vida"] <= 0:
			if pr["boom"] > 0.0 and pr["hits"].is_empty():
				_ring(n.global_position, pr["boom"], pr["dmg"] * 0.6, 0.0, 0.5)
				_efeito_anel(n.global_position, pr["boom"], Color(0.49, 0.78, 0.4))
			n.queue_free(); projectiles.erase(pr)

# ---------------- mortes, XP, nível ----------------
func on_enemy_killed(e) -> void:
	enemies.erase(e); kills += 1
	Som.tocar("morte", -8.0, 0.2, 0.07)
	_puff(e.global_position, e.boneco.cor_base, e.raio / 0.45)
	Salvo.contar("abates"); Salvo.contar("abates_" + e.tipo)
	var mm := 1.0 + 0.10 * Salvo.nivel("moedas")
	if chefe_morto: mm *= 1.0 + extra_t / 90.0        # quanto mais tempo depois do chefe, mais vale cada bicho
	var moeda_ganha: float = e.moeda_val * mm
	combo += 1; combo_t = 3.0
	if combo > int(Salvo.d["contadores"].get("combo_max", 0)): Salvo.d["contadores"]["combo_max"] = combo
	if Dados.COMBO_GRITOS.has(combo):
		lbl_centro.text = tr("%s\n×%d — ◉ +%d") % [tr(String(Dados.COMBO_GRITOS[combo])), combo, combo / 5]; _piscar_centro()
		moeda_ganha += combo / 5.0
	if e.chefe_tipo == "cuca":
		dar_poder("mula")
		if Rede.ativo(): _poder_rede.rpc("mula")
	elif e.elite and Dados.PODERES.has(e.tipo) and randf() < 0.4:
		dar_poder(e.tipo)
		if Rede.ativo(): _poder_rede.rpc(e.tipo)
	if e.chefe_tipo == "cuca":
		_novo_objeto("bau", e.global_position + Vector3(1.4, 0, 0), 0); _novo_objeto("bau", e.global_position - Vector3(1.4, 0, 0), 0)
		lbl_centro.text = "A CUCA FOI EMBORA!\nO tesouro é seu"; _piscar_centro(); Som.tocar("venceu"); tremor = 0.7
	elif e.elite and randf() < 0.4: _novo_objeto("bau", e.global_position, 0)
	if e.is_boss:
		chefe_morto = true; chefe = null; tremor = 1.0; Som.tocar("venceu"); Som.voz("v_venceu")
		_novo_objeto("bau", e.global_position + Vector3(1.5, 0, 0), 0); _novo_objeto("bau", e.global_position - Vector3(1.5, 0, 0), 0)
		Salvo.contar("chefes")
		Salvo.d["fase_max"] = maxi(int(Salvo.d["fase_max"]), mini(fase + 1, Dados.FASES.size() - 1))
		Salvo.salvar()
		lbl_centro.text = tr("DERROTOU O CHEFE!\nAgora aguente o quanto der — %s para sair") % Ctrl.nome("sair"); _piscar_centro()
	# XP e moeda são compartilhados: todo mundo ganha, não só quem acertou o golpe final
	moedas += moeda_ganha
	if player.roubo > 0.0 and player.hp > 0.0: player.hp = minf(player.max_hp, player.hp + player.roubo)
	if player.ult_t <= 0.0: player.ult = minf(1.0, player.ult + 1.0 / Dados.ULT_ABATES)
	if Rede.ativo():
		# XP é da EQUIPE e conta UMA vez (nada de cada um ganhar o seu): o cartão "XP" de cada jogador entra pela média
		var soma := 0.0; var n := 0
		for jj in jogadores_rede.values():
			if is_instance_valid(jj): soma += jj.xp_mult; n += 1
		_somar_xp_equipe(e.xp_val * (soma / maxf(1.0, n)))
		for id in jogadores_rede:
			if id != Rede.meu_id() and _peer_aqui(id): _premiar_abate.rpc_id(id, 0.0, moeda_ganha)
	else:
		spawn_firefly(e.global_position, e.xp_val)   # eu ando por cima do vaga-lume pra pegar o meu, como sempre foi
		enemies_por_net_id.erase(e.net_id)
		_remover_inimigo_rede.rpc(e.net_id)

func spawn_firefly(pos: Vector3, v: float) -> void:
	var f := MeshInstance3D.new()
	var sm := SphereMesh.new(); sm.radius = 0.12; sm.height = 0.24; f.mesh = sm
	sm.radial_segments = 6; sm.rings = 3
	f.material_override = Lib.mat(Color(1.0, 0.85, 0.2) if v < 5 else Color(1.0, 0.35, 0.2), 2.5)
	f.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	f.position = pos + Vector3(0, 0.3, 0); add_child(f)
	fireflies.append({"node": f, "v": v, "mag": false})

func _vaga_lumes(delta: float) -> void:
	_xp_combo_t -= delta
	if _xp_combo_t <= 0.0: _xp_combo = 0       # passou tempo sem coletar: a escala volta do início
	var pp: Vector3 = player.global_position
	for fr in fireflies.duplicate():
		var n: Node3D = fr["node"]
		if not is_instance_valid(n): fireflies.erase(fr); continue
		var to: Vector3 = pp - n.global_position; to.y = 0
		var d := to.length()
		if fr["mag"] or d < 2.6 * player.ima:
			fr["mag"] = true; n.global_position += to.normalized() * (6.0 + delta * 40.0) * delta
		n.position.y = Lib.h(n.position.x, n.position.z) + 0.45 + sin(time * 5.0 + n.position.x) * 0.1
		if d < 0.7:
			player.gain_xp(fr["v"]); n.queue_free(); fireflies.erase(fr)
			_xp_combo_t = 0.6
			Som.tocar("xp", -9.0, 0.0, 0.03, XP_ESCALA[mini(_xp_combo, XP_ESCALA.size() - 1)])
			_xp_combo += 1

func _ofertas(tipo: String) -> Array:
	if tipo == "bau": return player.ofertas(2, false)
	if tipo == "oratorio": return player.ofertas(1, true)
	if tipo == "contrabando": return player.ofertas(3, false)
	if tipo == "caminho": return player.ofertas(4, false)
	return player.ofertas()

# Empurra os bichos perto pra trás e dá um instante de respiro, SEM dano — é só a antecipação antes da
# carta aparecer (quebra de ritmo: o jogador sente que algo importante vai acontecer antes de ver o quê).
func _onda_antecipacao(centro: Vector3, raio: float = 5.0) -> void:
	for e in enemies.duplicate():
		if not is_instance_valid(e) or e.dead: continue
		var dd: Vector3 = e.global_position - centro; dd.y = 0
		var dist := dd.length()
		if dist <= raio and dist > 0.1:
			e.position += dd.normalized() * (raio - dist) * 0.35
			e.stun_t = maxf(e.stun_t, 0.15 if e.is_boss else 0.5)
	_efeito_anel(centro, raio, Color(1.0, 0.92, 0.7))
	tremor = maxf(tremor, 0.15)

# Abre a escolha de carta. Se já houver uma aberta, a nova espera na fila (nada se perde).
func abrir_escolha(tipo: String) -> void:
	var ficha := tipo.begins_with("lore:")
	if _teste_fim > 0.0:         # no auto-teste, pega uma carta sozinho
		if not ficha: player.aplicar_carta(_ofertas(tipo)[0])
		return
	if Rede.ativo() and not ficha:       # co-op: carta é uma RODADA (o anfitrião pára todo mundo até escolherem)
		_pedir_rodada.rpc_id(1, tipo); return
	if levelup_aberto or estado != "jogo":
		_fila.append(tipo); return
	levelup_aberto = true
	lbl_centro.text = ""
	if ficha:
		Som.tocar("carta"); menus.lore(tipo.substr(5)); _mouse(false); return
	if DisplayServer.get_name() != "headless":        # antecipação de 0.4s (onda + acorde) antes de revelar as cartas
		_onda_antecipacao(player.global_position)
		Som.tocar("nivel", -3.0, 0.1, 0.0)
		await get_tree().create_timer(0.4).timeout
		if estado != "jogo": levelup_aberto = false; return   # ele saiu/pausou durante a antecipação
	Som.tocar({"bau": "bau", "oratorio": "bencao", "contrabando": "loja", "caminho": "bencao"}.get(tipo, "nivel"))
	if tipo == "bau": Som.voz("v_bau")
	menus.nivel(player, _ofertas(tipo), tipo)
	_mouse(false)

func _escolher_carta(p: Jogador, card: Dictionary) -> void:
	var nome_carta: String = p.info_carta(card)["nome"]
	p.aplicar_carta(card)
	Som.tocar("carta")
	if card.get("rar", 0) == 5:
		lbl_centro.text = "CARTA MÍTICA!"; _piscar_centro(); Som.voz("v_mitica"); tremor = 0.6
	if Rede.ativo(): _avisar_carta_rede.rpc(Rede.meu_id(), nome_carta, p.level)
	menus.fechar()
	if Rede.ativo() and pausa_equipe:        # continua parado até TODOS escolherem; o anfitrião libera
		_rodada_pronto.rpc_id(1); _mostrar_espera([]); lbl_centro.text = tr("Escolhido! Esperando os outros…")
		return
	levelup_aberto = false
	if not _fila.is_empty():
		abrir_escolha(_fila.pop_front()); return
	_mouse(true)

# no co-op, quando o parceiro escolhe uma carta, mostra pra todo mundo flutuando em cima da cabeça dele
# (as cartas em si já chegam sozinhas pelos stats do Jogador, que já são sincronizados — isso aqui é só o aviso)
@rpc("any_peer", "call_remote", "reliable")
func _avisar_carta_rede(id: int, nome_carta: String, nivel: int) -> void:
	var j = jogadores_rede.get(id)
	if j == null or not is_instance_valid(j): return
	dano_num(j.global_position, tr("Nível %d: %s") % [nivel, nome_carta], Color(1.0, 0.9, 0.4), 32, true)

# ---------------- efeitos ----------------
func _efeito_anel(centro: Vector3, raio: float, cor: Color) -> void:
	_efeito_setor(centro, 0.0, raio, TAU, cor)

# Rastro do golpe: um leque (ou roda inteira) rente ao chão que abre e some.
func _efeito_setor(centro: Vector3, ang_dir: float, raio: float, abertura: float, cor: Color) -> void:
	if DisplayServer.get_name() == "headless": return
	var st := SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n := maxi(8, int(abertura / TAU * 44.0))
	var c_cor := Paleta.snap(cor)
	# três faixas como numa gravura: tinta por dentro, cor no meio, papel na borda; a borda de fora é serrilhada
	var faixas := [[0.50, 0.60, Paleta.TINTA], [0.60, 0.86, c_cor], [0.86, 1.0, Paleta.CREME]]
	for i in range(n):
		var a0 := ang_dir - abertura * 0.5 + abertura * i / n
		var a1 := ang_dir - abertura * 0.5 + abertura * (i + 1) / n
		var serra := 1.0 if i % 2 == 0 else 0.8
		for f in faixas:
			var r0: float = raio * f[0]; var r1: float = raio * f[1] * (serra if f[1] >= 0.86 else 1.0)
			if r1 <= r0: continue
			var p00 := Vector3(cos(a0) * r0, 0, sin(a0) * r0); var p01 := Vector3(cos(a0) * r1, 0, sin(a0) * r1)
			var p10 := Vector3(cos(a1) * r0, 0, sin(a1) * r0); var p11 := Vector3(cos(a1) * r1, 0, sin(a1) * r1)
			for p in [p00, p01, p11, p00, p11, p10]:
				st.set_color(f[2]); st.add_vertex(p)
	var m := MeshInstance3D.new(); m.mesh = st.commit()
	var mat := StandardMaterial3D.new(); mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true; mat.vertex_color_is_srgb = true; mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.material_override = mat; m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	m.position = Vector3(centro.x, Lib.h(centro.x, centro.z) + 0.55, centro.z); add_child(m)
	var tw := create_tween()
	tw.tween_property(m, "scale", Vector3(1.08, 1.0, 1.08), 0.24).from(Vector3(0.55, 1.0, 0.55))
	tw.parallel().tween_property(mat, "albedo_color:a", 0.0, 0.24).set_delay(0.08)
	tw.tween_callback(m.queue_free)

# Número de dano / aviso que sobe e some.
func dano_num(pos: Vector3, txt: String, cor: Color, tam: int = 40, forcar: bool = false) -> void:
	if DisplayServer.get_name() == "headless" or Tela.opc("numeros") < 0.5: return
	if _nums > (90 if forcar else 50): return
	_nums += 1
	var l := Label3D.new(); l.text = txt
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED; l.no_depth_test = true
	l.font = Tela.fonte(true); l.font_size = tam; l.pixel_size = 0.008; l.outline_size = 16
	l.modulate = cor; l.outline_modulate = Paleta.TINTA
	l.position = pos + Vector3(randf_range(-0.3, 0.3), 2.1, randf_range(-0.3, 0.3)); add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "position:y", l.position.y + 1.2, 0.55)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 0.3).set_delay(0.25)
	tw.parallel().tween_property(l, "outline_modulate:a", 0.0, 0.3).set_delay(0.25)      # o contorno some junto (senão sobra mancha preta)
	tw.tween_callback(_fim_num.bind(l))

func _fim_num(l: Node) -> void:
	_nums -= 1
	l.queue_free()

func popup(pos: Vector3, txt: String) -> void:
	dano_num(pos, tr(txt).to_upper() + "!", Color(1.0, 0.85, 0.2), 52)

# Estrela de impacto de gravura (ponta preta com miolo de papel), virada pra câmera, que estoura e some.
# estrela gravada (ponta de tinta + miolo colorido), em malha, virada pra câmera (billboard)
func _malha_estrela(raio: float, cor: Color, pontas: int = 9, picos: bool = true) -> MeshInstance3D:
	var st := SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for camada in range(2):
		var r_ext := raio * (1.0 if camada == 0 else 0.62); var r_int := r_ext * 0.45
		var col: Color = Paleta.TINTA if camada == 0 else (Paleta.snap(cor) if cor.get_luminance() < 0.8 else Paleta.CREME)
		for i in range(pontas):
			var a0 := i * TAU / pontas; var am := a0 + TAU / pontas * 0.5; var a1 := a0 + TAU / pontas
			var k0 := (0.75 if i % 2 else 1.0) if picos else 1.0
			var k1 := (0.75 if (i + 1) % 2 else 1.0) if picos else 1.0
			var po := Vector3(cos(a0) * r_ext * k0, sin(a0) * r_ext * k0, camada * 0.01)
			var pi := Vector3(cos(am) * r_int, sin(am) * r_int, camada * 0.01)
			var pn := Vector3(cos(a1) * r_ext * k1, sin(a1) * r_ext * k1, camada * 0.01)
			for v in [Vector3(0, 0, camada * 0.01), po, pi, Vector3(0, 0, camada * 0.01), pi, pn]:
				st.set_color(col); st.add_vertex(v)
	var m := MeshInstance3D.new(); m.mesh = st.commit()
	var mat := StandardMaterial3D.new(); mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true; mat.vertex_color_is_srgb = true; mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA; mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.material_override = mat; m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return m

func _estrela(pos: Vector3, raio: float, cor: Color) -> void:
	var m := _malha_estrela(raio, cor)
	m.position = pos + Vector3(0, 1.0, 0); add_child(m)
	var mat := m.material_override as StandardMaterial3D
	var tw := create_tween()
	tw.tween_property(m, "scale", Vector3.ONE, 0.16).from(Vector3(0.2, 0.2, 0.2)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.12)
	tw.tween_callback(m.queue_free)

const PALAVRAS_GOLPE := ["PÁ!", "TÁ!", "POF!", "ZÁS!", "TUM!", "TRÁS!"]
const PALAVRAS_CRIT := ["ZÁS-TRÁS!", "BUM!", "PAU!", "POW!", "ARRETADO!"]
var _impactos := 0
# IMPACTO DE CORDEL: estrela gravada com a onomatopeia em letra de folheto no meio ("PÁ!", "ZÁS!"), vermelha e maior no crítico,
# com riscos de choque saindo em volta. Tudo de papel e tinta, nada de partícula.
func impacto_gravado(pos: Vector3, crit: int = 0) -> void:
	if DisplayServer.get_name() == "headless" or _impactos > 22: return
	_impactos += 1
	var cor := Paleta.VERMELHO_CL if crit > 0 else Paleta.AMARELO_CL
	var c := pos + Vector3(randf_range(-0.25, 0.25), randf_range(0.0, 0.35), randf_range(-0.25, 0.25)) + Vector3(0, 1.0, 0)
	var raio := 0.62 + 0.38 * crit
	var m := _malha_estrela(raio, cor, 11 if crit > 0 else 9); m.position = c; add_child(m)
	# riscos de choque: traços finos de tinta saindo da estrela
	for k in range(8 if crit > 0 else 5):
		var ang := randf() * TAU
		var d := Vector3(cos(ang), sin(ang) * 0.8, 0.0)
		_traco_afilado(d * raio * 1.05, d * raio * (1.7 + randf() * 0.7), 0.05, Paleta.TINTA, m, false, true)
	var l := Label3D.new(); l.text = (PALAVRAS_CRIT if crit > 0 else PALAVRAS_GOLPE)[randi() % (PALAVRAS_CRIT.size() if crit > 0 else PALAVRAS_GOLPE.size())]
	l.font = Tela.fonte(true); l.font_size = 52 if crit > 0 else 38; l.pixel_size = 0.0105 if crit > 0 else 0.0085
	l.modulate = Paleta.TINTA; l.outline_modulate = Paleta.CREME; l.outline_size = 8
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED; l.no_depth_test = true; l.render_priority = 9; l.outline_render_priority = 8
	l.position = Vector3(0, 0.0, 0.02); m.add_child(l)
	m.rotation = Vector3.ZERO
	var tw := create_tween()
	tw.tween_property(m, "scale", Vector3.ONE, 0.12).from(Vector3(0.2, 0.2, 0.2)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_interval(0.16)
	tw.tween_callback(m.queue_free)
	get_tree().create_timer(0.34).timeout.connect(func(): _impactos -= 1)

# traço de gravura: começa grosso e AFILA até virar ponta (como entalhe de goiva). Deita no plano de `pai`.
func _traco_afilado(a: Vector3, b: Vector3, larg: float, cor: Color, pai: Node = null, chao: bool = false, billboard: bool = false) -> MeshInstance3D:
	var st := SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var dir := (b - a); var comp := dir.length()
	if comp < 0.01: return null
	dir = dir / comp
	var lado := Vector3(-dir.z, 0, dir.x) if chao else Vector3(-dir.y, dir.x, 0)
	if lado.length() < 0.01: lado = Vector3.UP
	lado = lado.normalized() * larg
	for v in [a + lado, a - lado, b, a + lado * 0.55 + dir * comp * 0.5, a - lado * 0.55 + dir * comp * 0.5, b]:
		st.set_color(cor); st.add_vertex(v)
	var m := MeshInstance3D.new(); m.mesh = st.commit()
	var mat := StandardMaterial3D.new(); mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true; mat.vertex_color_is_srgb = true; mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	if billboard: mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.material_override = mat; m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if pai: pai.add_child(m)
	else: add_child(m)
	return m

# RISCOS DE MOVIMENTO de xilogravura: feixe de traços AFILADOS (grosso perto do herói, ponta lá atrás), de tinta e de papel,
# rente ao chão, que se esticam e somem. Como as linhas de velocidade de um folheto de cordel.
func riscos_movimento(pos: Vector3, dir_atras: Vector3) -> void:
	if DisplayServer.get_name() == "headless": return
	var d := dir_atras; d.y = 0.0
	if d.length() < 0.1: return
	d = d.normalized()
	var lado := Vector3(-d.z, 0, d.x)
	var raiz := Node3D.new(); raiz.position = Vector3.ZERO; add_child(raiz)
	for k in range(7):
		var comp := randf_range(2.0, 3.8) * (1.0 - absf(k - 3) * 0.12)
		var off := lado * (k - 3) * 0.3
		var a := pos + off + d * 0.5 + Vector3(0, 0.18 + k * 0.012, 0)
		var m := _traco_afilado(a, a + d * comp, 0.07 + (0.05 if k % 2 == 0 else 0.0), Paleta.TINTA if k % 2 == 0 else Paleta.CREME, raiz, true)
		if m: m.position = Vector3.ZERO
	var tw := create_tween()
	tw.tween_property(raiz, "position", d * 1.6, 0.3).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(raiz, "scale", Vector3(1.0, 1.0, 1.0), 0.3)
	tw.tween_callback(raiz.queue_free)

# Estouro de cubinhos quando o bicho cai.
func _puff(pos: Vector3, cor: Color, esc: float) -> void:
	if DisplayServer.get_name() == "headless": return
	_estrela(pos, 0.9 * esc, cor)
	Lib.contorno_mundo = 0.03
	for i in range(6):
		var c := Lib.cx(self, Vector3(0.22, 0.22, 0.22) * esc, pos + Vector3(0, 0.9 * esc, 0), cor if i % 2 == 0 else Color(0.95, 0.92, 0.85))
		c.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var d := Vector3(randf_range(-1, 1), randf_range(0.6, 1.6), randf_range(-1, 1)) * 1.3 * esc
		var tw := create_tween()
		tw.tween_property(c, "position", c.position + d, 0.38).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
		tw.parallel().tween_property(c, "scale", Vector3(0.05, 0.05, 0.05), 0.38)
		tw.parallel().tween_property(c, "rotation", Vector3(randf() * 6.0, randf() * 6.0, 0), 0.38)
		tw.tween_callback(c.queue_free)
	Lib.contorno_mundo = 0.0

# ---------------- enfeites do cenário ----------------
func _montar_capim() -> void:
	var rng := RandomNumberGenerator.new(); rng.seed = 99
	var sh: Shader = load("res://shaders/tufo.gdshader")
	# tufos de capim: lâminas de tinta (preto na maioria, ocre e verde seco de vez em quando)
	var qm := QuadMesh.new(); qm.size = Vector2(0.9, 0.7); qm.center_offset = Vector3(0, 0.35, 0)
	var mm := MultiMesh.new(); mm.transform_format = MultiMesh.TRANSFORM_3D; mm.use_colors = true
	mm.mesh = qm; mm.instance_count = 6000
	for i in range(6000):
		var x := rng.randf_range(-ARENA - 10.0, ARENA + 10.0); var z := rng.randf_range(-ARENA - 10.0, ARENA + 10.0)
		var y := Lib.h(x, z)
		var e := 0.7 + rng.randf() * 1.0
		if y < -1.25: e = 0.001
		mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(e, e, e)), Vector3(x, y, z)))
		var sorte := rng.randf()
		mm.set_instance_color(i, Paleta.TINTA if sorte < 0.55 else (Paleta.TERRA_ESC if sorte < 0.75 else (Paleta.VERDE_ESC if sorte < 0.92 else Paleta.AMARELO)))
	var mat := ShaderMaterial.new(); mat.shader = sh; mat.set_shader_parameter("forma", 0)
	var mi := MultiMeshInstance3D.new(); mi.multimesh = mm; mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF; add_child(mi)
	# florzinhas: pontos de pigmento com filete preto
	var qf := QuadMesh.new(); qf.size = Vector2(0.34, 0.34); qf.center_offset = Vector3(0, 0.2, 0)
	var mf := MultiMesh.new(); mf.transform_format = MultiMesh.TRANSFORM_3D; mf.use_colors = true
	mf.mesh = qf; mf.instance_count = 1200
	var cores := [Paleta.VERMELHO_CL, Paleta.AMARELO_CL, Paleta.CREME, Paleta.ROSA, Paleta.AZUL_CL, Paleta.AMARELO]
	for i in range(1200):
		var x2 := rng.randf_range(-ARENA - 6.0, ARENA + 6.0); var z2 := rng.randf_range(-ARENA - 6.0, ARENA + 6.0)
		var y2 := Lib.h(x2, z2)
		var e2 := 0.8 + rng.randf() * 0.8
		if y2 < -1.25: e2 = 0.001
		mf.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(e2, e2, e2)), Vector3(x2, y2 + 0.05, z2)))
		mf.set_instance_color(i, cores[rng.randi() % cores.size()])
	var matf := ShaderMaterial.new(); matf.shader = sh; matf.set_shader_parameter("forma", 1)
	var mi2 := MultiMeshInstance3D.new(); mi2.multimesh = mf; mi2.material_override = matf
	mi2.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF; add_child(mi2)

func _montar_agua() -> void:
	var m := MeshInstance3D.new(); var pm := PlaneMesh.new(); pm.size = Vector2(200, 200); m.mesh = pm
	var mat := ShaderMaterial.new(); mat.shader = load("res://shaders/agua.gdshader")
	m.material_override = mat; m.position.y = -1.3
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF; add_child(m)

func _montar_nuvens() -> void:
	var rng := RandomNumberGenerator.new(); rng.seed = 5
	for i in range(18):
		var pos := Vector3(rng.randf_range(-130, 130), rng.randf_range(34, 50), rng.randf_range(-130, 130))
		var e := 2.0 + rng.randf() * 3.0
		if Gravador.disponivel():
			var c := Cartao.novo("@cenario:nuvem:%d" % (i % 3))
			c.position = pos; c.scale = Vector3.ONE * e * 1.1; add_child(c)
			continue
		var n := Node3D.new(); add_child(n); n.position = pos
		for k in range(4):
			var b := Lib.esf(n, e * (1.0 - k * 0.15), Vector3((k - 1.5) * e * 1.1, rng.randf() * e * 0.3, rng.randf_range(-1, 1) * e * 0.4), Paleta.CREME, Vector3(1.2, 0.6, 1), 6, 0.6)
			b.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

# Serras ao fundo, como bastidores de teatro de papel: recortes grandes de montanha atrás da mata.
func _montar_serras() -> void:
	if not Gravador.disponivel(): return
	var rng := RandomNumberGenerator.new(); rng.seed = 41
	for i in range(16):
		var a := i * TAU / 16.0 + rng.randf() * 0.18
		var r := 100.0 + rng.randf() * 8.0
		var x := cos(a) * r; var z := sin(a) * r
		var c := Cartao.novo("@cenario:serra:%d" % (i % 4))
		var e := 5.5 + rng.randf() * 3.0
		c.position = Vector3(x, Lib.h(cos(a) * 94.0, sin(a) * 94.0) - 3.0, z); c.scale = Vector3(e, e, e); add_child(c)

# o Gravador pede: monta o cenário `args[0]` (variante `args[1]`) pra tirar a gravura
func _gravar_cenario(args: Array) -> Node3D:
	var n := Node3D.new()
	var tipo := String(args[0]); var v := int(args[1]) if args.size() > 1 else 0
	var r := RandomNumberGenerator.new(); r.seed = 900 + v * 7 + tipo.length()
	Lib.contorno_mundo = 0.06
	match tipo:
		"nuvem":
			var e := 1.0
			for k in range(5):
				Lib.esf(n, e * (1.0 - absf(k - 2.0) * 0.18), Vector3((k - 2.0) * e * 0.95, r.randf() * e * 0.3 + (0.3 if k % 2 == 0 else 0.0), 0), Paleta.CREME, Vector3(1.15, 0.8, 1), 7)
			Lib.cx(n, Vector3(e * 4.6, e * 0.22, 0.6), Vector3(0, -e * 0.35, 0), Paleta.CREME)
		"serra":
			var alt := 6.0 + v * 1.4
			Lib.cil(n, 0.0, 5.2 + v, alt, Vector3(0, alt * 0.5, 0), Paleta.TERRA if v % 2 == 0 else Paleta.TERRA_ESC, 5)
			Lib.cil(n, 0.0, 4.0, alt * 0.7, Vector3(-4.6 - v * 0.4, alt * 0.35, 0.5), Paleta.TERRA_CL, 5)
			Lib.cil(n, 0.0, 3.4, alt * 0.55, Vector3(4.4 + v * 0.3, alt * 0.28, 0.5), Paleta.TERRA_ESC if v % 2 == 0 else Paleta.TERRA, 5)
			Lib.cil(n, 0.0, 1.4, alt * 0.22, Vector3(0.2, alt * 0.9, 0), Paleta.PAPEL, 5)       # cume claro
		"casa": _casa_montar(n)
		"cruzeiro": _cruzeiro_montar(n)
		"cranio": _cranio_montar(n)
		"cerca": _cerca_montar(n)
		"passaro":
			Lib.cx(n, Vector3(0.9, 0.07, 0.06), Vector3(-0.42, 0.12, 0), Paleta.TINTA, Vector3(0, 0, 0.5))
			Lib.cx(n, Vector3(0.9, 0.07, 0.06), Vector3(0.42, 0.12, 0), Paleta.TINTA, Vector3(0, 0, -0.5))
			Lib.esf(n, 0.1, Vector3(0, 0.0, 0), Paleta.TINTA, Vector3.ONE, 5)
		"bandeira":
			var cores := [Paleta.VERMELHO, Paleta.AMARELO, Paleta.VERDE, Paleta.AZUL, Paleta.ROSA, Paleta.TERRA_CL]
			var f := Lib.cil(n, 0.22, 0.0, 0.42, Vector3(0, 0.21, 0), cores[v % cores.size()], 4, Vector3(0, PI / 4.0, 0))
			f.scale = Vector3(1.0, 1.0, 0.25)
	Lib.contorno_mundo = 0.0
	return n

func _fio(a: Vector3, b: Vector3) -> void:
	var m := Lib.cx(self, Vector3(0.025, 0.025, a.distance_to(b)), (a + b) * 0.5, Color(0.2, 0.15, 0.1))
	m.look_at_from_position((a + b) * 0.5, b, Vector3.UP)
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

# Arraial de São João no meio do mapa: mastros com bandeirinhas e uma fogueira.
func _montar_arraial() -> void:
	Lib.contorno_mundo = 0.04
	_arraial_obj()
	Lib.contorno_mundo = 0.0

func _arraial_obj() -> void:
	var cores := [Color(0.9, 0.15, 0.15), Color(1.0, 0.82, 0.1), Color(0.15, 0.65, 0.3), Color(0.15, 0.45, 0.9), Color(0.98, 0.45, 0.7), Color(1.0, 0.5, 0.1)]
	var topos: Array = []
	for i in range(5):
		var a := i * TAU / 5.0 + 0.3
		var x := cos(a) * 8.5; var z := sin(a) * 8.5; var y := Lib.h(x, z)
		Lib.cil(self, 0.07, 0.1, 4.6, Vector3(x, y + 2.3, z), Color(0.5, 0.33, 0.18), 6)
		Lib.esf(self, 0.16, Vector3(x, y + 4.65, z), cores[i], Vector3.ONE, 6)
		troncos.append(Vector3(x, z, 0.15))
		topos.append(Vector3(x, y + 4.5, z))
	var k := 0
	for i in range(5):
		var A: Vector3 = topos[i]; var B: Vector3 = topos[(i + 1) % 5]
		var ant := A
		for j in range(1, 13):
			var t := j / 13.0
			var pt := A.lerp(B, t) - Vector3(0, sin(t * PI) * 0.9, 0)
			_fio(ant, pt); ant = pt
			# SEMPRE fixa (nunca vira pro boneco de papel/Cartao): bandeirinha é objeto de cenário preso no
			# varal, não personagem — virar pra câmera fazia todas ficarem de canto e se sobrepor quando
			# a câmera olhava quase de raspão pro varal (ficava um borrão tremido).
			var f := Lib.cil(self, 0.2, 0.0, 0.38, pt - Vector3(0, 0.21, 0), cores[k % cores.size()], 4)
			f.rotation.y = atan2(B.x - A.x, B.z - A.z) + PI / 4.0
			f.scale = Vector3(1, 1, 1)
			f.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			k += 1
		_fio(ant, B)
	# fogueira
	var fx := 3.6; var fz := -3.2; var fy := Lib.h(fx, fz)
	var base := Lib.pivo(self, Vector3(fx, fy, fz))
	for i in range(5):
		var a2 := i * TAU / 5.0
		Lib.cil(base, 0.11, 0.13, 1.5, Vector3(cos(a2) * 0.35, 0.55, sin(a2) * 0.35), Color(0.36, 0.22, 0.12), 6, Vector3(sin(a2) * 0.5, 0, -cos(a2) * 0.5))
	for i in range(7):
		var a3 := i * TAU / 7.0
		Lib.esf(base, 0.2, Vector3(cos(a3) * 0.85, 0.08, sin(a3) * 0.85), Color(0.55, 0.55, 0.52), Vector3(1, 0.7, 1), 5)
	fogo = Lib.pivo(base, Vector3(0, 0.3, 0))
	Lib.cil(fogo, 0.0, 0.5, 1.5, Vector3(0, 0.75, 0), Color(1.0, 0.35, 0.05), 6, Vector3.ZERO, 2.0).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Lib.cil(fogo, 0.0, 0.32, 1.1, Vector3(0.1, 0.6, 0.05), Color(1.0, 0.7, 0.1), 5, Vector3.ZERO, 2.5).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Lib.cil(fogo, 0.0, 0.18, 0.7, Vector3(-0.08, 0.45, -0.05), Color(1.0, 0.95, 0.5), 5, Vector3.ZERO, 3.0).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var luz := OmniLight3D.new(); luz.light_color = Color(1.0, 0.55, 0.2); luz.light_energy = 2.5; luz.omni_range = 9.0
	luz.position = Vector3(0, 1.3, 0); base.add_child(luz)
	troncos.append(Vector3(fx, fz, 0.9))

const COR_PAU := Color(0.45, 0.3, 0.16)
# ---------------- potes, baús e oratórios ----------------
func _pos_livre(rmin: float, rmax: float) -> Vector3:
	for i in range(30):
		var a := randf() * TAU; var d := randf_range(rmin, rmax)
		var x := cos(a) * d; var z := sin(a) * d
		if Lib.h(x, z) > -0.9: return Vector3(x, Lib.h(x, z), z)
	return Vector3(6, Lib.h(6, 6), 6)

func _montar_objetos() -> void:
	for i in range(14): _novo_objeto("pote", _pos_livre(6.0, ARENA - 4.0), 0)
	for i in range(3): _novo_objeto("oratorio", _pos_livre(14.0, ARENA - 6.0), 0)
	for i in range(4): _novo_objeto("bau", _pos_livre(10.0, ARENA - 5.0), 1)
	_novo_objeto("loja", _pos_livre(12.0, ARENA - 8.0), 0)
	_novo_objeto("portal", _pos_livre(16.0, ARENA - 8.0), 0)
	var gente: Array = Dados.NPCS.keys(); gente.shuffle()
	var so_um := OS.get_cmdline_user_args().find("--npc")
	if so_um >= 0: gente = [OS.get_cmdline_user_args()[so_um + 1]]
	var qtd_gente := 1 if so_um >= 0 else randi_range(1, 2)   # só 1 ou 2 por partida, não um grupo fixo sempre no mapa
	for i in range(mini(qtd_gente, gente.size())): _novo_objeto(gente[i], _pos_livre(12.0, ARENA - 8.0), 0)
	if Dados.FASES[fase].get("cristo", false): _montar_cristo()

# custo 0 = baú de graça (caiu de elite ou de chefe); custo 1 = trancado, paga com as moedas da partida
# net_id = -1 quando é um objeto novo de verdade (decide replicar pro co-op se eu for o anfitrião);
# vem preenchido quando é o anfitrião me mandando o objeto dele por RPC (aí eu só construo, não replico de novo)
# troca as peças 3D de um objeto do mapa por uma figura de papel (luzes e rótulos continuam como estavam)
func _objeto_cartao(n: Node3D, chave: String) -> void:
	if not Gravador.disponivel(): return
	if not Gravador.moldes.has(chave):
		var molde := Node3D.new()
		for c in n.get_children():
			if c is MeshInstance3D: molde.add_child(c.duplicate())
		Gravador.moldes[chave] = molde
	var card := Cartao.novo("@objeto:" + chave)
	for c in n.get_children():
		if c is MeshInstance3D: c.queue_free()
	n.add_child(card)

func _novo_objeto(tipo: String, pos: Vector3, custo: int, net_id: int = -1) -> void:
	Lib.contorno_mundo = 0.05
	var n := Node3D.new(); n.position = Vector3(pos.x, Lib.h(pos.x, pos.z), pos.z); add_child(n)
	var o := {"tipo": tipo, "no": n, "custo": custo, "carga": 0.0, "usado": false, "aviso": 0.0, "lbl": null, "vida_npc": -1.0}
	if Dados.NPCS.has(tipo): o["vida_npc"] = randf_range(50.0, 85.0)   # gente do mapa não fica pra sempre: some depois de um tempo
	match tipo:
		"pote":
			Lib.esf(n, 0.42, Vector3(0, 0.4, 0), Color(0.78, 0.42, 0.22), Vector3(1, 1.15, 1), 7)
			Lib.cil(n, 0.2, 0.26, 0.2, Vector3(0, 0.88, 0), Color(0.66, 0.33, 0.17), 7)
			Lib.cil(n, 0.43, 0.43, 0.07, Vector3(0, 0.45, 0), Color(0.95, 0.9, 0.78), 7)
		"bau":
			var mad := Color(0.5, 0.3, 0.14) if custo > 0 else Color(0.75, 0.2, 0.15)
			Lib.cx(n, Vector3(1.1, 0.6, 0.75), Vector3(0, 0.32, 0), mad)
			Lib.cx(n, Vector3(1.16, 0.26, 0.8), Vector3(0, 0.72, 0), mad.darkened(0.2))
			Lib.cx(n, Vector3(0.16, 0.9, 0.82), Vector3(-0.36, 0.45, 0), Color(1.0, 0.8, 0.2))
			Lib.cx(n, Vector3(0.16, 0.9, 0.82), Vector3(0.36, 0.45, 0), Color(1.0, 0.8, 0.2))
			Lib.cx(n, Vector3(0.2, 0.22, 0.1), Vector3(0, 0.58, 0.4), Color(1.0, 0.85, 0.3), Vector3.ZERO, 1.5)
			n.rotation.y = randf() * TAU
			o["lbl"] = _placa(n, 1.7, Color(1.0, 0.85, 0.3))
		"oratorio":
			Lib.cx(n, Vector3(1.3, 0.3, 1.3), Vector3(0, 0.15, 0), Color(0.6, 0.6, 0.58))
			Lib.cx(n, Vector3(0.9, 1.3, 0.8), Vector3(0, 0.95, 0), Color(0.96, 0.95, 0.9))
			Lib.cil(n, 0.0, 0.8, 0.7, Vector3(0, 1.95, 0), Color(0.15, 0.4, 0.75), 4)
			Lib.cx(n, Vector3(0.5, 0.7, 0.1), Vector3(0, 0.9, 0.38), Color(0.2, 0.25, 0.45))
			Lib.cx(n, Vector3(0.08, 0.45, 0.08), Vector3(0, 2.5, 0), Color(1.0, 0.85, 0.3)); Lib.cx(n, Vector3(0.28, 0.08, 0.08), Vector3(0, 2.56, 0), Color(1.0, 0.85, 0.3))
			Lib.esf(n, 0.12, Vector3(0, 0.95, 0.5), Color(1.0, 0.8, 0.3), Vector3(1, 1.5, 1), 5, 3.0)
			var luz := OmniLight3D.new(); luz.light_color = Color(0.6, 0.85, 1.0); luz.light_energy = 1.6; luz.omni_range = 6.0; luz.position = Vector3(0, 1.6, 0); n.add_child(luz)
			o["luz"] = luz
			o["lbl"] = _placa(n, 3.2, Color(0.7, 0.92, 1.0)); o["lbl"].text = tr("ORATÓRIO\nfique perto")
			troncos.append(Vector3(pos.x, pos.z, 0.6))
		"zepilintra":   # mesa de bar com Seu Zé ao lado
			Lib.cil(n, 0.7, 0.7, 0.08, Vector3(0.9, 0.85, 0), Color(0.5, 0.32, 0.18), 10)
			Lib.cil(n, 0.07, 0.1, 0.85, Vector3(0.9, 0.42, 0), Color(0.3, 0.2, 0.12), 6)
			Lib.cil(n, 0.07, 0.08, 0.3, Vector3(0.75, 1.04, 0.1), Color(0.25, 0.5, 0.25), 6)
			Lib.cx(n, Vector3(0.12, 0.12, 0.12), Vector3(1.1, 0.95, -0.1), Color.WHITE); Lib.cx(n, Vector3(0.12, 0.12, 0.12), Vector3(0.95, 0.95, 0.25), Color.WHITE, Vector3(0, 0.6, 0))
			var bz := Boneco.criar("zepilintra"); n.add_child(bz); bz.position = Vector3(-0.3, 0, 0)
			o["lbl"] = _placa(n, 2.9, Color.WHITE); o["lbl"].text = tr(String(Dados.NPCS[tipo]["lugar"]))
			n.rotation.y = atan2(-pos.x, -pos.z)
		"pombagira":    # encruzilhada com velas
			Lib.cx(n, Vector3(5.0, 0.04, 1.0), Vector3(0, 0.05, 0), Color(0.45, 0.33, 0.22)); Lib.cx(n, Vector3(1.0, 0.04, 5.0), Vector3(0, 0.06, 0), Color(0.45, 0.33, 0.22))
			for i in range(4):
				var av := i * TAU / 4.0 + 0.78
				Lib.cil(n, 0.05, 0.05, 0.3, Vector3(cos(av) * 1.1, 0.2, sin(av) * 1.1), Color(0.85, 0.1, 0.12), 6)
				Lib.esf(n, 0.06, Vector3(cos(av) * 1.1, 0.42, sin(av) * 1.1), Color(1.0, 0.8, 0.3), Vector3(1, 1.5, 1), 5, 3.0)
			var bp := Boneco.criar("pombagira"); n.add_child(bp)
			var lg := OmniLight3D.new(); lg.light_color = Color(1.0, 0.3, 0.3); lg.light_energy = 1.6; lg.omni_range = 6.0; lg.position = Vector3(0, 1.6, 0); n.add_child(lg)
			o["lbl"] = _placa(n, 2.9, Color(1.0, 0.45, 0.45)); o["lbl"].text = tr(String(Dados.NPCS[tipo]["lugar"]))
			n.rotation.y = atan2(-pos.x, -pos.z)
		"pretovelho", "baiana", "repentista", "vaqueiro":
			var bn := Boneco.criar(tipo); n.add_child(bn)
			match tipo:
				"pretovelho":
					Lib.cil(n, 0.3, 0.26, 0.4, Vector3(-0.9, 0.2, 0), Color(0.5, 0.33, 0.18), 8)                          # banquinho
					Lib.esf(n, 0.25, Vector3(-0.9, 0.2, 0.7), Color(0.25, 0.55, 0.25), Vector3(1, 0.8, 1), 6)             # ervas
				"baiana":
					Lib.cx(n, Vector3(1.4, 0.08, 0.8), Vector3(1.0, 0.8, 0), Color(0.6, 0.4, 0.22))                       # tabuleiro
					Lib.cx(n, Vector3(0.06, 0.8, 0.06), Vector3(0.4, 0.4, 0.3), COR_PAU); Lib.cx(n, Vector3(0.06, 0.8, 0.06), Vector3(1.6, 0.4, -0.3), COR_PAU)
					for k in range(5): Lib.esf(n, 0.12, Vector3(0.6 + k * 0.2, 0.92, 0.1 * (k % 2)), Color(0.85, 0.5, 0.15), Vector3(1, 0.7, 1), 6)
					Lib.cil(n, 0.2, 0.16, 0.2, Vector3(1.45, 0.94, -0.15), Color(0.2, 0.2, 0.22), 8)
				"repentista":
					Lib.cil(n, 0.28, 0.26, 0.45, Vector3(-0.9, 0.22, 0), Color(0.5, 0.33, 0.18), 8)
					Lib.cx(n, Vector3(0.5, 0.02, 0.35), Vector3(0.9, 0.03, 0.4), Color(0.9, 0.82, 0.6)); Lib.cx(n, Vector3(0.5, 0.02, 0.35), Vector3(1.1, 0.04, 0.1), Color(0.95, 0.6, 0.6), Vector3(0, 0.5, 0))
				"vaqueiro":
					for k in range(3): Lib.cil(n, 0.06, 0.07, 1.2, Vector3(1.0 + k * 0.9, 0.6, 0), COR_PAU, 5)
					Lib.cx(n, Vector3(2.0, 0.07, 0.07), Vector3(1.9, 0.9, 0), COR_PAU); Lib.cx(n, Vector3(2.0, 0.07, 0.07), Vector3(1.9, 0.5, 0), COR_PAU)
			o["lbl"] = _placa(n, 2.9, Color.WHITE); o["lbl"].text = tr(String(Dados.NPCS[tipo]["lugar"]))
			n.rotation.y = atan2(-pos.x, -pos.z)
		"portal":
			for i in range(8):
				var a := i * TAU / 8.0
				Lib.esf(n, 0.35, Vector3(cos(a) * 1.5, 0.2, sin(a) * 1.5), Color(0.4, 0.38, 0.45), Vector3(1, 0.8 + (i % 3) * 0.5, 1), 5)
			Lib.cil(n, 1.3, 1.3, 0.06, Vector3(0, 0.12, 0), Color(0.55, 0.2, 0.9), 16, Vector3.ZERO, 2.5)
			Lib.cil(n, 0.8, 0.8, 0.08, Vector3(0, 0.16, 0), Color(0.85, 0.5, 1.0), 12, Vector3.ZERO, 3.5)
			var lp := OmniLight3D.new(); lp.light_color = Color(0.7, 0.35, 1.0); lp.light_energy = 2.4; lp.omni_range = 7.0; lp.position = Vector3(0, 1.4, 0); n.add_child(lp)
			o["lbl"] = _placa(n, 2.6, Color(0.85, 0.6, 1.0)); o["lbl"].text = tr("PORTAL DA CUCA\nentre se tiver coragem")
		"loja":
			for sx in [-1.0, 1.0]:
				for sz in [-1.0, 1.0]: Lib.cil(n, 0.08, 0.1, 2.6, Vector3(sx * 1.5, 1.3, sz * 1.1), Color(0.45, 0.3, 0.16), 6)
			for k in range(6): Lib.cx(n, Vector3(0.56, 0.1, 2.7), Vector3(-1.4 + k * 0.56, 2.65 + (0.05 if k % 2 == 0 else 0.0), 0), Color(0.8, 0.18, 0.12) if k % 2 == 0 else Color(0.96, 0.9, 0.75))
			Lib.cx(n, Vector3(2.9, 0.9, 0.5), Vector3(0, 0.45, -0.9), Color(0.55, 0.36, 0.2))
			Lib.esf(n, 0.16, Vector3(-0.8, 1.05, -0.9), Color(0.85, 0.6, 0.2), Vector3.ONE, 6); Lib.esf(n, 0.16, Vector3(-0.45, 1.05, -0.9), Color(0.6, 0.25, 0.15), Vector3.ONE, 6)
			Lib.cil(n, 0.1, 0.12, 0.35, Vector3(0.7, 1.07, -0.9), Color(0.3, 0.55, 0.3), 6)
			Lib.esf(n, 0.14, Vector3(1.3, 2.2, 0.9), Color(1.0, 0.8, 0.3), Vector3(1, 1.4, 1), 6, 3.0)
			var lz := OmniLight3D.new(); lz.light_color = Color(1.0, 0.75, 0.35); lz.light_energy = 2.0; lz.omni_range = 7.0; lz.position = Vector3(0, 2.0, 0); n.add_child(lz)
			o["lbl"] = _placa(n, 3.5, Color(1.0, 0.8, 0.3)); o["lbl"].text = tr("BODEGA DO\nLAMPIÃO")
			n.rotation.y = atan2(-pos.x, -pos.z)
	Lib.contorno_mundo = 0.0
	match tipo:
		"pote", "oratorio", "loja", "pretovelho", "baiana", "repentista", "vaqueiro", "zepilintra": _objeto_cartao(n, tipo)
		"bau": _objeto_cartao(n, "bau_c" if custo > 0 else "bau_g")
	if net_id >= 0:
		o["net_id"] = net_id; objetos_por_net_id[net_id] = o
	elif Rede.ativo() and Rede.sou_host():
		_proximo_net_id_objeto += 1
		o["net_id"] = _proximo_net_id_objeto; objetos_por_net_id[_proximo_net_id_objeto] = o
		_spawnar_objeto_rede.rpc(_proximo_net_id_objeto, tipo, pos, custo)
	objetos.append(o)
	_placas_bau()

@rpc("authority", "call_remote", "reliable")
func _spawnar_objeto_rede(net_id: int, tipo: String, pos: Vector3, custo: int) -> void:
	if Rede.sou_host(): return
	_novo_objeto(tipo, pos, custo, net_id)

# o anfitrião é quem decide quando um objeto compartilhado some (pote pego, baú aberto, portal usado, gente que foi embora)
func _remover_objeto_rede_todos(net_id: int) -> void:
	if Rede.ativo() and Rede.sou_host(): _remover_objeto_rede.rpc(net_id)
	_remover_objeto_local(net_id)

func _remover_objeto_local(net_id: int) -> void:
	var o = objetos_por_net_id.get(net_id)
	objetos_por_net_id.erase(net_id)
	if o == null: return
	objetos.erase(o)
	if is_instance_valid(o["no"]): o["no"].queue_free()

# tira o objeto do mapa — se tiver net_id (co-op), avisa todo mundo; senão (sozinho) só remove na hora
func _remover_objeto(o: Dictionary) -> void:
	if o.has("net_id"): _remover_objeto_rede_todos(o["net_id"])
	else:
		objetos.erase(o)
		if is_instance_valid(o["no"]): o["no"].queue_free()

@rpc("authority", "call_remote", "reliable")
func _remover_objeto_rede(net_id: int) -> void:
	_remover_objeto_local(net_id)

# pro oratório: ele não some (fica o altar), só fica "usado" (sem a placa/luz) pra todo mundo ver
func _marcar_objeto_usado_rede_todos(net_id: int) -> void:
	if Rede.ativo() and Rede.sou_host(): _marcar_objeto_usado_rede.rpc(net_id)
	_marcar_objeto_usado_local(net_id)

func _marcar_objeto_usado_local(net_id: int) -> void:
	var o = objetos_por_net_id.get(net_id)
	if o == null: return
	o["usado"] = true
	if o.get("lbl"): o["lbl"].text = ""
	if o.get("luz"): o["luz"].light_energy = 0.0

@rpc("authority", "call_remote", "reliable")
func _marcar_objeto_usado_rede(net_id: int) -> void:
	_marcar_objeto_usado_local(net_id)

func _placa(pai: Node3D, alt: float, cor: Color) -> Label3D:
	var l := Label3D.new(); l.billboard = BaseMaterial3D.BILLBOARD_ENABLED; l.font = Tela.fonte(true)
	# letra e contorno bem mais grossos: de longe, o filtro de pixelização "comia" partes finas e ficava ilegível
	l.font_size = 64; l.pixel_size = 0.0072; l.outline_size = 18; l.modulate = cor; l.outline_modulate = Color(0.1, 0.07, 0.05)
	l.position = Vector3(0, alt, 0); pai.add_child(l)
	return l

func _placas_bau() -> void:
	for o in objetos:
		if o["tipo"] == "bau": o["lbl"].text = tr("BAÚ\n◉ %d") % bau_custo if o["custo"] > 0 else tr("BAÚ\nde graça")

func _objetos(delta: float) -> void:
	var pp: Vector3 = player.global_position
	var potes := 0
	for o in objetos.duplicate():
		var n: Node3D = o["no"]
		var d := Vector2(n.position.x - pp.x, n.position.z - pp.z).length()
		match o["tipo"]:
			"pote":
				potes += 1
				if d < 1.15 and player.alt < 0.9:
					_puff(n.position, Color(0.78, 0.42, 0.22), 1.0); Som.tocar("pote")
					var sorte := randf()
					if sorte < 0.3: player.curar(player.max_hp * 0.15)
					elif sorte < 0.4:
						for fr in fireflies: fr["mag"] = true
						dano_num(n.position, "LAMPARINA!", Color(0.6, 0.9, 1.0), 50, true)
					else:
						var v := randi_range(3, 6); moedas += v; Som.tocar("moeda", -4.0)
						dano_num(n.position, tr("◉ +%d") % v, Color(1.0, 0.85, 0.3), 46, true)
					_remover_objeto(o)
			"bau":
				n.scale = Vector3.ONE * (1.0 + 0.05 * sin(time * 5.0))
				o["aviso"] = maxf(0.0, o["aviso"] - delta)
				if d < 1.5:
					var preco: int = bau_custo if o["custo"] > 0 else 0
					if moedas >= preco:
						moedas -= preco
						if o["custo"] > 0: bau_custo += 15
						Salvo.contar("baus")
						_puff(n.position, Color(1.0, 0.8, 0.2), 1.6); _efeito_anel(n.position, 3.0, Color(1.0, 0.85, 0.3)); tremor = maxf(tremor, 0.25)
						_remover_objeto(o); _placas_bau()
						abrir_escolha("bau")
					elif o["aviso"] <= 0.0:
						o["aviso"] = 1.5; dano_num(n.position, tr("faltam ◉ %d") % int(ceil(preco - moedas)), Color(1.0, 0.5, 0.4), 44, true)
			"portal":
				n.rotation.y += delta * 1.5
				if d < 1.4:
					_puff(n.position, Color(0.7, 0.35, 1.0), 2.0); _efeito_anel(n.position, 5.0, Color(0.7, 0.35, 1.0)); tremor = 0.6
					var pos_p: Vector3 = n.position
					_remover_objeto(o)
					if Rede.ativo() and not Rede.sou_host(): _pedir_cuca_rede.rpc_id(1, pos_p)
					else: _cuca(pos_p)   # sozinho, ou anfitrião: eu mesmo faço nascer a Cuca (só o anfitrião tem autoridade pra replicar bicho)
			"loja":
				if d > 4.5: o["usado"] = false
				elif d < 2.4 and not o["usado"]:
					o["usado"] = true; abrir_loja()
			"zepilintra", "pombagira", "pretovelho", "baiana", "repentista", "vaqueiro":
				if d > 4.5: o["usado"] = false
				elif d < 2.2 and not o["usado"]:
					o["usado"] = true; abrir_npc(o["tipo"])
				# só o anfitrião decide quando a gente do mapa vai embora, pra não sumir num PC e continuar no outro
				if (not Rede.ativo() or Rede.sou_host()) and o["vida_npc"] > 0.0 and d > 3.0:
					o["vida_npc"] -= delta
					if o["vida_npc"] <= 0.0:
						_puff(n.position, Color(0.85, 0.85, 0.95), 1.4)
						_remover_objeto(o)
			"oratorio":
				if o["usado"]: continue
				if d < 3.2:
					o["carga"] += delta
					o["lbl"].text = tr("ORATÓRIO\n%d%%") % int(o["carga"] / 4.0 * 100.0)
					if o["carga"] >= 4.0:
						o["usado"] = true; o["lbl"].text = ""; o["luz"].light_energy = 0.0
						if o.has("net_id"): _marcar_objeto_usado_rede_todos(o["net_id"])
						Salvo.contar("oratorios")
						_efeito_anel(n.position, 4.0, Color(0.6, 0.9, 1.0)); _efeito_anel(n.position, 2.4, Color.WHITE)
						abrir_escolha("oratorio")
				elif o["carga"] > 0.0:
					o["carga"] = maxf(0.0, o["carga"] - delta * 2.0)
					o["lbl"].text = tr("ORATÓRIO\nfique perto")
	if potes < 14:
		_pote_t -= delta
		if _pote_t <= 0.0:
			_pote_t = 20.0; _novo_objeto("pote", _pos_livre(6.0, ARENA - 4.0), 0)

# ---------------- Bodega do Lampião ----------------
func loja_preco(id: String) -> int:
	return int(loja_precos.get(id, 0))

func _golpe_fraco():
	var m = null
	for g in player.golpes:
		if g["nivel"] < Dados.NIVEL_MAX and (m == null or g["nivel"] < m["nivel"]): m = g
	return m

func loja_pode(id: String) -> bool:
	if moedas < loja_preco(id): return false
	match id:
		"pacto": return not pacto_feito
		"amolar": return _golpe_fraco() != null
		"troca": return player.cartas_stat.size() > 0
		"cura": return player.hp < player.max_hp
	return true

func abrir_loja() -> void:
	if _teste_fim > 0.0 or levelup_aberto or estado != "jogo": return
	levelup_aberto = true; lbl_centro.text = ""
	Som.tocar("loja")
	menus.loja(); _mouse(false)

func fechar_loja() -> void:
	if not menus.tela in ["loja", "lore", "npc"]: return
	menus.fechar(); levelup_aberto = false
	if not _fila.is_empty():
		abrir_escolha(_fila.pop_front()); return
	_mouse(true)

func comprar_loja(id: String) -> void:
	if not loja_pode(id): return
	moedas -= loja_preco(id); Som.tocar("moeda")
	for it in Dados.LOJA:
		if it["id"] == id: loja_precos[id] = loja_preco(id) + int(it["sobe"])
	match id:
		"carta":
			_fila.push_front("contrabando"); fechar_loja(); return
		"troca":
			var n := player.troca_troca()
			lbl_centro.text = tr("TROCA-TROCA!\n%d cartas sorteadas de novo") % n; _piscar_centro()
		"amolar":
			var g = _golpe_fraco(); g["nivel"] += 1
			lbl_centro.text = tr("%s subiu para o nível %d") % [tr(String(Dados.GOLPES[g["id"]]["nome"])), g["nivel"]]; _piscar_centro()
		"cura": player.curar(player.max_hp)
		"ima":
			for fr in fireflies: fr["mag"] = true
		"pacto":
			pacto_feito = true; player.dano_mult += 0.4
			player.max_hp = maxf(20.0, player.max_hp * 0.75); player.hp = minf(player.hp, player.max_hp)
	menus.loja()

# ---------------- Seu Zé Pilintra e Pomba Gira ----------------
var npc_precos := {}
func abrir_npc(tipo: String) -> void:
	if _teste_fim > 0.0 or levelup_aberto or estado != "jogo": return
	levelup_aberto = true; lbl_centro.text = ""
	Som.tocar("bencao")
	var fala := int(Salvo.d["falas"].get(tipo, 0))          # a cada encontro, uma fala diferente
	Salvo.d["falas"][tipo] = fala + 1
	menus.npc(tipo, fala); _mouse(false)

func npc_preco(id: String, base: int) -> int:
	return int(npc_precos.get(id, base))

func npc_pode(id: String) -> bool:
	match id:
		"pomba": return player.pombas < 4
		"gole", "frio", "quente": return player.hp < player.max_hp or id == "quente"
		"mote": return player.cartas_stat.size() > 0
	return true

func npc_comprar(tipo: String, it: Dictionary, preco: int, fala: int) -> void:
	var id: String = it["id"]
	if moedas < preco or npc_feito.has(id) or not npc_pode(id): return
	moedas -= preco; Som.tocar("moeda")
	if it.get("vez", false): npc_feito[id] = true
	npc_precos[id] = preco + int(it.get("sobe", 0))
	var p := player
	match id:
		"dados":
			if randf() < 0.5:
				moedas += 50; lbl_centro.text = "DEU SORTE!\n◉ +50"; Som.tocar("bau")
			else: lbl_centro.text = "Hoje não, malandro."
			_piscar_centro()
		"guarda": p.segunda_chance = true
		"gole": p.curar(p.max_hp * 0.35)
		"rosa": p.crit += 0.10; p.crit_dano += 0.30
		"pomba": p.pombas += 1
		"caminho":
			praga *= 1.15; _fila.push_front("caminho"); fechar_loja(); return
		"benzer": p.regen += 1.5
		"conselho": p.gain_xp((p.xp_next - p.xp) / p.xp_mult + 0.01)
		"arruda": p.armor += 0.10
		"quente": p.curar(p.max_hp * 0.5); p.dano_mult += 0.10
		"frio": p.curar(p.max_hp * 0.5)
		"cocada": p.max_hp += 25.0; p.hp += 25.0
		"folheto":
			_fila.push_front("bau"); fechar_loja(); return
		"verso": p.atk_speed += 0.15
		"mote":
			lbl_centro.text = tr("MOTE NOVO!\n%d cartas sorteadas de novo") % p.troca_troca(); _piscar_centro()
		"gibao": p.armor += 0.12
		"aboio":
			for fr in fireflies: fr["mag"] = true
		"espora": p.speed *= 1.12
	if menus.tela == "npc": menus.npc(tipo, fala)

func seu_ze_segurou() -> void:
	_ze_n += 1
	lbl_centro.text = "SEU ZÉ TE SEGUROU!\nLevanta, que ainda tem jogo"; _piscar_centro()
	Som.tocar("bencao"); tremor = 0.5
	_ring(player.global_position, 6.0, 40.0 * _escala_hab(player), 1.5, 3.0)
	_efeito_anel(player.global_position, 6.0, Color.WHITE)

# Pomba Girando: pombas brancas em órbita que bicam quem encostar
func _pombas_girando(delta: float) -> void:
	var p := player
	while _pombas.size() < p.pombas:
		var n := Node3D.new(); add_child(n)
		Lib.esf(n, 0.2, Vector3.ZERO, Color.WHITE, Vector3(1, 0.9, 1.4), 6, 0.4)
		Lib.esf(n, 0.12, Vector3(0, 0.12, 0.26), Color.WHITE, Vector3.ONE, 5, 0.4)
		Lib.cx(n, Vector3(0.7, 0.03, 0.22), Vector3(0, 0.05, 0), Color(0.92, 0.92, 0.96))
		Lib.cil(n, 0.0, 0.03, 0.1, Vector3(0, 0.1, 0.4), Color(1.0, 0.6, 0.1), 4, Vector3(PI / 2.0, 0, 0))
		_pombas.append(n)
	if _pombas.is_empty(): return
	_pomba_a += delta * 3.2; _pomba_t -= delta
	var bica := _pomba_t <= 0.0
	if bica: _pomba_t = 0.35
	for i in range(_pombas.size()):
		var a := _pomba_a + i * TAU / _pombas.size()
		var n2: Node3D = _pombas[i]
		n2.position = p.global_position + Vector3(cos(a) * 2.8, 1.1 + 0.2 * sin(a * 2.0), sin(a) * 2.8)
		n2.rotation.y = -a
		if bica:
			for e in enemies.duplicate():
				if not is_instance_valid(e) or e.dead: continue
				var dd: Vector3 = e.global_position - n2.position; dd.y = 0
				if dd.length() < 1.1 + e.raio:
					_dano_pombas += 9.0 * _escala_hab(p); ferir(e, 9.0 * _escala_hab(p))

# Cristo Redentor no alto do morro, de braços abertos sobre a fase do Corcovado
func _montar_cristo() -> void:
	var pedra := Color(0.95, 0.94, 0.9); var sombra := Color(0.8, 0.8, 0.78)
	var n := Node3D.new(); n.position = Vector3(0, 6.0, -ARENA - 16.0); n.scale = Vector3(1.9, 1.9, 1.9); add_child(n)
	Lib.esf(n, 9.0, Vector3(0, -4.0, 0), Color(0.36, 0.42, 0.34), Vector3(1.4, 0.8, 1.2), 7)        # o morro
	Lib.cx(n, Vector3(4.2, 3.2, 4.2), Vector3(0, 4.2, 0), sombra)                                   # pedestal
	Lib.cil(n, 1.5, 2.3, 9.0, Vector3(0, 10.3, 0), pedra, 8)                                        # manto
	Lib.cx(n, Vector3(15.0, 1.5, 1.6), Vector3(0, 13.6, 0), pedra)                                  # braços abertos
	Lib.cx(n, Vector3(3.6, 2.4, 1.9), Vector3(0, 13.2, 0), pedra)
	for sx in [-1.0, 1.0]:
		Lib.cx(n, Vector3(1.5, 3.2, 1.7), Vector3(5.6 * sx, 12.4, 0), sombra)                       # mangas caindo
		Lib.cx(n, Vector3(1.0, 0.6, 1.0), Vector3(7.9 * sx, 13.6, 0), pedra)                        # mãos
	Lib.esf(n, 1.3, Vector3(0, 15.9, 0.1), pedra, Vector3(0.9, 1.1, 0.95), 8)                       # cabeça
	Lib.cx(n, Vector3(1.4, 1.2, 0.7), Vector3(0, 15.2, 0.6), sombra)                                # barba
	var luz := OmniLight3D.new(); luz.light_color = Color(1.0, 0.95, 0.8); luz.light_energy = 3.0; luz.omni_range = 26.0; luz.position = Vector3(0, 12.0, 8.0); n.add_child(luz)

# ---------------- poderes temporários ----------------
func dar_poder(tipo: String) -> void:
	if estado != "jogo": return
	if poder != "": _fim_poder()
	var d: Dictionary = Dados.PODERES[tipo]
	poder = tipo; poder_t = d["dur"]; _poder_tick = 0.0
	var p := player
	match tipo:
		"mula":
			p.speed *= 1.5
			_boneco_seu = p.boneco; _boneco_seu.visible = false
			p.boneco = Boneco.criar("mula"); p.add_child(p.boneco)
		"lobisomem": p.atk_speed *= 2.0
		"curupira": p.speed *= 1.6
		"boto": p.xp_mult *= 2.0
	lbl_centro.text = tr("%s\n%s") % [tr(String(d["nome"])), tr(String(d["txt"]))]; _piscar_centro()
	Som.tocar("ult"); tremor = maxf(tremor, 0.5)
	_efeito_anel(p.global_position, 5.0, d["cor"])

func _fim_poder() -> void:
	var p := player
	match poder:
		"mula":
			p.speed /= 1.5
			if is_instance_valid(_boneco_seu):
				p.boneco.queue_free(); p.boneco = _boneco_seu; p.boneco.visible = true
		"lobisomem": p.atk_speed /= 2.0
		"curupira": p.speed /= 1.6
		"boto": p.xp_mult /= 2.0
	poder = ""

func _poderes(delta: float) -> void:
	# o fogo que a mula deixou continua queimando mesmo depois que o poder acaba
	for f in _fogos.duplicate():
		f["t"] -= delta; f["tick"] -= delta
		if f["tick"] <= 0.0:
			f["tick"] = 0.3
			_ring(f["no"].position, 1.5, 9.0 * _escala_hab(player), 0.0, 0.0)
		if f["t"] <= 0.0:
			f["no"].queue_free(); _fogos.erase(f)
	if poder == "": return
	var p := player; var pos: Vector3 = p.global_position
	var s := _escala_hab(p)
	poder_t -= delta; _poder_tick -= delta
	match poder:
		"mula":
			p.iframes = maxf(p.iframes, 0.2)
			if _poder_tick <= 0.0:
				_poder_tick = 0.12
				var n := Node3D.new(); n.position = Vector3(pos.x, Lib.h(pos.x, pos.z), pos.z); add_child(n)
				Lib.cil(n, 0.0, 0.45, 1.1, Vector3(0, 0.55, 0), Color(1.0, 0.4, 0.05), 5, Vector3.ZERO, 2.2).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				Lib.cil(n, 0.0, 0.25, 0.7, Vector3(0.1, 0.4, 0.1), Color(1.0, 0.8, 0.2), 5, Vector3.ZERO, 2.8).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				_fogos.append({"no": n, "t": 3.0, "tick": 0.0})
		"iara":
			if _poder_tick <= 0.0:
				_poder_tick = 0.5
				for e in enemies:
					if is_instance_valid(e) and not e.dead and not e.is_boss and e.global_position.distance_to(pos) < 7.5: e.stun_t = maxf(e.stun_t, 0.9)
				_efeito_anel(pos, 7.5, Dados.PODERES[poder]["cor"])
		"saci":
			if _poder_tick <= 0.0:
				_poder_tick = 0.3
				_ring(pos, 4.2 * p.area_mult, 9.0 * s, 0.0, 0.4)
				_efeito_anel(pos, 4.2 * p.area_mult, Color(0.9, 0.9, 0.85)); p.boneco.girar()
		"curupira": p.dash_cd = 0.0
		"boto":
			for fr in fireflies: fr["mag"] = true
		"corposeco": p.iframes = maxf(p.iframes, 0.2)
		"caipora": p.hp = minf(p.max_hp, p.hp + p.max_hp * 0.05 * delta)
	if poder_t <= 0.0: _fim_poder()

# ---------------- pulos de cada herói ----------------
func efeito_pulo(p: Jogador) -> void:
	_efeito_anel(p.global_position, 1.2, Color.WHITE)

func pousou(p: Jogador) -> void:
	if estado != "jogo": return
	var s := _escala_hab(p)
	match p.classe:
		"capoeirista":
			_ring(p.global_position, 2.6 * p.area_mult, 12.0 * s, 0.0, 1.0)
			_efeito_anel(p.global_position, 2.6 * p.area_mult, Dados.CLASSES[p.classe]["cor"])
		"jiujitsu":
			_ring(p.global_position, 2.8 * p.area_mult, 5.0 * s, 0.9, 0.0)
			_efeito_anel(p.global_position, 2.8 * p.area_mult, Dados.CLASSES[p.classe]["cor"]); tremor = maxf(tremor, 0.15)
		"frevista":        # só empurra, não bate — como o texto do pulo avisa
			_ring(p.global_position, 3.0 * p.area_mult, 0.0, 0.0, 2.2)
			_efeito_anel(p.global_position, 3.0 * p.area_mult, Dados.CLASSES[p.classe]["cor"])
		"cordelista":
			_ring(p.global_position, 2.4 * p.area_mult, 6.0 * s, 0.8, 0.3)
			_efeito_anel(p.global_position, 2.4 * p.area_mult, Dados.CLASSES[p.classe]["cor"])
		"maracatuzeiro":   # queda pesada do alfaia: tremor e acerta em volta
			_ring(p.global_position, 2.9 * p.area_mult, 7.0 * s, 0.8, 0.0)
			_efeito_anel(p.global_position, 2.9 * p.area_mult, Dados.CLASSES[p.classe]["cor"]); tremor = maxf(tremor, 0.15)
		"carimbozeiro":    # só empurra, não bate — como no frevista
			_ring(p.global_position, 3.0 * p.area_mult, 0.0, 0.0, 2.2)
			_efeito_anel(p.global_position, 3.0 * p.area_mult, Dados.CLASSES[p.classe]["cor"])
		"angoleiro":       # cabeçada ao cair: atordoa quem está perto
			_ring(p.global_position, 2.7 * p.area_mult, 8.0 * s, 1.0, 0.2)
			_efeito_anel(p.global_position, 2.7 * p.area_mult, Dados.CLASSES[p.classe]["cor"]); tremor = maxf(tremor, 0.15)

# ---------------- tutorial ----------------
const TUT := [
	"Ande com {cima}, {esq}, {baixo} e {dir} (ou as setas).",
	"Mexa o mouse para girar a câmera.\nA rodinha aproxima e afasta.",
	"{pulo} pula. Dá para pular por cima dos bichos pequenos.\n%s",
	"{dash} dá uma arrancada para onde você estiver andando.\nNão gasta nada: é só esperar recarregar.",
	"Os golpes saem sozinhos. Chegue perto dos bichos e derrube todos!",
	"Os bichos deixam vaga-lumes: é o XP. Passe por cima deles\npara subir de nível e escolher uma carta.",
	"{q} é o seu especial: %s. Use perto dos bichos!",
	"{r} é o ultimate: %s.\nEle carrega derrubando bichos. Solte agora!",
	"Pelo mapa: potes (moedas e cura), baús (cartas raras, pagos com moedas),\noratórios (fique perto para ganhar uma graça) e a Bodega do Lampião.",
	"É isso! Na fase de verdade: aguente 10 minutos, vença o chefe\ne depois veja até onde você aguenta. ESC pausa, {info} mostra a build.",
]

func _tut_bichos(n: int) -> void:
	for i in range(n):
		var a := i * TAU / n
		var e := _nascer("caipora" if i % 2 == 0 else "saci", 0.6, 1.0, null, false)
		e.position = player.global_position + Vector3(cos(a) * 9.0, 0, sin(a) * 9.0)
		e.dmg = 1.0

func _tutorial(delta: float) -> void:
	var p := player
	p.hp = p.max_hp
	if painel_tut == null:
		painel_tut = Tela.painel(Color(1.0, 0.97, 0.86), 4)
		painel_tut.anchor_left = 0.5; painel_tut.anchor_right = 0.5; painel_tut.offset_top = 96
		painel_tut.grow_horizontal = Control.GROW_DIRECTION_BOTH
		lbl_tut = Tela.texto("", 19, 640); painel_tut.add_child(lbl_tut); hud.add_child(painel_tut)
	var hb: Dictionary = Dados.HABILIDADES[p.classe]
	var txt: String = tr(TUT[tut])
	for it in Ctrl.ACOES: txt = txt.replace("{%s}" % it[0], Ctrl.nome(it[0]).to_upper())
	if tut == 2: txt = txt % tr(String(Dados.CLASSES[p.classe]["pulo"]))
	elif tut == 6: txt = txt % tr(String(hb["q"]["nome"]))
	elif tut == 7: txt = txt % tr(String(hb["r"]["nome"]))
	lbl_tut.text = tr("TUTORIAL %d/%d\n%s") % [tut + 1, TUT.size(), txt]
	tut_t += delta
	var feito := false
	match tut:
		0: feito = p.position.distance_to(_tut_pos) > 5.0 or (p.bot and tut_t > 1.0)
		1: feito = absf(cam_yaw - _tut_a) > 1.0 or (p.bot and tut_t > 1.0)
		2: feito = p.alt > 0.6 or (p.bot and tut_t > 1.0)
		3:
			if Ctrl.ap("dash") and p.dash_cd <= 0.0 and p.dash_t <= 0.0: p.forcar_dash()
			feito = p.dash_t > 0.0 or (p.bot and tut_t > 1.0)
		4:
			if tut_t < delta * 1.5: _tut_bichos(8)
			feito = tut_t > 1.0 and enemies.is_empty()
		5:
			if tut_t < delta * 1.5: _tut_bichos(12)    # bichos de verdade: ao morrer, deixam os vaga-lumes (como o texto explica)
			if enemies.is_empty() and tut_t > 1.2:
				for fr in fireflies: fr["mag"] = true   # ninguém fica preso catando vaga-lume de longe (ex.: benzedeira só atira)
			feito = p.level >= 2 and not levelup_aberto and fireflies.size() < 4 and enemies.is_empty()
		6:
			if tut_t < delta * 1.5: p.q_cd = 0.0; _tut_bichos(8)
			if enemies.is_empty() and p.q_cd <= 0.0 and tut_t > 2.0: _tut_bichos(8)
			feito = p.q_cd > 0.0 and tut_t > 1.0
		7:
			if tut_t < delta * 1.5: p.ult = 1.0; _tut_bichos(12)
			feito = p.ult_t > 0.0
		8: feito = tut_t > 7.0
		9:
			if tut_t > 7.0: _fim_tutorial()
	if feito and tut_t > 0.8:
		tut += 1; tut_t = 0.0; Som.tocar("carta")

func _fim_tutorial() -> void:
	if _teste_fim > 0.0:
		print("TUTORIAL OK em %s — nivel:%d abates:%d" % [_mmss(time), player.level, kills]); get_tree().quit(); return
	Salvo.d["tutorial"] = true; Salvo.salvar()
	get_tree().reload_current_scene()

# mini-chefe do portal: a Cuca. Vencer rende muito XP, moedas e dois baús de graça.
# convidado usou o portal: só o anfitrião tem autoridade pra fazer a Cuca nascer de verdade (pra replicar pros dois)
@rpc("any_peer", "call_remote", "reliable")
func _pedir_cuca_rede(pos: Vector3) -> void:
	if not Rede.sou_host(): return
	_cuca(pos)

func _cuca(pos: Vector3) -> void:
	var forca := (1.0 + time / 75.0) * float(Dados.FASES[fase]["mult"])
	var c := _nascer("cuca", forca, 1.7, null, false)
	c.position = pos + Vector3(4.0, 0, 0); c.chefe_tipo = "cuca"; c.elite = true
	c.hp = 320.0 * forca; c.max_hp_cache = c.hp; c.dmg = 9.0 * sqrt(forca); c.speed = 2.6
	c.xp_val = 30.0 + time / 12.0; c.moeda_val = 60.0
	lbl_centro.text = "A CUCA VEIO PEGAR!\nVença para levar o tesouro dela"; _piscar_centro()
	Som.tocar("chefe")
	_replicar_bicho(c)   # no-op sozinho; no co-op, é assim que o convidado também vê a Cuca

func game_over() -> void:
	_pedir_fim_grupo("VOCÊ CAIU NA MATA", Color(0.95, 0.4, 0.3))

# Fim da partida (caiu, ou saiu depois de vencer o chefe): paga as moedas, guarda recorde e volta ao arraial.
func _encerrar(titulo: String, cor: Color) -> void:
	if estado == "fim": return
	estado = "fim"
	if Rede.ativo(): _ficou_fora.rpc_id(1)     # co-op: não seguro mais as rodadas de carta dos outros
	Som.tocar("venceu" if titulo == "FASE VENCIDA!" else "caiu")
	if titulo == "VOCÊ CAIU NA MATA": Som.voz("v_caiu")
	_mouse(false)
	var ganho := int(moedas * (1.0 if chefe_morto else 0.5))
	Salvo.d["moedas"] = int(Salvo.d["moedas"]) + ganho
	Salvo.d["maior_dano_run"] = maxf(float(Salvo.d.get("maior_dano_run", 0.0)), dano_total)   # pra liberar herói por feito, tipo "2 milhões numa corrida"
	var linha := "Não venceu o chefe: leva metade das moedas"
	if chefe_morto:
		linha = tr("Aguentou %s depois do chefe") % _mmss(extra_t)
		var k := str(fase)
		if extra_t > float(Salvo.d["recordes"].get(k, -1.0)):
			Salvo.d["recordes"][k] = extra_t; linha += " — NOVO RECORDE!"
	Salvo.salvar()
	if _teste_fim == 2.0: _bot_fim(titulo)
	lbl_centro.text = ""
	var img: String = {"FASE VENCIDA!": "t_venceu", "VOCÊ CAIU NA MATA": "t_caiu"}.get(titulo, "")
	var linhas := tr("Fase %d — %s\nTempo %s  ·  %d abates  ·  nível %d\nMaior golpe: %s  ·  Dano total: %s\n%s") % [
		fase + 1, tr(String(Dados.FASES[fase]["nome"])), _mmss(time), kills, player.level, Tela.num(maior_dano), Tela.num(dano_total), linha]
	var fase_nome := tr(String(Dados.FASES[fase]["nome"]))
	var apelido := tr(String(Dados.CLASSES[player.classe]["apelido"]))
	var cordel := Dados.titulo_cordel(apelido, fase_nome, dano_total, maior_dano, kills, chefe_morto, time)
	menus.fim(titulo, img, linhas, ganho, player.classe, cordel, player.golpes.duplicate())

func tomou_dano() -> void:
	_moldura_a = 0.75; tremor = maxf(tremor, 0.3); Som.tocar("dano", -2.0)

func _piscar_centro() -> void:
	await get_tree().create_timer(1.6).timeout
	if estado != "fim" and not levelup_aberto: lbl_centro.text = ""

func _hud() -> void:
	var p := player
	var f: Dictionary = Dados.FASES[fase]
	var dt := get_process_delta_time()
	var larg := get_viewport().get_visible_rect().size.x
	lbl_topo.text = _mmss(time)
	lbl_nv.text = tr("NÍVEL %d") % p.level
	lbl_dir.text = "☠ %d   ◉ %d" % [kills, int(moedas)]
	while _dps_janela.size() > 0 and time - _dps_janela[0][0] > 1.0: _dps_janela.pop_front()
	var dps := 0.0
	for it in _dps_janela: dps += it[1]
	lbl_dps.text = tr("%s de dano/s") % Tela.num(dps)
	# segurando Tab, o minimapa do canto só aumenta no lugar dele mesmo — não cobre a tela
	var mapa_ampliado: bool = Ctrl.ap("mapa") and not levelup_aberto
	var lado_map := (380.0 if mapa_ampliado else 194.0)
	minimapa.offset_right = -14; minimapa.offset_left = -14 - lado_map
	minimapa.offset_top = 12; minimapa.offset_bottom = 12 + lado_map
	lbl_dir.offset_top = 12 + lado_map + 4.0
	_inventario()
	painel_info.visible = Ctrl.ap("info")
	if painel_info.visible: _montar_placar()
	if chefe_morto: lbl_sub.text = tr("Tempo extra %s · moedas ×%.1f · F sai com o que ganhou") % [_mmss(extra_t), 1.0 + extra_t / 90.0]
	elif chefe_veio: lbl_sub.text = tr("%s, %s — %s") % [tr(String(f["chefe_nome"])), tr(String(f["chefe_titulo"])), tr("ENFURECIDO!") if furia else tr("enfurece em ") + _mmss(furia_t)]
	elif tut >= 0: lbl_sub.text = tr("Tutorial")
	if poder != "": lbl_sub.text = tr("%s — %d s") % [tr(String(Dados.PODERES[poder]["nome"])), int(ceil(poder_t))]
	else: lbl_sub.text = tr("Chefe em ") + _mmss(maxf(0.0, chefe_t - time))
	barra_chefe_bg.visible = chefe_veio and not chefe_morto and is_instance_valid(chefe)
	if barra_chefe_bg.visible: barra_chefe.size.x = 494.0 * clampf(chefe.hp / chefe.max_hp_cache, 0, 1)
	# vida: a parte clara mostra o que acabou de perder e vai sumindo
	var fr := clampf(p.hp / p.max_hp, 0, 1)
	_vida_lag = fr if fr > _vida_lag else maxf(fr, _vida_lag - dt * 0.35)
	barra_vida.size.x = 258.0 * fr; barra_lag.size.x = 258.0 * _vida_lag
	barra_vida.color = Tela.URUCUM if fr > 0.3 else Color(1.0, 0.2, 0.1).lerp(Tela.URUCUM, 0.5 + 0.5 * sin(time * 9.0))
	barra_xp.size.x = 260.0 * clampf(p.xp / p.xp_next, 0, 1)
	lbl_vida.text = "♥ %d / %d" % [ceil(p.hp), p.max_hp]
	_moldura_a = maxf(0.0, _moldura_a - dt * 1.6)
	var baixa := 0.0 if fr > 0.3 else (0.3 + 0.2 * sin(time * 7.0)) * (1.0 - fr / 0.3 * 0.5)
	moldura.modulate.a = maxf(_moldura_a, baixa)
	# quadrinhos
	if _slots.size() != p.golpes.size() + 2: _refazer_slots()
	for i in range(p.golpes.size()):
		var g: Dictionary = p.golpes[i]; var q: Dictionary = _slots[i]
		var cd := Dados.cd_golpe(g["id"], g["nivel"], p.atk_speed)
		q["som"].size.y = (q["tam"] - 8.0) * clampf(g["t"] / cd, 0, 1)
		q["nv"].text = "MÁX" if g["nivel"] >= Dados.NIVEL_MAX else str(g["nivel"])
	var hb: Dictionary = Dados.HABILIDADES[p.classe]
	var sq: Dictionary = _slots[-2]; var sr: Dictionary = _slots[-1]
	sq["som"].size.y = (sq["tam"] - 8.0) * clampf(p.q_cd / float(hb["q"]["cd"]), 0, 1)
	sq["txt"].text = "" if p.q_cd <= 0.0 else str(int(ceil(p.q_cd)))
	sr["som"].size.y = (sr["tam"] - 8.0) * (0.0 if p.ult_t > 0.0 else 1.0 - p.ult)
	sr["txt"].text = "" if p.ult >= 1.0 or p.ult_t > 0.0 else "%d%%" % int(p.ult * 100.0)
	var pulso := 1.0 + 0.25 * (0.5 + 0.5 * sin(time * 8.0))
	sr["no"].modulate = Color(pulso, pulso, 0.9) if p.ult >= 1.0 or p.ult_t > 0.0 else Color.WHITE
	sq["no"].modulate = Color.WHITE if p.q_cd > 0.0 else Color(1.12, 1.12, 1.0)
	# sequência de abates
	combo_t -= dt
	if combo_t <= 0.0: combo = 0
	lbl_combo.text = "" if combo < 5 else tr("×%d\nSEQUÊNCIA") % combo
	lbl_combo.modulate.a = clampf(combo_t / 1.2, 0.25, 1.0)

# mini inventário: um quadradinho por tipo de carta de atributo, com a quantidade
func _inventario() -> void:
	var p := player
	if _inv_n == p.cartas_stat.size(): return
	_inv_n = p.cartas_stat.size()
	for c in caixa_inv.get_children(): c.queue_free()
	var conta := {}; var melhor := {}
	for c in p.cartas_stat:
		conta[c["id"]] = int(conta.get(c["id"], 0)) + 1
		melhor[c["id"]] = maxi(int(melhor.get(c["id"], 0)), int(c["rar"]))
	for id in conta:
		var q := Panel.new(); q.custom_minimum_size = Vector2(34, 34)
		var cr: Color = Dados.RARIDADES[melhor[id]]["cor"] if melhor[id] > 0 else Tela.TINTA
		q.add_theme_stylebox_override("panel", Tela.caixa(Tela.PAPEL, 2, cr.darkened(0.2) if melhor[id] > 0 else cr, 0, 3))
		var im := Tela.imagem("a_" + String(Dados.STATS[id]["arte"]), Vector2(28, 28)); im.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		im.position = Vector2(3, 3); im.size = Vector2(28, 28); im.clip_contents = true; q.add_child(im)
		if conta[id] > 1:
			var l := _label(13, HORIZONTAL_ALIGNMENT_RIGHT); l.text = "×%d" % conta[id]; l.position = Vector2(0, 16); l.size = Vector2(33, 18); q.add_child(l)
		caixa_inv.add_child(q)

# placar estilo "ver build" (Tab): uma coluna por pessoa na sala; sozinho, é só a sua
func _montar_placar() -> void:
	for c in caixa_placar.get_children(): c.queue_free()
	var gente: Array = (Rede.ids() if Rede.ativo() else [0])
	for id in gente:
		var j = (jogadores_rede.get(id, null) if Rede.ativo() else player)
		if j == null or not is_instance_valid(j): continue
		caixa_placar.add_child(_coluna_placar(j, id))

func _coluna_placar(j: Jogador, id: int) -> PanelContainer:
	var c: Dictionary = Dados.CLASSES[j.classe]
	var p := PanelContainer.new(); p.custom_minimum_size = Vector2(230, 0)
	p.add_theme_stylebox_override("panel", Tela.caixa(Color(1.0, 0.97, 0.86), 3, c["cor"].darkened(0.2), 5))
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 3); p.add_child(v)
	var nome: String = Rede.nome_por_id.get(id, "") if Rede.ativo() else ""
	v.add_child(Tela.faixa((nome + " — " if nome != "" else "") + String(c["apelido"]).to_upper(), c["cor"], 13, Tela.TINTA))
	v.add_child(Tela.rotulo(tr("NÍVEL %d") % j.level, 14, Tela.TINTA, HORIZONTAL_ALIGNMENT_CENTER, true))
	for g in j.golpes: v.add_child(Tela.rotulo(tr("%s — nv %d") % [tr(String(Dados.GOLPES[g["id"]]["nome"])), g["nivel"]], 12, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	var st := tr("Vida %d/%d  ·  Dano +%d%%\nCrítico %d%% (×%.1f)  ·  Atq +%d%%\nÁrea +%d%%  ·  Defesa %d%%  ·  Regen %.1f/s") % [
		int(ceil(j.hp)), int(j.max_hp), int(round((j.dano_mult - 1.0) * 100.0)), int(round(j.crit * 100.0)), j.crit_dano,
		int(round((j.atk_speed - 1.0) * 100.0)), int(round((j.area_mult - 1.0) * 100.0)), int(round(minf(0.7, j.armor) * 100.0)), j.regen]
	v.add_child(Tela.texto(st, 11, 214, Tela.TINTA, HORIZONTAL_ALIGNMENT_LEFT))
	if id == Rede.meu_id() or not Rede.ativo():
		v.add_child(Tela.texto(tr("Maior golpe: %s\nDano total: %s\nSequência: ×%d") % [Tela.num(maior_dano), Tela.num(dano_total), combo], 11, 214, Tela.ANIL))
	return p

func _mmss(t: float) -> String:
	return "%d:%02d" % [int(t) / 60, int(t) % 60]

# prints de conferência
func _salvar(nome: String) -> void:
	await get_tree().process_frame
	while not Gravador.ocioso(): await get_tree().process_frame     # espera a impressão das figuras de papel
	await get_tree().create_timer(1.0).timeout
	print("METRICAS nos=%d desenhos=%d objetos=%d primitivas=%d modo=%s" % [Performance.get_monitor(Performance.OBJECT_NODE_COUNT), Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME), "papel" if Gravador.ligado else "3D"])
	var img := get_viewport().get_texture().get_image()
	img.save_png(ProjectSettings.globalize_path("res://%s.png" % nome))
	get_tree().quit()

func _shot_tela(nome: String) -> void:
	sem_mouse = true
	Salvo.d["moedas"] = 345; Salvo.d["fase_max"] = 1; Salvo.d["melhorias"] = {"capoeirista": {"dano": 3, "vida": 1}, "jiujitsu": {"dano": 7, "critico": 4}}; Salvo.d["recordes"] = {"0": 100.0}
	Salvo.d["contadores"] = {"abates": 812, "abates_saci": 150, "chefes": 1, "uso_kimura": 40, "criticos": 300}
	if nome in ["herois", "melhorias", "opcoes", "titulo", "feitos", "controles", "opcoes_jogo", "icones", "sala", "sala_falha", "pergtut", "herois_tut", "coop", "coopesperar", "herois_trancados", "herois_dica", "heroi_novo"]:
		_montar_menu()
		if nome == "herois": menus.herois()
		elif nome == "herois_trancados":
			menus.herois()
			await get_tree().process_frame; await get_tree().process_frame
			menus._scr_herois.scroll_vertical = 9999
		elif nome == "herois_dica":
			menus.herois()
			await get_tree().process_frame; await get_tree().process_frame
			menus._scr_herois.scroll_vertical = 9999
			await get_tree().process_frame; await get_tree().process_frame
			var gr: GridContainer = menus._scr_herois.get_child(0)
			var alvo: Control = null
			for ch in gr.get_children():
				if ch is Button and String(ch.tooltip_text) != "": alvo = ch; break
			if alvo:
				var ctr: Vector2 = alvo.get_global_rect().get_center()
				print("DEBUG dica: alvo=%s ctr=%s tooltip=%s" % [alvo.name, ctr, alvo.tooltip_text])
				var mm := InputEventMouseMotion.new(); mm.position = ctr; mm.global_position = ctr
				Input.parse_input_event(mm)
				await get_tree().create_timer(0.7).timeout
				Input.parse_input_event(mm)
			else:
				print("DEBUG dica: nenhum botao trancado encontrado")
		elif nome == "herois_tut": menus._so_tutorial = true; menus.herois()
		elif nome == "heroi_novo": sel_heroi = "sambista"; menus.herois()
		elif nome == "melhorias": menus.melhorias()
		elif nome == "feitos": menus.feitos()
		elif nome == "opcoes": menus.opcoes(menus.titulo)
		elif nome == "controles": menus._aba = "controles"; menus.opcoes(menus.titulo)
		elif nome == "opcoes_jogo": menus._aba = "jogo"; menus.opcoes(menus.titulo)
		elif nome == "icones":      # depuração: folha com o ícone de todos os golpes
			menus._limpar("icones"); Tela.fundo_papel(menus.raiz, Color(1, 1, 1), false)
			var gi := GridContainer.new(); gi.columns = 13; gi.position = Vector2(14, 8); gi.add_theme_constant_override("h_separation", 5); gi.add_theme_constant_override("v_separation", 5)
			menus.raiz.add_child(gi)
			for gid in Dados.GOLPES: gi.add_child(Tela.imagem("a_" + String(Dados.GOLPES[gid]["arte"]), Vector2(92, 62)))
		elif nome == "coop": menus.coop()
		elif nome == "sala_falha":  # depuração: a sala como aparece num PC onde nada abriu (firewall bloqueado, roteador recusou)
			Rede.hospedar(""); await get_tree().create_timer(5.0).timeout
			Rede.firewall_estado = "faltando"; Rede.upnp_estado = "falhou"
			Rede.upnp_motivo = "O roteador recusou abrir a porta (erro 725). Abra a porta UDP 7777 à mão no roteador, ou use uma VPN (Tailscale)."
			menus._ajuda_porta = true; menus.coop(); await get_tree().create_timer(1.0).timeout
		elif nome == "sala":        # depuração: abre uma sala de verdade e mostra o código
			Rede.hospedar(""); menus.coop()
			await get_tree().create_timer(6.0).timeout
		elif nome == "coopesperar":
			menus.coop()
			await get_tree().create_timer(3.5).timeout
		elif nome == "pergtut": _montar_menu(); menus.herois(); menus.perguntar_tutorial()
	else:
		iniciar_jogo("capoeirista" if nome != "nivel2" else "cangaceiro", 3 if nome == "cristo" else 0)
		player.aplicar_carta({"tipo": "golpe_novo", "id": Dados.CLASSES[player.classe]["desbloqueia"].keys()[0]})
		player.level = 4
		for i in range(14):
			var a := i * TAU / 14.0
			_nascer("caipora" if i % 2 == 0 else "saci", 1.0, 1.0, null, false)
			enemies[-1].position = player.global_position + Vector3(cos(a) * (4.0 + i % 3 * 2.0), 0, sin(a) * (4.0 + i % 3 * 2.0))
			enemies[-1].hp = 9999
		await get_tree().create_timer(1.3).timeout
		dano_total = 48213.0; maior_dano = 1840.0
		if nome == "pausa": estado = "pausa"; menus.pausa()
		elif nome == "fim": _encerrar("VOCÊ CAIU NA MATA", Color.WHITE)
		elif nome == "jogo": pass
		elif nome == "bau": abrir_escolha("bau")
		elif nome == "loja": moedas = 60.0; abrir_loja()
		elif nome == "tutorial": tut = 2
		elif nome == "mula":
			dar_poder("mula"); player.position += Vector3(3, 0, 0)
			await get_tree().create_timer(0.5).timeout
			player.position += Vector3(2, 0, 2)
		elif nome == "cristo":
			player.position = Vector3(0, 0, 4); cam_yaw = 0.0; cam_pitch = 0.2; cam_dist = 20.0
		elif nome == "placar":
			var ek := InputEventKey.new(); ek.physical_keycode = Ctrl.tecla("info"); ek.pressed = true
			Input.parse_input_event(ek)
		elif nome == "mapagrande":
			_montar_objetos()
			var ek := InputEventKey.new(); ek.physical_keycode = Ctrl.tecla("mapa"); ek.pressed = true
			Input.parse_input_event(ek)
		elif nome == "placas":
			_novo_objeto("oratorio", player.global_position + Vector3(4.0, 0, 2.0), 0)
			_novo_objeto("baiana", player.global_position + Vector3(-3.0, 0, 3.0), 0)
			cam_yaw = 0.3; cam_pitch = 0.6; cam_dist = 15.0
		elif Dados.NPCS.has(nome):
			moedas = 70.0; _teste_fim = 0.0; Salvo.d["falas"][nome] = randi() % 5; abrir_npc(nome)
		elif nome == "lore": abrir_escolha("lore:lobisomem")
		elif nome == "lore2": abrir_escolha("lore:minhocao")
		elif nome == "inv":
			for sid in ["dano", "dano", "critico", "vermes", "pulo", "area", "vida"]: player.aplicar_carta({"tipo": "stat", "id": sid, "rar": randi() % 5})
		elif nome == "feitos": pass
		else: abrir_escolha("nivel")
	_salvar("shot_" + nome)

# depuração: imprime as folhas de gravura de alguns tipos e salva em godot/folha_N.png
func _folha() -> void:
	sem_mouse = true
	Gravador.dump_dir = ProjectSettings.globalize_path("res://")
	var nomes: Array = Dados.CLASSES.keys() + ["caipora", "saci", "curupira", "corposeco", "iara", "lobisomem", "boto", "cuca", "mapinguari", "mula", "minhocao", "boitata"]
	if "--folha" in OS.get_cmdline_user_args() and OS.get_cmdline_user_args().find("--folha") + 1 < OS.get_cmdline_user_args().size() and OS.get_cmdline_user_args()[OS.get_cmdline_user_args().find("--folha") + 1] == "poucos":
		nomes = ["minhocao", "boitata", "mula", "mapinguari", "cuca", "lobisomem"]
	for i in range(nomes.size()):
		var b := Boneco.criar(nomes[i]); add_child(b); b.position = Vector3(i * 2.0 - 10.0, Lib.h(i * 2.0 - 10.0, 0), 0)
	while not Gravador.ocioso() or get_tree().get_frame() < 30: await get_tree().process_frame
	await get_tree().create_timer(1.0).timeout
	get_tree().quit()

func _shot_arena(cls: String) -> void:
	sem_mouse = true
	iniciar_jogo(cls, sel_fase)
	_salvar("shot_arena_" + cls)

func _shot_cerco(cls: String) -> void:
	sem_mouse = true
	iniciar_jogo(cls, sel_fase)
	player.max_hp = 1e6; player.hp = 1e6
	_evento_t = 0.1
	await get_tree().create_timer(16.0).timeout
	_salvar("shot_cerco_" + cls)

func _shot_debug(cls: String) -> void:
	sem_mouse = true
	iniciar_jogo(cls, sel_fase)
	for id in Dados.CLASSES[cls]["desbloqueia"]:
		player.aplicar_carta({"tipo": "golpe_novo", "id": id})
	player.max_hp = 1e6; player.hp = 1e6
	for i in range(14):
		var a := i * TAU / 14.0
		_nascer("caipora" if i % 2 == 0 else "saci", 1.0, 1.0 if i != 5 else 1.5, null if i != 5 else Color(0.98, 0.85, 0.2), false)
		enemies[-1].position = player.global_position + Vector3(cos(a) * (5.5 + i % 3 * 2.0), 0, sin(a) * (5.5 + i % 3 * 2.0))
		enemies[-1].hp = 9999
	_salvar("shot_" + cls)

# confere, sem precisar da tela toda, que a arrancada do tutorial funciona mesmo parado
func _teste_coop_host() -> void:
	sem_mouse = true; _coop_teste = true    # teste automático: nunca prende o mouse do jogador de verdade
	Salvo.d["nome_jogador"] = "Anfitriao"
	sel_heroi = "capoeirista"; sel_fase = 0
	var erro := Rede.hospedar("Mundo de Teste")
	if erro != "": print("ERRO HOST: ", erro); get_tree().quit(); return
	await get_tree().create_timer(0.3).timeout
	print("codigo relay desta sala: ", Rede._sala_relay)
	var espera := 0
	var quer := 2
	var args_t := OS.get_cmdline_user_args()
	if "--esperar" in args_t: quer = int(args_t[args_t.find("--esperar") + 1])
	while Rede.ids().size() < quer and espera < 20:
		await get_tree().create_timer(1.0).timeout
		espera += 1
	print("HOST viu %d na sala depois de %ds: %s" % [Rede.ids().size(), espera, str(Rede.ids())])
	Rede.comecar()
	_teste_coop_relatar()

func _teste_coop_join(ip: String) -> void:
	sem_mouse = true; _coop_teste = true    # teste automático: nunca prende o mouse do jogador de verdade
	Salvo.d["nome_jogador"] = "Convidado" if not ("--sem-nome" in OS.get_cmdline_user_args()) else ""
	sel_heroi = "jiujitsu"; sel_fase = 2      # de propósito DIFERENTE do anfitrião: tem que jogar a fase dele
	var erro = await Rede.entrar(ip)
	if erro != "": print("ERRO JOIN: ", erro); get_tree().quit(); return
	_teste_coop_relatar()

func _teste_coop_relatar() -> void:
	var args0 := OS.get_cmdline_user_args()
	var n_ticks := int(args0[args0.find("--ticks") + 1]) if "--ticks" in args0 else 16
	for i in range(n_ticks):
		await get_tree().create_timer(1.0).timeout
		if estado != "jogo" or player == null:
			print("COOP eu=%s tick=%d AINDA SEM JOGO (estado=%s)" % [sel_heroi, i, estado]); continue
		var a_t := OS.get_cmdline_user_args()
		if "--sair-em" in a_t and i == int(a_t[a_t.find("--sair-em") + 1]):
			print("CONVIDADO saiu da sala de repente (queda de conexão)"); get_tree().quit(); return
		if not Rede.sou_host() and i == 0: player.position = Vector3(20, 0, 20)   # longe do anfitrião, pra isolar o teste
		if Rede.sou_host() and i == 3 and jogadores_rede.size() >= 2:
			var alvo_pos: Vector3 = player.global_position
			for id in jogadores_rede:
				if id != Rede.meu_id(): alvo_pos = jogadores_rede[id].global_position
			var bicho := _nascer("caipora", 0.3, 1.0, null, false)
			bicho.position = alvo_pos; bicho.hp = 400.0; bicho.max_hp_cache = 400.0; bicho.dmg = 8.0
			_replicar_bicho(bicho)
			print("HOST criou bicho de teste (aguenta apanhar) em %s hp=%.0f net_id=%d" % [str(alvo_pos), bicho.hp, bicho.net_id])
		if not Rede.sou_host() and i == 9 and enemies.size() > 0:
			var k := _ring(player.global_position, 6.0, 1000.0, 0.0, 0.0)
			print("CLIENTE atacou — _ring acertou %d bicho(s)" % k)
		if Rede.sou_host() and i == 6:
			for o2 in objetos:
				if o2["tipo"] == "pote":
					player.position = o2["no"].position; player.alt = 0.0
					print("HOST teleportou pro pote net_id=%s pra testar consumo sincronizado" % str(o2.get("net_id", "?")))
					break
		if Rede.sou_host() and i == 4:
			xp_para_equipe(equipe_xp_next + 1.0)
			print("HOST deu XP pra equipe: sobe nível e abre rodada de cartas pra todos")
		if Rede.sou_host() and i == 11:
			_pedir_rodada.rpc_id(1, "bau")
			print("HOST pediu um baú: só ele escolhe, mas o jogo pára pra todos")
		if i == 8:
			var nomes := []
			for id2 in jogadores_rede:
				var lb := jogadores_rede[id2].get_node_or_null("Nome") as Label3D
				nomes.append("%d:'%s'" % [id2, lb.text if lb else "SEM ETIQUETA"])
			print("NOMES vistos por mim (id %d): %s" % [Rede.meu_id(), ", ".join(nomes)])
		if i == 12 and Rede.sou_host() and DisplayServer.get_name() != "headless":
			get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://shot_coopnomes.png"))
		print("COOP eu=%s id=%d tick=%d jogadores=%d bichos=%d objetos=%d nivel=%d xp=%.1f/%.1f equipe=%d moedas=%.1f vida=%.1f/%.1f t=%.1f fase=%d" % [
			sel_heroi, Rede.meu_id(), i, jogadores_rede.size(), enemies.size(), objetos.size(), player.level, player.xp, player.xp_next, equipe_nivel, moedas, player.hp, player.max_hp, time, fase + 1])
	get_tree().quit()

# simula o ritmo da partida inteira (sem precisar esperar 10 minutos de verdade): avança o relógio na marra e
# confere quantos bichos tem na tela e quantos XP/nível em cada marco de tempo.
func _teste_ritmo() -> void:
	sem_mouse = true
	iniciar_jogo("capoeirista")
	player.aplicar_carta({"tipo": "golpe_novo", "id": "meialua"})
	var passo := 0.1
	var proximo_marco := 60.0
	while time < 620.0:
		time += passo
		_marcos_de_ritmo()
		_dirigir(passo)
		_update_projectiles(passo)
		_objetos(passo)
		if time >= proximo_marco:
			print("RITMO t=%s bichos=%d xp_next=%.0f nivel=%d" % [_mmss(time), enemies.size(), player.xp_next, player.level])
			proximo_marco += 60.0
	get_tree().quit()

func _teste_lock() -> void:
	for id in ["forrozeiro", "angoleiro", "marujo"]:
		print("%s trancado no começo: %s (esperado: true)" % [id, not Dados.heroi_desbloqueado(id)])
	Salvo.d["maior_dano_run"] = 2000001.0
	print("forrozeiro depois de 2kk de dano: %s (esperado: true)" % Dados.heroi_desbloqueado("forrozeiro"))
	Salvo.d["contadores"]["chefes"] = 10
	print("angoleiro depois de 10 chefes: %s (esperado: true)" % Dados.heroi_desbloqueado("angoleiro"))
	Salvo.d["contadores"]["abates"] = 10000
	print("marujo depois de 10 mil abates: %s (esperado: true)" % Dados.heroi_desbloqueado("marujo"))
	print("capoeirista sempre liberado: %s (esperado: true)" % Dados.heroi_desbloqueado("capoeirista"))
	get_tree().quit()

func _teste_mundo() -> void:
	Salvo.d["nome_jogador"] = "Diogo"   # campo pessoal: tem que sobreviver à troca de mundo
	Salvo.entrar_mundo("Mundo de Teste XYZ123")
	print("1) entrou no mundo novo — moedas=%d nome=%s (esperado: 0, Diogo)" % [int(Salvo.d["moedas"]), Salvo.d["nome_jogador"]])
	Salvo.d["moedas"] = 777
	Salvo.sair_mundo()
	print("2) saiu do mundo — nome=%s (esperado: Diogo)" % Salvo.d["nome_jogador"])
	Salvo.entrar_mundo("Mundo de Teste XYZ123")
	print("3) voltou no MESMO mundo — moedas=%d (esperado: 777, igual salvou antes)" % int(Salvo.d["moedas"]))
	Salvo.sair_mundo()
	Salvo.entrar_mundo("Outro Mundo XYZ456")
	print("4) entrou em mundo DIFERENTE — moedas=%d (esperado: 0, não pegou do outro mundo)" % int(Salvo.d["moedas"]))
	Salvo.sair_mundo()
	print("5) saiu de novo — nome=%s moedas(d)=%d (esperado: Diogo, e o save sozinho sem as 777 moedas)" % [Salvo.d["nome_jogador"], int(Salvo.d["moedas"])])
	var visitante := {"moedas": 333, "nome_jogador": "Nome Que Não Deveria Aparecer"}
	Salvo.entrar_mundo_visitante(visitante)
	print("6) visitante entrou — moedas=%d nome=%s (esperado: 333, Diogo — nome é sempre o da pessoa)" % [int(Salvo.d["moedas"]), Salvo.d["nome_jogador"]])
	Salvo.d["moedas"] = 999   # visitante NUNCA deveria conseguir gravar isso em lugar nenhum
	Salvo.sair_mundo()
	print("7) visitante saiu — nome=%s (esperado: Diogo)" % Salvo.d["nome_jogador"])
	get_tree().quit()

func _teste_dash() -> void:
	iniciar_jogo("capoeirista")
	player.frente = Vector3(0, 0, 1)
	player.forcar_dash()
	print("TESTE ARRANCADA — dash_t:%.2f dash_dir:%s (esperado dash_t > 0)" % [player.dash_t, player.dash_dir])
	get_tree().quit()

func _galeria() -> void:
	cam_fixa = true
	var nomes := _nomes_galeria
	for i in range(nomes.size()):
		var b := Boneco.criar(nomes[i]); add_child(b)
		var x := (i - (nomes.size() - 1) / 2.0) * 1.5
		b.position = Vector3(x, Lib.h(x, 0), 0); b.rotation.y = 0.35
	camera.fov = 55.0; sem_mouse = true
	camera.global_position = Vector3(0, Lib.h(0, 0) + 2.4, 14.0)
	camera.look_at(Vector3(0, Lib.h(0, 0) + 1.0, 0), Vector3.UP)
	_salvar("shot_galeria")

# Muralha de mata amazônica em volta da clareira: árvores gigantes coladas, com sapopemba e cipó.
# casa de taipa com telhado de palha (a matriz que o Gravador usa e o reserva 3D)
func _casa_montar(c: Node3D) -> void:
	Lib.cx(c, Vector3(4.4, 2.5, 3.6), Vector3(0, 1.25, 0), Paleta.TERRA_CL)                          # parede de taipa
	Lib.cx(c, Vector3(4.5, 0.55, 3.7), Vector3(0, 0.27, 0), Paleta.PALHA)                           # rodapé caiado
	var tel := Lib.cil(c, 0.0, 3.5, 1.9, Vector3(0, 3.4, 0), Paleta.PALHA, 4, Vector3(0, PI / 4.0, 0))   # telhado de palha
	tel.scale = Vector3(1.0, 1.0, 0.82)
	Lib.cx(c, Vector3(0.9, 1.6, 0.12), Vector3(-0.6, 0.85, 1.83), Paleta.TINTA)                      # porta
	Lib.cx(c, Vector3(0.7, 0.6, 0.12), Vector3(0.9, 1.5, 1.83), Paleta.AZUL)                         # janela
	Lib.cx(c, Vector3(0.9, 0.12, 0.2), Vector3(0.9, 1.15, 1.9), Paleta.TERRA_ESC)

func _cruzeiro_montar(cz: Node3D) -> void:
	Lib.cil(cz, 0.12, 0.16, 3.6, Vector3(0, 1.8, 0), Paleta.TERRA_ESC, 5)
	Lib.cx(cz, Vector3(1.5, 0.22, 0.22), Vector3(0, 2.7, 0), Paleta.TERRA_ESC)
	Lib.cil(cz, 0.6, 0.8, 0.3, Vector3(0, 0.15, 0), Paleta.PEDRA, 6)

# crânio de boi branco numa estaca, com chifres abertos
func _cranio_montar(n: Node3D) -> void:
	Lib.cil(n, 0.07, 0.09, 1.3, Vector3(0, 0.65, 0), Paleta.TERRA_ESC, 5)
	Lib.esf(n, 0.3, Vector3(0, 1.38, 0), Paleta.CREME, Vector3(0.85, 1.0, 1.15), 6)
	Lib.cx(n, Vector3(0.2, 0.28, 0.3), Vector3(0, 1.2, 0.28), Paleta.CREME)          # focinho
	for sx in [-1.0, 1.0]:
		Lib.cx(n, Vector3(0.1, 0.1, 0.06), Vector3(0.12 * sx, 1.45, 0.3), Paleta.TINTA)   # órbitas
		Lib.cil(n, 0.02, 0.07, 0.75, Vector3(0.5 * sx, 1.55, 0.0), Paleta.CREME, 5, Vector3(0, 0, -1.15 * sx))   # chifre
		Lib.cil(n, 0.0, 0.03, 0.4, Vector3(0.88 * sx, 1.82, 0.0), Paleta.CREME, 4, Vector3(0, 0, -0.5 * sx))

# um vão de cerca de pau a pique (3 estacas e 2 travessas)
func _cerca_montar(n: Node3D) -> void:
	for k in range(3):
		Lib.cil(n, 0.07, 0.09, 1.25, Vector3(-1.3 + k * 1.3, 0.62, 0), Paleta.TERRA_ESC, 5)
	for alt in [0.45, 0.9]:
		Lib.cx(n, Vector3(2.8, 0.08, 0.08), Vector3(0, alt, 0), Paleta.PALHA)

# Vilarejo do sertão: casas de taipa, cercas de pau, crânios de boi e um cruzeiro (figuras de papel, ou 3D no reserva).
func _montar_vilarejo() -> void:
	Lib.contorno_mundo = 0.05
	var casas := [Vector3(-30, 0, 14), Vector3(33, 0, -24), Vector3(-17, 0, -38), Vector3(24, 0, 30)]
	for i in range(casas.size()):
		var p: Vector3 = casas[i]
		var y := Lib.h(p.x, p.z)
		if y < -0.8: continue
		var giro := i * 1.3 + 0.4
		if Gravador.disponivel():
			var cc := Cartao.novo("@cenario:casa:0"); cc.position = Vector3(p.x, y - 0.1, p.z); add_child(cc)
		else:
			var c := Node3D.new(); c.position = Vector3(p.x, y - 0.1, p.z); c.rotation.y = giro; add_child(c)
			_casa_montar(c)
		troncos.append(Vector3(p.x, p.z, 2.7))
		_cerca(Vector3(p.x, 0, p.z) + Vector3(-3.5, 0, 4.2).rotated(Vector3.UP, giro), Vector3(p.x, 0, p.z) + Vector3(3.5, 0, 4.2).rotated(Vector3.UP, giro))
	for sp in [Vector3(-27, 0, 9), Vector3(30, 0, -18), Vector3(-12, 0, -33), Vector3(20, 0, 26), Vector3(-34, 0, 20)]:
		_cranio_boi(Vector3(sp.x, Lib.h(sp.x, sp.z), sp.z), sp.x * 0.37)
	var cp := Vector3(-24, 0, 4); cp.y = Lib.h(cp.x, cp.z)
	if Gravador.disponivel():
		var cz := Cartao.novo("@cenario:cruzeiro:0"); cz.position = cp; add_child(cz)
	else:
		var cz2 := Node3D.new(); cz2.position = cp; add_child(cz2); _cruzeiro_montar(cz2)
	troncos.append(Vector3(cp.x, cp.z, 0.6))
	Lib.contorno_mundo = 0.0

func _cranio_boi(pos: Vector3, giro: float) -> void:
	var n: Node3D
	if Gravador.disponivel(): n = Cartao.novo("@cenario:cranio:0")
	else:
		n = Node3D.new(); n.rotation.y = giro; _cranio_montar(n)
	n.position = pos; add_child(n)
	troncos.append(Vector3(pos.x, pos.z, 0.2))

# cerca de pau a pique entre dois pontos (só enfeite: não bloqueia ninguém)
func _cerca(a: Vector3, b: Vector3) -> void:
	var d := a.distance_to(b)
	# SEMPRE fixa (nunca vira pro boneco de papel/Cartao): a cerca corre em linha reta por dezenas de metros,
	# e virar cada pedaço pra câmera fazia tudo se sobrepor/tremer quando a câmera olhava quase junto da cerca
	# (de raspão) — o mesmo problema das bandeirinhas do arraial, só que pior por ser bem mais comprida.
	var n2 := int(d / 1.3) + 1
	for k in range(n2 + 1):
		var pt2 := a.lerp(b, float(k) / n2)
		Lib.cil(self, 0.07, 0.09, 1.25, Vector3(pt2.x, Lib.h(pt2.x, pt2.z) + 0.6, pt2.z), Paleta.TERRA_ESC, 5)
	for alt in [0.45, 0.9]:
		var m := Lib.cx(self, Vector3(0.07, 0.07, d), (a + b) * 0.5 + Vector3(0, Lib.h((a.x + b.x) * 0.5, (a.z + b.z) * 0.5) + alt, 0), Paleta.PALHA)
		m.look_at_from_position(m.position, Vector3(b.x, m.position.y, b.z), Vector3.UP)

func _montar_muralha() -> void:
	var rng := RandomNumberGenerator.new(); rng.seed = 314
	var verdes := [Paleta.VERDE_ESC, Paleta.TINTA, Paleta.VERDE_ESC, Paleta.VERDE]   # mata de fundo: massa escura de gravura
	var casca := Paleta.TERRA_ESC
	for anel in range(3):
		var r := ARENA + 1.5 + anel * 4.5
		var n := int(TAU * r / (3.3 + anel * 0.9))
		for i in range(n):
			var a := i * TAU / n + rng.randf() * 0.05 + anel * 0.37
			var rr := r + rng.randf_range(-0.7, 0.7)
			var x := cos(a) * rr; var z := sin(a) * rr
			var t: Node3D
			if Gravador.disponivel():
				var ee := 1.0 + rng.randf() * 0.5 + anel * 0.3
				t = Cartao.novo("@muralha:%d" % (rng.randi() % 4))
				t.position = Vector3(x, Lib.h(x, z) - 0.3, z); t.scale = Vector3(ee, ee, ee); add_child(t)
				oclusores.append([t, x, z, 3.7 * ee])
				continue
			t = Node3D.new(); t.position = Vector3(x, Lib.h(x, z) - 0.3, z); t.rotation.y = rng.randf() * TAU
			var e := 1.0 + rng.randf() * 0.5 + anel * 0.3
			t.scale = Vector3(e, e, e); add_child(t); oclusores.append([t, x, z, 3.7 * e])
			var alt := 7.0 + rng.randf() * 3.5
			Lib.cil(t, 0.35, 0.62, alt, Vector3(0, alt * 0.5, 0), casca, 6)
			Lib.esf(t, 3.3, Vector3(0, alt + 0.6, 0), verdes[rng.randi() % 4], Vector3(1, 0.62, 1), 6)
			Lib.esf(t, 2.4, Vector3(1.7, alt - 0.9, 0.6), verdes[rng.randi() % 4], Vector3(1, 0.62, 1), 6)
			if anel == 0:
				for k in range(3):                                          # sapopemba
					Lib.cx(t, Vector3(0.14, 1.7, 1.9), Vector3(0, 0.6, 0), casca, Vector3(0, k * TAU / 6.0, 0))
				for k in range(3):                                          # cipós
					Lib.cil(t, 0.035, 0.035, alt * 0.55, Vector3(rng.randf_range(-2.2, 2.2), alt * 0.62, rng.randf_range(-2.2, 2.2)), Color(0.22, 0.42, 0.15), 4)
				Lib.esf(t, 1.7, Vector3(1.5, 0.8, 0.3), verdes[rng.randi() % 4], Vector3(1.25, 1.0, 1.25), 6)   # moita fechando o vão
				Lib.esf(t, 1.3, Vector3(-1.4, 0.6, -0.4), verdes[rng.randi() % 4], Vector3(1.2, 1.0, 1.2), 6)

func _borda() -> void:
	sem_mouse = true
	iniciar_jogo("benzedeira")
	player.position = Vector3(ARENA - 10.0, 0, -14.0)
	player.frente = Vector3(-1, 0, 0.3)
	cam_yaw = -PI / 2.0; cam_pitch = 0.3; cam_dist = 9.0
	_salvar("shot_borda")

# ---------------- especial (Q) e ultimate (R) ----------------
func _escala_hab(p: Jogador) -> float:
	return p.dano_mult * (1.0 + 0.06 * (p.level - 1))

func _mais_forte(pos: Vector3, maxd: float):
	var melhor = null; var bh := 0.0
	for e in enemies:
		if not is_instance_valid(e) or e.dead: continue
		var dd: Vector3 = e.global_position - pos; dd.y = 0
		if dd.length() <= maxd and e.hp > bh: bh = e.hp; melhor = e
	return melhor

func usar_especial(p: Jogador) -> void:
	if p.q_cd > 0.0 or p.lunge_t > 0.0: return
	var hq: Dictionary = Dados.HABILIDADES[p.classe]["q"]
	var s := _escala_hab(p); var pos: Vector3 = p.global_position
	var cor: Color = Dados.CLASSES[p.classe]["cor"]
	match p.classe:
		"capoeirista":
			p.iframes = 0.8; p.dash_t = 0.25; p.dash_dir = p.frente; p.boneco.girar()
			_ring(pos, 4.0 * p.area_mult, 38.0 * s, 0.6, 2.0)
			_efeito_anel(pos, 4.2 * p.area_mult, cor); _efeito_anel(pos, 2.6, Color.WHITE)
		"jiujitsu":
			var alvo = _mais_forte(pos, 9.0)
			if alvo == null: return
			p.guarda_t = 1.5
			var alvo_id: int = alvo.get_instance_id()
			p.comecar_investida(alvo.global_position, 22.0, func():
				_efeito_anel(p.global_position, 2.2, cor)
				var al = instance_from_id(alvo_id)
				if al != null and is_instance_valid(al) and not al.dead:
					al.stun_t = maxf(al.stun_t, 0.6 if al.is_boss else 2.5)
					ferir(al, 160.0 * s)
					if al.dead: p.curar(p.max_hp * 0.10))
		"benzedeira":
			p.curar(p.max_hp * 0.3)
			_ring(pos, 5.5 * p.area_mult, 20.0 * s, 0.8, 3.5)
			_efeito_anel(pos, 5.5 * p.area_mult, Color(0.5, 1.0, 0.6))
		"cangaceiro":
			var alvo2 = _mais_forte(pos, 28.0)
			var dir: Vector3 = p.frente
			if alvo2:
				dir = alvo2.global_position - pos; dir.y = 0; dir = dir.normalized()
			_disparar(pos, dir * 32.0, TIRO_Q, 210.0 * s)
			p.boneco.atacar()
		"frevista":
			p.iframes = 0.7; p.dash_t = 0.22; p.dash_dir = p.frente; p.boneco.girar()
			_ring(pos, 4.0 * p.area_mult, 34.0 * s, 0.5, 1.8)
			_efeito_anel(pos, 4.0 * p.area_mult, cor); _efeito_anel(pos, 2.4, Color.WHITE)
		"cordelista":
			var alvo3q = _mais_forte(pos, 28.0)
			var dir3: Vector3 = p.frente
			if alvo3q:
				dir3 = alvo3q.global_position - pos; dir3.y = 0; dir3 = dir3.normalized()
			_disparar(pos, dir3 * 30.0, TIRO_Q, 220.0 * s)
			p.boneco.atacar()
		"sambista":
			p.iframes = 0.75; p.dash_t = 0.23; p.dash_dir = p.frente; p.boneco.girar()
			_ring(pos, 4.1 * p.area_mult, 36.0 * s, 0.5, 2.0)
			_efeito_anel(pos, 4.1 * p.area_mult, cor); _efeito_anel(pos, 2.5, Color.WHITE)
		"maracatuzeiro":
			var alvo4 = _mais_forte(pos, 9.0)
			if alvo4 == null: return
			var alvo4_id: int = alvo4.get_instance_id()
			p.comecar_investida(alvo4.global_position, 18.0, func():
				_efeito_anel(p.global_position, 2.4, cor)
				var al4 = instance_from_id(alvo4_id)
				if al4 != null and is_instance_valid(al4) and not al4.dead:
					al4.stun_t = maxf(al4.stun_t, 0.6 if al4.is_boss else 2.5)
					ferir(al4, 150.0 * s))
		"violeiro":
			var alvo5 = _mais_forte(pos, 28.0)
			var dir5: Vector3 = p.frente
			if alvo5:
				dir5 = alvo5.global_position - pos; dir5.y = 0; dir5 = dir5.normalized()
			_disparar(pos, dir5 * 30.0, TIRO_Q, 210.0 * s)
			p.boneco.atacar()
		"carimbozeiro":
			p.iframes = 0.7; p.dash_t = 0.22; p.dash_dir = p.frente; p.boneco.girar()
			_ring(pos, 4.0 * p.area_mult, 34.0 * s, 0.5, 1.8)
			_efeito_anel(pos, 4.0 * p.area_mult, cor); _efeito_anel(pos, 2.4, Color.WHITE)
		# ---- a partir daqui: cada um tem um Q de verdade diferente (não é mais golpe reaproveitado) ----
		"forrozeiro":    # o mais ligeiro: acelera o próprio ataque, não ataca na hora
			p.buff_temp("atk_speed", 0.70, 4.0); _efeito_anel(pos, 2.0, cor)
		"angoleiro":     # cabeçada de mestre (golpe de verdade, autêntico da capoeira angola)
			var alvo7 = _mais_forte(pos, 9.0)
			if alvo7 == null: return
			var alvo7_id: int = alvo7.get_instance_id()
			p.comecar_investida(alvo7.global_position, 18.0, func():
				_efeito_anel(p.global_position, 2.3, cor)
				var al7 = instance_from_id(alvo7_id)
				if al7 != null and is_instance_valid(al7) and not al7.dead:
					al7.stun_t = maxf(al7.stun_t, 0.6 if al7.is_boss else 2.5)
					ferir(al7, 155.0 * s))
		"marujo":        # rede: prende um bicho num raio grande, sem sair do lugar
			_ring(pos, 5.0 * p.area_mult, 38.0 * s, 2.2, 0.3)
			_efeito_anel(pos, 5.0 * p.area_mult, cor)
		"jongueira":     # roda de jongo: atordoa todo mundo num raio grande, parada no chão
			_ring(pos, 5.5 * p.area_mult, 34.0 * s, 1.8, 0.2)
			_efeito_anel(pos, 5.5 * p.area_mult, cor)
		"chorao":        # solo de flauta: um golpe só, mas rouba vida
			var alvo10 = _nearest(pos, 10.0)
			if alvo10 == null: return
			ferir(alvo10, 160.0 * s); p.curar(160.0 * s * 0.3)
		"ceramista":     # arremesso que endurece: atordoa e empurra num raio grande, parado
			_ring(pos, 5.0 * p.area_mult, 38.0 * s, 1.6, 1.6)
			_efeito_anel(pos, 5.0 * p.area_mult, cor)
		"cantora":       # grito certeiro: um golpe só, crítico garantido no bicho mais forte
			var alvo_c = _mais_forte(pos, 10.0)
			if alvo_c == null: return
			ferir(alvo_c, 220.0 * s, 1.0)
		"pintor":        # retrato certeiro: um golpe só, crítico garantido no bicho mais forte
			var alvo_p = _mais_forte(pos, 10.0)
			if alvo_p == null: return
			ferir(alvo_p, 200.0 * s, 1.0)
		"maestro":       # regência: atordoa todo mundo num raio grande, parado no lugar
			_ring(pos, 5.5 * p.area_mult, 30.0 * s, 2.0, 0.2)
			_efeito_anel(pos, 5.5 * p.area_mult, cor)
		"violonista":    # acorde: um golpe só, mas rouba vida
			var alvo13 = _nearest(pos, 10.0)
			if alvo13 == null: return
			ferir(alvo13, 150.0 * s); p.curar(150.0 * s * 0.2)
		"bimba":         # cintura desprezada (a queda clássica de Bimba, autêntica)
			var alvo14 = _mais_forte(pos, 9.0)
			if alvo14 == null: return
			var alvo14_id: int = alvo14.get_instance_id()
			p.comecar_investida(alvo14.global_position, 18.0, func():
				_efeito_anel(p.global_position, 2.3, cor)
				var al14 = instance_from_id(alvo14_id)
				if al14 != null and is_instance_valid(al14) and not al14.dead:
					al14.stun_t = maxf(al14.stun_t, 0.6 if al14.is_boss else 2.5)
					ferir(al14, 155.0 * s))
		"escultor":      # cinzel: atordoa todo mundo num raio grande, parado no lugar
			_ring(pos, 5.0 * p.area_mult, 32.0 * s, 2.2, 0.2)
			_efeito_anel(pos, 5.0 * p.area_mult, cor)
		"aviador":       # decola: fica rápido e esquivo por um tempo, não ataca na hora
			p.buff_temp("speed", 3.8, 5.0); p.buff_temp("dodge", 0.25, 5.0); _efeito_anel(pos, 2.0, cor)
		"escritor":      # farpa certeira: um golpe só, mas rouba vida
			var alvo16 = _nearest(pos, 10.0)
			if alvo16 == null: return
			ferir(alvo16, 150.0 * s); p.curar(150.0 * s * 0.25)
		"sertanista":    # expedição: atordoa todo mundo num raio grande, parado no lugar
			_ring(pos, 5.5 * p.area_mult, 34.0 * s, 1.8, 1.3)
			_efeito_anel(pos, 5.5 * p.area_mult, cor)
		"cangaceiro_chefe":  # tiro certeiro do capitão: um golpe só, crítico garantido no bicho mais forte
			var alvo17 = _mais_forte(pos, 10.0)
			if alvo17 == null: return
			ferir(alvo17, 230.0 * s, 1.0)
		"cangaceira":    # faca certeira: um golpe só, mas rouba vida
			var alvo_cc = _nearest(pos, 10.0)
			if alvo_cc == null: return
			ferir(alvo_cc, 155.0 * s); p.curar(155.0 * s * 0.25)
		"muralista":     # mural: atordoa todo mundo num raio grande, parado no lugar
			_ring(pos, 5.0 * p.area_mult, 36.0 * s, 1.6, 0.2)
			_efeito_anel(pos, 5.0 * p.area_mult, cor)
		"orador":        # réplica certeira: um golpe só, crítico garantido no bicho mais forte
			var alvo19 = _mais_forte(pos, 10.0)
			if alvo19 == null: return
			ferir(alvo19, 210.0 * s, 1.0)
		"quilombola":    # golpe do líder: lança que não solta (autêntico, resistência)
			var alvo20 = _mais_forte(pos, 9.0)
			if alvo20 == null: return
			var alvo20_id: int = alvo20.get_instance_id()
			p.comecar_investida(alvo20.global_position, 18.0, func():
				_efeito_anel(p.global_position, 2.4, cor)
				var al20 = instance_from_id(alvo20_id)
				if al20 != null and is_instance_valid(al20) and not al20.dead:
					al20.stun_t = maxf(al20.stun_t, 0.6 if al20.is_boss else 2.5)
					ferir(al20, 160.0 * s)
					if al20.dead: p.curar(p.max_hp * 0.10))
		"martir":        # carga da bandeira: atordoa todo mundo num raio grande, parado no lugar
			_ring(pos, 5.5 * p.area_mult, 34.0 * s, 2.0, 1.6)
			_efeito_anel(pos, 5.5 * p.area_mult, cor)
		"santa":         # bênção (segunda curandeira — mantém o jeito autêntico, só que com raio maior)
			p.curar(p.max_hp * 0.35)
			_ring(pos, 6.0 * p.area_mult, 18.0 * s, 0.8, 3.8)
			_efeito_anel(pos, 6.0 * p.area_mult, Color(0.5, 1.0, 0.6))
	p.q_cd = hq["cd"]
	Som.tocar("especial")
	Salvo.contar("uso_especial_" + p.classe)
	popup(pos, hq["nome"])

func usar_ultimate(p: Jogador) -> void:
	if p.ult < 1.0 or p.ult_t > 0.0: return
	var hr: Dictionary = Dados.HABILIDADES[p.classe]["r"]
	p.ult = 0.0; p.ult_tick = 0.0; p.ult_t = hr["dur"]
	Som.tocar("ult")
	var voz_ult: String = {"capoeirista": "v_cap", "jiujitsu": "v_jiu", "benzedeira": "v_ben", "cangaceiro": "v_can"}.get(p.classe, "")
	if voz_ult != "": Som.voz(voz_ult)
	tremor = 0.4
	if p.classe == "capoeirista": p.guarda_t = hr["dur"]
	# ultimates que são reforço do próprio corpo (não ataque em canal): aplica tudo de uma vez só aqui,
	# desfaz sozinho no fim da duração — por isso não aparecem em _hab_update.
	var d: float = hr["dur"]
	match p.classe:
		"forrozeiro": p.buff_temp("speed", 3.3, d); p.buff_temp("dano_mult", 0.25, d)
		"angoleiro": p.buff_temp("dodge", 0.45, d); p.buff_temp("armor", 0.15, d)
		"marujo": p.buff_temp("regen", 2.5, d); p.buff_temp("armor", 0.15, d)
		"jongueira": p.buff_temp("armor", 0.30, d); p.buff_temp("regen", 2.0, d)
		"chorao": p.buff_temp("atk_speed", 0.80, d)
		"ceramista": p.buff_temp("dano_mult", 0.45, d); p.buff_temp("armor", 0.15, d)
		"cantora": p.buff_temp("crit", 0.50, d); p.buff_temp("crit_dano", 1.0, d)
		"pintor": p.buff_temp("dano_mult", 0.40, d); p.buff_temp("atk_speed", 0.30, d)
		"maestro": p.buff_temp("regen", 2.5, d); p.buff_temp("armor", 0.20, d)
		"violonista": p.buff_temp("speed", 2.6, d); p.buff_temp("atk_speed", 0.40, d)
		"bimba": p.buff_temp("dodge", 0.35, d); p.buff_temp("dano_mult", 0.30, d)
		"escultor": p.buff_temp("armor", 0.40, d)
		"aviador": p.buff_temp("atk_speed", 0.50, d); p.buff_temp("speed", 1.9, d)
		"escritor": p.buff_temp("atk_speed", 0.50, d); p.buff_temp("regen", 2.0, d)
		"sertanista": p.buff_temp("armor", 0.25, d); p.buff_temp("speed", 1.3, d)
		"cangaceiro_chefe": p.buff_temp("crit", 0.40, d); p.buff_temp("atk_speed", 0.40, d)
		"cangaceira": p.buff_temp("dodge", 0.35, d); p.buff_temp("dano_mult", 0.25, d)
		"muralista": p.buff_temp("dano_mult", 0.45, d)
		"orador": p.buff_temp("regen", 3.0, d); p.buff_temp("armor", 0.15, d)
		"quilombola": p.buff_temp("armor", 0.40, d); p.buff_temp("dano_mult", 0.30, d)
		"martir": p.buff_temp("dano_mult", 0.50, d); p.buff_temp("speed", 1.3, d)
	Salvo.contar("uso_ultimate_" + p.classe)
	lbl_centro.text = String(hr["nome"]).to_upper(); _piscar_centro()

func _hab_update(delta: float) -> void:
	var p := player
	if p.ult_t <= 0.0: return
	p.ult_t -= delta; p.ult_tick -= delta
	if p.ult_tick > 0.0: return
	var s := _escala_hab(p); var pos: Vector3 = p.global_position
	var cor: Color = Dados.CLASSES[p.classe]["cor"]
	match p.classe:
		"capoeirista":
			p.ult_tick = 0.3; p.boneco.girar()
			_ring(pos, 4.6 * p.area_mult, 16.0 * s, 0.0, 0.6)
			_efeito_anel(pos, 4.6 * p.area_mult, cor)
		"jiujitsu":
			p.ult_tick = 0.2; p.iframes = 0.45
			var alvo = _nearest(pos, 14.0)
			if alvo:
				var d: Vector3 = alvo.global_position - pos; d.y = 0
				p.position += d * 0.85
				if d.length() > 0.1: p.frente = d.normalized()
				p.boneco.atacar()
				var k := _ring(p.global_position, 2.2, 110.0 * s, 1.0, 0.0)
				_efeito_anel(p.global_position, 2.2, cor)
				if k > 0: p.curar(p.max_hp * 0.02 * k)
		"benzedeira":
			p.ult_tick = 0.15
			var a := randf() * TAU
			_disparar(pos, Vector3(cos(a), 0, sin(a)) * 12.0, FOGO_ULT, 22.0 * s, _nearest(pos, 30.0))
		"cangaceiro":
			p.ult_tick = 0.25; p.boneco.atacar()
			for i in range(8):
				var a2 := i * TAU / 8.0 + time * 2.0
				_disparar(pos, Vector3(cos(a2), 0, sin(a2)) * 16.0, BALA_ULT, 14.0 * s)
		"frevista":
			p.ult_tick = 0.28; p.boneco.girar()
			_ring(pos, 4.2 * p.area_mult, 15.0 * s, 0.0, 0.5)
			_efeito_anel(pos, 4.2 * p.area_mult, cor)
		"cordelista":
			p.ult_tick = 0.25; p.boneco.atacar()
			for i in range(8):
				var a3 := i * TAU / 8.0 + time * 2.0
				_disparar(pos, Vector3(cos(a3), 0, sin(a3)) * 16.0, BALA_ULT, 13.0 * s)
		"sambista":
			p.ult_tick = 0.3; p.boneco.girar()
			_ring(pos, 4.5 * p.area_mult, 15.0 * s, 0.0, 0.6)
			_efeito_anel(pos, 4.5 * p.area_mult, cor)
		"maracatuzeiro":
			p.ult_tick = 0.22; p.iframes = 0.4
			var alvo6 = _nearest(pos, 13.0)
			if alvo6:
				var d6: Vector3 = alvo6.global_position - pos; d6.y = 0
				p.position += d6 * 0.7
				if d6.length() > 0.1: p.frente = d6.normalized()
				p.boneco.atacar()
				var k6 := _ring(p.global_position, 2.4, 95.0 * s, 1.0, 0.0)
				_efeito_anel(p.global_position, 2.4, cor)
				if k6 > 0: p.curar(p.max_hp * 0.015 * k6)
		"violeiro":
			p.ult_tick = 0.25; p.boneco.atacar()
			for i in range(8):
				var a6 := i * TAU / 8.0 + time * 2.0
				_disparar(pos, Vector3(cos(a6), 0, sin(a6)) * 16.0, BALA_ULT, 13.0 * s)
		"carimbozeiro":
			p.ult_tick = 0.28; p.boneco.girar()
			_ring(pos, 4.2 * p.area_mult, 14.0 * s, 0.0, 0.5)
			_efeito_anel(pos, 4.2 * p.area_mult, cor)
		# os 22 desbloqueáveis (forrozeiro até martir) agora têm ultimate de reforço do próprio corpo,
		# aplicado uma vez só em usar_ultimate() — por isso não entram aqui, não têm nada pra repetir a cada quadro.
		"santa":    # manto dos pobres: pulso de cura + atordoa quem chega perto, sem parar
			p.ult_tick = 0.5
			p.curar(p.max_hp * 0.03)
			_ring(pos, 4.5 * p.area_mult, 10.0 * s, 0.6, 1.0)
			_efeito_anel(pos, 4.5 * p.area_mult, Color(0.5, 1.0, 0.6))

# ---------------- ataques dos chefes ----------------
func aviso_chefe(pos: Vector3, raio: float, txt: String) -> void:
	_efeito_anel(pos, raio, Color(1.0, 0.15, 0.1))
	dano_num(pos + Vector3(0, 2.0, 0), txt, Color(1.0, 0.3, 0.2), 64)

func efeito_chefe(pos: Vector3, raio: float) -> void:
	Som.tocar("pisao")
	_efeito_anel(pos, raio, Color(1.0, 0.5, 0.1)); _efeito_anel(pos, raio * 0.6, Color(1.0, 0.9, 0.4))

func tiro_inimigo(pos: Vector3, vel: Vector3, dmg: float, cor: Color = Color(1.0, 0.45, 0.1)) -> void:
	var n := Lib.esf(self, 0.35, pos + Vector3(0, 0.9, 0), cor, Vector3.ONE, 6, 2.5)
	n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	tiros.append({"node": n, "vel": vel, "dmg": dmg, "vida": 3.5})

func _tiros(delta: float) -> void:
	for t in tiros.duplicate():
		var n: Node3D = t["node"]
		t["vida"] -= delta
		n.position += t["vel"] * delta
		n.position.y = Lib.h(n.position.x, n.position.z) + 0.9
		var alvo_tiro = _alvo_mais_perto(n.position)
		var dd: Vector3 = alvo_tiro.global_position - n.position if alvo_tiro else Vector3(99, 0, 99); dd.y = 0
		if alvo_tiro and dd.length() < 0.8 and alvo_tiro.alt < 1.3:
			ferir_jogador(alvo_tiro, t["dmg"]); t["vida"] = 0.0
		if t["vida"] <= 0.0:
			n.queue_free(); tiros.erase(t)

# print dos três chefes lado a lado
func _shot_chefe() -> void:
	cam_fixa = true
	var nomes := ["mapinguari", "mula", "boitata", "cuca", "minhocao"]
	for i in range(nomes.size()):
		var b := Boneco.criar(nomes[i]); add_child(b)
		var x := (i - 2) * 4.2
		b.position = Vector3(x, Lib.h(x, 0), 0); b.rotation.y = 0.55; b.scale = Vector3(1.6, 1.6, 1.6)
	var h0 := Boneco.criar("capoeirista"); add_child(h0); h0.position = Vector3(-10.8, Lib.h(-10.8, 0), 0.5); h0.rotation.y = 0.5
	camera.fov = 65.0
	camera.global_position = Vector3(-0.5, Lib.h(0, 0) + 4.5, 20.0)
	camera.look_at(Vector3(-0.5, Lib.h(0, 0) + 1.7, 0), Vector3.UP)
	_salvar("shot_chefes")
